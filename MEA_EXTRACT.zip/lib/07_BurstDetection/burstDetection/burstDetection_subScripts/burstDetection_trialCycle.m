% burstDetection_trialCycle.m
% Detects bursts from the collection of peak
% trains (trial by trial)
function [newBurstDetection_cell, burstEvent_cell, outburstSpikes_cell, isActiveChannel] = ...
    burstDetection_trialCycle(startPath, ISIThFolder, userParam)
% count number of different trials
trialFolders = dirr(startPath);
numTrials = length(trialFolders); 
% initialize variables
maxNumElec = 88;
newBurstDetection_cell = cell(maxNumElec,numTrials);
burstEvent_cell = cell(maxNumElec,numTrials);
outburstSpikes_cell = cell(maxNumElec,numTrials);
% ------ COMPUTATION ------
cancWinSample = userParam.cancWin*1e-3*userParam.sf;    % [sample]
hWB = waitbar(0,'Burst Detection...Please wait...','Position',[50 50 275 50]);
u = 0;
for j = 1:numTrials
    u = u + 1/(numTrials);
    waitbar(u,hWB)
    trialFolder = fullfile(startPath,trialFolders(j).name);
    numberOfSamples = getSamplesNumber(trialFolder);
    numberOfElectrodes = getElectrodesNumber(trialFolder);
    files = dirr(trialFolder);
    idxSlash = strfind(trialFolder,filesep);
    trialFolderName = trialFolder(idxSlash(end)+1:end);
%     [trialFolderPath, trialFolderName] = fileparts(trialFolder);
    % Load ISITh
    ISITh = importdata(fullfile(ISIThFolder,['ISIHistLOG_ISImaxTh_',trialFolderName,'.txt']));
    
    isActiveChannel = zeros(88,1); % array to store whether the channel has any peaks --> active
    
    tic
    for k = 1:numberOfElectrodes
        filename = fullfile(trialFolder,files(k).name);
        elecNumber = str2double(filename(end-5:end-4));
        load(filename);
        if sum(peak_train) > 0        % if there is at least one spike
            %%%%%%%%% TO REVISE AS SOON AS THE NEW ARTEFACT DETECTION WILL
            %%%%%%%%% BE AVAILABLE
            
            isActiveChannel(elecNumber)=1;
            
            if exist('artifact','var') && ~isempty(artifact) && ~isscalar(artifact)
                peak_train = delartcontr(peak_train,artifact,cancWinSample);    % delete artifact contribution
            end
            %%%%%%%%%
%             peakTrain = sparse(numberOfSamples,1);
%             peak_train = peak_train(1:numberOfSamples);
%             clear peak_train artifact
            if ISITh(k,3)
                ISIThThis = ISITh(ISITh(:,1)==elecNumber,:);
                [newBurstDetection_cell{elecNumber,j}, ...
                    burstEvent_cell{elecNumber,j}, ...
                    outburstSpikes_cell{elecNumber,j}] = ...
                    burstDetection_oneChannelComput(peak_train, ISIThThis, userParam);
            else
                continue
            end  
        else
            continue
        end
    end
    toc
end
close(hWB)

%%Initialize figure
scrsz = get(0,'ScreenSize');
f2 = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
ylim([0,60]);
hold on
channels = getMEA60Channels();
fs = userParam.sf;
for k = 1:length(channels)
    BDcurElec = newBurstDetection_cell{channels(k)};
    for i=1:size(BDcurElec)-1
        x = [BDcurElec(i,1),BDcurElec(i,2)]/fs;
        y = [k k];
        line(x,y,'lineWidth',2);
    end
end

set(gca,'YTick',1:60);
set(gca,'YTickLabel',channels);
close(f2);
