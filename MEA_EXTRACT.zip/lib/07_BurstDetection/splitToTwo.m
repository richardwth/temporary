function [splitPos,flag,voidParameter] = splitToTwo(valPos,voidParamTh,simBursts)

if size(valPos,1)<2
    splitPos=[];
    voidParameter=[];
    flag = 0;
    return
end

voidMat = zeros(size(valPos,1));
sepMat = zeros(size(valPos,1));

for i=1:size(valPos,1)
    y1 = valPos(i,1);
    for j=i+1:size(valPos,1)
        y2 = valPos(j,1);
        index1 = min([valPos(i,2),valPos(j,2)]);
        index2 = max([valPos(i,2),valPos(j,2)]);
        [yMin,tempIdxMin] = min(simBursts(index1:index2));
        % the void parameter is a measure of the degree of separation
        % between the two peaks through the minimum
        voidMat(i,j) = 1-(yMin/sqrt(y1.*y2));
        sepMat(i,j) = tempIdxMin+index1-1;
    end
end

[colVals,rowPos] = max(voidMat);
[maxVoid,col] = max(colVals);


if maxVoid>=voidParamTh
    flag = 1;
    row = rowPos(col);
    splitPos = sepMat(row,col);
    voidParameter=maxVoid;
else
    splitPos=[];
    flag = 0;
    voidParameter=[];
    return;
end

