function burstDetectionISIN(peakfolder, end_folder1, end_folder2, end_folder3, nspikes, fs)
% Function for producing the Burst Detection files
display=1;

% DEFINE LOCAL VARIABLES
first=3;
channels = getMEA60Channels();
coreMult = 4;
extMult = 3;

% START PROCESSING
cd(peakfolder)                       % start_folder in the MAIN program
peakfolderdir=dir;                   % struct containing the peak-det folders
NumPeakFolder=length(peakfolderdir); % number of experimental phases


%% Initilaize figure
scrsz = get(0,'ScreenSize');
f2 = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
ylim([0,60]);
hold on


for m= first:NumPeakFolder  % FOR cycle on the phase directories
    phasedir=peakfolderdir(m).name;
    newdir=strcat (phasedir(8:end));
    cd (phasedir)
    phasedir= pwd;
    phasefiles= dir;
    NumPhaseFiles= length(phasefiles);
    
    if(NumPhaseFiles>first)
        h = waitbar(0,'Initializing waitbar...');
    end
    
    burst_detection_cell = cell(88,1);  % cell array containing the burst features for each channel
    burst_event_cell     = cell (88,1); % cell array containing the burst_event train for each channel
    outburst_spikes_cell = cell(88,1);  % cell array containing the random spikes features for each channel
    
    isActiveChannel = zeros(88,1); % array to store whether the channel has any peaks --> active
    
    isiChans = zeros(NumPhaseFiles-2,5);
    
    for i= first:NumPhaseFiles % FOR cycle on the single directory files
        filename = phasefiles(i).name;    % current PKD file
        electrode= filename(end-5:end-4); % current electrode [char]
        el= str2num(electrode);           % current electrode [num]
        
        waitbar((i-first+1)/(NumPhaseFiles-first+1),h,sprintf('%d out %d channels',i-first+1,NumPhaseFiles-first+1));
        
        load (filename);                  % 'peak_train' and 'artifact' are loaded
        
        if nnz(peak_train)>3
            
            %separate time into 500ms bins and find bins <afr
            timestamps = find(peak_train);
            
            afrAll = length(timestamps)/length(peak_train); %average firing rate
            
            spikes = find(peak_train);
            
            minSpikes = 3;
            % isi2 = getThreshForISIN(spikes,2);
            isiN = getThreshForISIN(spikes,minSpikes);
            
            mode = 0;
            
            if  ~isnan(isiN)
                disp('isi');
                mode = 1;
               % disp(isi2*1000/fs);
                disp(isiN*1000/fs);
                
                %% find isiThreshs
                ISImaxsample1 = min([100*fs/1000,isiN*1000/fs]);
                ISImaxsample2  = min([200*fs/1000,isiN*1000/fs]);
            else
                disp('afr');
                afr = afrAll;
                ISImaxsample1 = min([100*fs/1000,1/(coreMult*afr)]);
                ISImaxsample2  = min([200*fs/1000,1/(extMult*afr)]);
            end
            
            afr = afrAll;
            
            isiChans(i-2,:)=[el,ISImaxsample1*1000/fs,ISImaxsample2*1000/fs,1000/(fs*afr),1000/(fs*afrAll)];
            
            barray = [];
            if ~isempty(ISImaxsample1) && ~isempty(ISImaxsample2) && mode==0
                
                isActiveChannel(el)=1;
                timestamp=find(peak_train); % Vector with dimension [nx1]
                
                allisi  =[-sign(diff(timestamp)-ISImaxsample1)];
                allisi(find(allisi==0))=1;  % If the difference is exactly ISImax, I have to accept the two spikes as part of the burst
                edgeup1  =find(diff(allisi)>1)+1;  % Beginning of burst
                edgedown1=find(diff(allisi)<-1)+1; % End of burst
                
                if ((length(edgedown1)>=2) && (length(edgeup1)>=2))
                    
                    % Get bursts with intra burst spikes only
                    barray_init=[];
                    barray_end=[];
                    
                    if (edgedown1(1)<edgeup1(1))
                        barray_init=[timestamp(1), timestamp(edgedown1(1)), edgedown1(1), ...
                            (timestamp(edgedown1(1))-timestamp(1))/fs,1,edgedown1(1)];
                        edgedown1=edgedown1(2:end);
                    end
                    
                    if(edgeup1(end)>edgedown1(end))
                        barray_end= [timestamp(edgeup1(end)), timestamp(end), length(timestamp)-edgeup1(end)+1, ...
                            (timestamp(end)-timestamp(edgeup1(end)))/fs,edgeup1(end),length(timestamp)];
                        edgeup1=edgeup1(1:end-1);
                    end
                    
                    barray1= [timestamp(edgeup1), timestamp(edgedown1), (edgedown1-edgeup1+1), ...
                        (timestamp(edgedown1)-timestamp(edgeup1))/fs,edgeup1,edgedown1];      % [init end nspikes duration-sec]
                    barray1= [barray_init;barray1;barray_end];
                    
                    barray1=barray1(barray1(:,3)>=3,:);
                    
                    
                    allisi  =[-sign(diff(timestamp)-ISImaxsample2)];
                    allisi(allisi==0)=1;  % If the difference is exactly ISImax, I have to accept the two spikes as part of the burst
                    edgeup2  =find(diff(allisi)>1)+1;  % Beginning of burst
                    edgedown2=find(diff(allisi)<-1)+1; % End of burst
                    
                    %% Get bursts with burst related spikes
                    if ((length(edgedown2)>=2) && (length(edgeup2)>=2))
                        
                        barray_init=[];
                        barray_end=[];
                        
                        if (edgedown2(1)<edgeup2(1))
                            barray_init=[timestamp(1), timestamp(edgedown2(1)), edgedown2(1), ...
                                (timestamp(edgedown2(1))-timestamp(1))/fs,1,edgedown2(1)];
                            edgedown2=edgedown2(2:end);
                        end
                        
                        if(edgeup2(end)>edgedown2(end))
                            barray_end= [timestamp(edgeup2(end)), timestamp(end), length(timestamp)-edgeup2(end)+1, ...
                                (timestamp(end)-timestamp(edgeup2(end)))/fs,edgeup2(end),length(timestamp)];
                            edgeup2=edgeup2(1:end-1);
                        end
                        
                        barray2= [timestamp(edgeup2), timestamp(edgedown2), (edgedown2-edgeup2+1), ...
                            (timestamp(edgedown2)-timestamp(edgeup2))/fs,edgeup2,edgedown2];      % [init end nspikes duration-sec]
                        barray2= [barray_init;barray2;barray_end];
                        
                        
                        %%If a strict burst is found inside a diluted burst, expand the edges of the strict burst
                        for t=1:size(barray2,1)
                            barray1Inds = find(barray1(:,1)>=barray2(t,1) &  barray1(:,2)<=barray2(t,2));
                            if ~isempty(barray1Inds)
                                barray1(barray1Inds(1),:)=barray2(t,:);
                                if length(barray1Inds) > 1
                                    barray1(barray1Inds(2:end),:)=[];
                                end
                            end
                        end
                    end
                    barray = barray1;
                end
            else
                %% if isiN was used
                
%                 isi2s = spikes(2:end)-spikes(1:end-1);
%                 inds = find(isi2s<isi2);
%                 coreSpk = zeros(length(spikes),1);
%                 for j=1:2
%                     coreSpk(inds+j-1)=1;
%                 end
                
                isiNs = spikes(minSpikes:end)-spikes(1:end-minSpikes+1);
                inds = find(isiNs<isiN);
                extSpk = zeros(length(spikes)+minSpikes,1);
                for j=1:minSpikes
                    extSpk(inds+j-1)=1;
                end
                extSpk(length(extSpk)-minSpikes+1:end)=[];
                
%                 edges = diff(coreSpk);
%                 starts2 = find(edges==1)+1;
%                 ends2 = find(edges==-1);
                
                edges = diff([0;extSpk;0]);
                startsN = find(edges==1);
                endsN = find(edges==-1)-1;
                
                barray = [spikes(startsN),spikes(endsN),endsN-startsN+1,(spikes(endsN)-spikes(startsN))./fs];
                
            end
            
            barray(barray(:,3)<nspikes,:) = [];
            
            if ~isempty(barray)                
                
                %%Take bursts that have spikes above the min Number of Spikes
                burst_detection=barray(:,1:4); % Real burst statistics
                
                burstSize = zeros(size(burst_detection,1),3);
                for x=1:size(burst_detection,1)
                    burstSize(x,1) = sum(peak_train(burst_detection(x,1):burst_detection(x,2))); % sum of all peak amplitudes in the burst
                    burstSize(x,2) = burstSize(x,1)/burst_detection(x,3); % average peak amplitude per spike in the burst
                    burstSize(x,3) = burstSize(x,1)/burst_detection(x,4); % average peak amplitude during the burst duration
                end
                
                [r,c]=size(burst_detection);
                acq_time=fix(length(peak_train)/fs); % Acquisition time  [sec]
                mbr=r/(acq_time/60);                 % Mean Bursting Rate [bpm]
                
                
                % INSIDE BURST Parameters
                binit= burst_detection(:,1); % Burst init [samples]
                burst_event =sparse(binit, ones(length(binit),1), peak_train(binit)); % Burst event
                bp= [diff(binit)/fs; 0];     % Burst Period [sec] - start-to-start
                ibi= [((burst_detection(2:end,1)- burst_detection(1:end-1,2))/fs); 0]; % Inter Burst Interval, IBI [sec] - end-to-start
                lastrow=[acq_time, length(find(peak_train)), r, sum(burst_detection(:,3)), mbr, 0, 0, 0, 0];
                
                burst_detection=[burst_detection, ibi, bp, burstSize; lastrow];
                % burst_detection=[init, end, nspikes, duration, ibi, bp;
                %  acquisition time, total spikes, total bursts, total burst spikes, mbr, average mfob]
                
                burst_detection_cell{el,1}= burst_detection; % Update the cell array
                burst_event_cell{el,1}= burst_event;         % Update the cell array
                outburst_spikes_cell{el,1}= [];   % Update the cell array
                
                
                clear rlines clines out_burst tempburst
                
                %% draw bursts
                figure(f2);
                if ~isempty(burst_detection)
                    for k=1:size(burst_detection,1)-1
                        x = [burst_detection(k,1),burst_detection(k,2)]/fs;
                        chanNo = find(channels == el);
                        y = [chanNo chanNo];
                        line(x,y,'lineWidth',2);
                    end
                end
                
            end
            
        end
        cd (phasedir);
        
    end
    
    % SAVE ALL FILES
    cd(end_folder1) % Burst array
    nome=strcat('burst_detection_', newdir);
    save(nome, 'burst_detection_cell','isActiveChannel');
    
    cd(end_folder2) % Burst event
    nome=strcat('burst_event_', newdir);
    save(nome, 'burst_event_cell');
    
    cd(end_folder3) % Outside Burst Spikes
    nome=strcat('outburst_spikes_', newdir);
    save(nome, 'outburst_spikes_cell');
    
    
    cd(peakfolder);
end

set(gca,'YTick',1:60);
set(gca,'YTickLabel',channels);
xlabel('Time(s)');
ylabel('Channels');
title('Detected bursts: SAFR method');
close(h);

close(f2);



