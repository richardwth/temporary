function tonicChannels=removeTonic()

fs = 10000;
rPeriod = 250; %ms
rPeriod = fs*rPeriod/1000;

folder = uigetdir(pwd);
cd(folder);
list = dir('*');
cd(list(3).name);
list = dir('*PeakDetectionMAT*');
cd(list(1).name);
list = dir('*ptrain*');
cd(list(1).name);
list = dir('*ptrain*.mat');

normalFR = zeros(length(list),1);
tonicFR = zeros(length(list),1);
for i=1:length(list)
   load(list(i).name);
   spikes = find(peak_train);   
   normalFR(i) = length(spikes)/length(peak_train);
   
      f = figure();
plot(spikes,ones(length(spikes),1),'.');
hold on
   %%remove spikes
   count=1;
   while count<length(spikes)
       inds = find(spikes>spikes(count) & spikes<spikes(count)+rPeriod);
       spikes(inds)=[];
       count = count+1;
   end
   
   tonicFR(i) = length(spikes)/length(peak_train);
   plot(spikes,2*ones(length(spikes),1),'.');
   ylim([0,5]);
   close(f);
end


plot(normalFR,tonicFR,'+');
