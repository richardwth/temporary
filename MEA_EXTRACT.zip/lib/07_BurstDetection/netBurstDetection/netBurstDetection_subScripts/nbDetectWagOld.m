function [NBursts, NBurstsPattern] = nbDetectWagOld(path,fs,removeOutliers)

warning('off','all');

%% initialize parameters
channels = getMEA60Channels();

scrsz = get(0,'ScreenSize');


%% load the burst detection file
cd(path);

BDfiles = dirr(path);
fileName = BDfiles(1).name;
load(fileName);

%% get all the bursts of all channels into BDTrains
burstEl = find(~cellfun('isempty', burst_detection_cell));
BDTrains = [];
burstDurations = [];

for k = 1:length(burstEl)
    BDcurElec = burst_detection_cell{burstEl(k)};
    NumBcurElec = size(BDcurElec,1);
    BDTrains = [BDTrains; burstEl(k)*ones(NumBcurElec,1) BDcurElec(:,[1,2,7,8,9])];
    BDTrains = BDTrains(1:end-1,:);
    if ~isempty(BDcurElec)
        burstDurations = vertcat(burstDurations,BDcurElec(1:end-1,4)*fs);
        
    end
end

if ~isempty(BDTrains)
    
  
    
    %% get the starts of net bursts
    BDTrainsSorted = sortrows(BDTrains,2);
    
    NBFirstBurst = [];
    NBLastBurst = [];
    
    if ~isempty(BDTrainsSorted)
        NBFirstBurst = 1;
        NBLastBurst = 1;
        for k = 2:size(BDTrainsSorted,1)
            lastBurstEnd = max(BDTrainsSorted(NBFirstBurst(end):NBLastBurst(end),3));
            if BDTrainsSorted(k,2)>=BDTrainsSorted(NBFirstBurst(end),2) && BDTrainsSorted(k,2)<=lastBurstEnd
                NBLastBurst(end) = k;
            else
                NBFirstBurst = vertcat(NBFirstBurst,k);
                NBLastBurst = vertcat(NBLastBurst,k);
            end
        end
    end
    
    %%Delete net bursts that have less than 2 bursts in them
    numBursts = NBLastBurst-NBFirstBurst;
    NBFirstBurst(find(numBursts<2))=[];
    NBLastBurst(find(numBursts<2))=[];
    
    %%Separating merged network bursts
    NBFirstBurstSep = [];
    NBLastBurstSep = [];
    for k = 1:length(NBFirstBurst)
         f = figure();
        voidParamTh = 0.7;
        burstStarts = BDTrainsSorted(NBFirstBurst(k):NBLastBurst(k),2);
        burstEnds = BDTrainsSorted(NBFirstBurst(k):NBLastBurst(k),3);
        minStart = min(burstStarts);
        maxEnd = max(burstEnds);
        simBursts = zeros(maxEnd-minStart+1,1);
        
        for j=1:length(burstStarts);
            simBursts(burstStarts(j)-minStart+1:burstEnds(j)-minStart+1) = simBursts(burstStarts(j)-minStart+1:burstEnds(j)-minStart+1)+1;
        end
        
        simBursts = smooth(simBursts,round(fs/10),'lowess');
         plot(simBursts);
         hold on
        
        [vals,pos] = findpeaks(simBursts,'minpeakdistance',ceil(length(simBursts)/10),'minpeakheight',5);
          scatter(pos,vals,'markerfacecolor','green');
        
        if length(vals)>1
            
            numOfSecondPeaks = length(vals)-1;
            sepInds = 0; % take 0 as the starting point to seperate bursts
        
            for j = 1:numOfSecondPeaks
   
                    [yMin,tempIdxMin] = min(simBursts(pos(j):pos(j+1)));
                    
                        sepInds = [sepInds;tempIdxMin+pos(j)-1];
                        
            end
            
            
            sepInds = [sepInds;length(simBursts)]; %add the last index as the ending point to separate bursts
            
              scatter(sepInds,zeros(length(sepInds),1),'markerfacecolor','red');
            
            sepInds = minStart+sepInds;
            sepInds = [1;sepInds;length(simBursts)];
            
            for j=1:length(sepInds)-1
                firstBurst = NBFirstBurst(k)+find(burstStarts<sepInds(j+1) & burstStarts>=sepInds(j),1)-1;
                lastBurst = NBFirstBurst(k)+find(burstStarts<sepInds(j+1) & burstStarts>=sepInds(j),1,'last')-1;
                NBFirstBurstSep = [NBFirstBurstSep;firstBurst];
                NBLastBurstSep = [NBLastBurstSep;lastBurst];
            end
        else
            NBFirstBurstSep = [NBFirstBurstSep;NBFirstBurst(k)];
            NBLastBurstSep = [NBLastBurstSep;NBLastBurst(k)];
        end
        
          close(f);
    end
    
    NBFirstBurst = NBFirstBurstSep;
    NBLastBurst = NBLastBurstSep;
 
    
    %% Initilaize figure
    f = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
    ylim([0,60]);
    hold on
    
    %% draw bursts
    for k = 1:length(burstEl)
        BDcurElec = BDTrains(find(BDTrains(:,1)==burstEl(k)),:);
        
        for i=1:size(BDcurElec)-1
            percentileX = [BDcurElec(i,2),BDcurElec(i,3)]/fs;
            chanNo = find(channels==burstEl(k));
            threshPercY = [chanNo chanNo];
            line(percentileX,threshPercY,'lineWidth',2);
        end
    end
    
    numNB = length(NBFirstBurst);
    numActElec = zeros(numNB,1);
    totBurstSize = zeros(numNB,1);
    avgPeakSize = zeros(numNB,1);
    noOfSpikesInBurst = zeros(numNB,1);
    
    
    %% gather all bursts whose starts or end fall within a given net burst start-end into that net burst
    for i = 1:numNB
        % list of bursting electrodes (in the i-th NB)
        actElec = unique(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),1));
        % counts number of active electrodes
        numActElec(i) = length(actElec);
        
        totBurstSize(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),4));
        avgPeakSize(i) = mean(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),5));
        noOfSpikesInBurst(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),6));
    end
    
    %% group bursts into network bursts
    numElecTh = 10;
    NB2save = numActElec>=numElecTh;
    newNBFirstBurst = NBFirstBurst(NB2save);
    newNBLastBurst = NBLastBurst(NB2save);
    newNumNB = length(newNBFirstBurst);
    newNumActElec = numActElec(NB2save);
    newTotBurstSize = totBurstSize(NB2save);
    newAvgPeakSize= avgPeakSize(NB2save);
    newNoOfSpikesInBurst= noOfSpikesInBurst(NB2save);
    
    NB = zeros(newNumNB,8);
    NBpattern = cell(newNumNB,1);
    for jj = 1:newNumNB
        burstBegin = BDTrainsSorted(newNBFirstBurst(jj),2);
        burstEnd = max(BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),3));
        if jj ~= newNumNB
            succBurstBegin = BDTrainsSorted(newNBFirstBurst(jj+1),2);
            if burstEnd >= succBurstBegin
                burstEnd = succBurstBegin-1;
            end
        end
        NB(jj,1:4) = [burstBegin, ... % ts of the begin of the first burst [samples]
            burstEnd, ...  % ts of the end of the longest burst [samples]
            newNBLastBurst(jj)-newNBFirstBurst(jj)+1,...        % number of bursts
            burstEnd-burstBegin]; % duration [samples]
        NB(jj,5) = newNumActElec(jj);
        NB(jj,6) = newTotBurstSize(jj); %sum of all peak amplitudes within burst
        NB(jj,7) = newAvgPeakSize(jj); % average peak size in the burst
        NB(jj,8) = newTotBurstSize(jj)/(burstEnd-burstBegin); % average amplitude during the burst
        
        NB(jj,9) = newNoOfSpikesInBurst(jj); % average amplitude during the burst
        NBpattern{jj} = BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),1:2);
    end
    
    
    
    
    NBursts = {NB};
    NBurstsPattern = {NBpattern};
    
    nbMarkerHeight = 0.4;
    for i=1:size(NB,1)
        percentileX = [NB(i,1), NB(i,2)]/fs;
        threshPercY = [nbMarkerHeight nbMarkerHeight];
        line(percentileX,threshPercY,'Color','red','lineWidth',2);
        line([NB(i,1) NB(i,1)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
        line([NB(i,2) NB(i,2)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
    end
    
    
    set(gca,'YTick',1:60);
    set(gca,'YTickLabel',channels);
    xlabel('Time(s)');
    ylabel('Channel');
    
    close(f);
else
    NB = [];
    NBpattern = [];
    NBursts = {NB};
    NBurstsPattern = {NBpattern};
    
    
end

warning('on','all');
