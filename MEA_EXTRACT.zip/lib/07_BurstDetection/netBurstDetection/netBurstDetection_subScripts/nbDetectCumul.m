function [NBursts, NBurstsPattern] = nbDetectCumul(path,channelPercentage,fs)
%function to find network bursts depending on the optimum intra-NB interval

%% initialize parameters
channels = getMEA60Channels();

scrsz = get(0,'ScreenSize');
%f = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);


%% load the burst detection file
cd(path);

BDfiles = dirr(path);
fileName = BDfiles(1).name;
load(fileName);

%% get all the bursts of all channels into BDTrains
burstEl = find(~cellfun('isempty', burst_detection_cell));
activeChannels = length(burstEl); %length(find(isActiveChannel==1));
BDTrains = [];
burstDurations = [];

noOfBurstChans = 0;
h = waitbar(0,'Removing outlier bursts...');

for k = 1:length(burstEl)
    BDcurElec = burst_detection_cell{burstEl(k)};
    NumBcurElec = size(BDcurElec,1);
    BDTrains = [BDTrains; burstEl(k)*ones(NumBcurElec,1) BDcurElec(:,[1,2,3,7,8,9])];
    BDTrains = BDTrains(1:end-1,:);
    if ~isempty(BDcurElec)
        burstDurations = vertcat(burstDurations,BDcurElec(1:end-1,4)*fs);
        noOfBurstChans = noOfBurstChans + 1;
    end
end

numElecTh = max([3,noOfBurstChans*channelPercentage]);

if ~isempty(BDTrains)
    maxBurstDuration = prctile(burstDurations,99);%percentileX(end)
    validBursts = find((BDTrains(:,3)-BDTrains(:,2))<maxBurstDuration);
    BDTrains = BDTrains(validBursts,:);
end

if ~isempty(BDTrains)
    
    %% find threshold number of channels
    numElecTh = activeChannels*channelPercentage;
    
    %% get the starts and ends of net bursts
    BDTrainsSorted = sortrows(BDTrains,2);
    bdStarts = BDTrainsSorted(:,2);
    
    counts = zeros(length(bdStarts),1);
    
    minIbiThresh = 50;
    ibiThresh = minIbiThresh; %increasing in 1ms intervals
    
    %     ibiThreshs = [];
    %     countMat = [];
    %     a=0;
    %     b=0;
    %     decayThresh = 0;
    %     modeThresh = 0;
    waitbar(0.1,h,'Finding optimum intra-network burst interval');
    while ibiThresh<1000
        disp(ibiThresh);
        ibiThresh = ibiThresh+5;
        NBLastBurst = zeros(length(bdStarts),1);
        prevCounts = counts;
        counts = zeros(length(bdStarts),1);
        
        for i=1:length(bdStarts)
            diffs = bdStarts(i+1:end)-bdStarts(i);
            withinThresh = find(diffs<=ibiThresh*fs/1000);
            if ~isempty(withinThresh)
                count = max(withinThresh);
            else
                count = 0;
            end
            NBLastBurst(i) = i+count; %horzcat(NBLastBurst,i+count-1);
            counts(i) = count;
            
        end
        
        
        diffCounts =prctile(counts-prevCounts,95); %%earlier it was MEAN
        %diffCounts = mean(diffCounts)+3*std(diffCounts);
        %         ibiThreshs = [ibiThreshs;ibiThresh];
        %         countMat = [countMat;[diffCounts,mode(counts)]];
        
        
        if prctile(counts,1)>=1 %&& a==0
            %         modeThresh = ibiThresh;
            %         a=1;
            break
        elseif ibiThresh > minIbiThresh && max(counts)>5
            if diffCounts < 1 %&& b==0
                %decayThres = ibiThresh;
                %b=1;
                break
            end
        end
        
    end
    
    if ibiThresh ~= 1000
        ibiThresh = ibiThresh-5;
    end
    
    
    
    %    disp(ibiThresh);
    %
    %     f2 = figure();
    %     subplot(2,1,1);
    %     stem(ibiThreshs,countMat(:,1));
    %     hold on
    %     if decayThresh ~= 0
    %     scatter(decayThresh,0,'markerfacecolor','red');
    %     end
    %     subplot(2,1,2);
    %     stem(ibiThreshs,countMat(:,2));
    %     hold on
    %     if modeThresh ~=0
    %     scatter(modeThresh,0,'markerfacecolor','red');
    %     end
    %     close(f2);
    %
    
    counts = zeros(length(bdStarts),1);
    NBFirstBurst = [];
    NBLastBurst = [];
    %%Get the correct counts for the chose ibi thresh
    for i=1:length(bdStarts)
        count = 1;
        while count>0 && (i+count)<=length(bdStarts)
            if (bdStarts(i+count)-bdStarts(i))<ibiThresh*fs/1000
                count=count+1;
            else
                break
            end
        end
        NBFirstBurst = horzcat(NBFirstBurst,i);
        NBLastBurst = horzcat(NBLastBurst,i+count-1);
        counts(i) = count-1;
        %ibei = [ibei;prctile(diff(bdStarts(i:i+count-1)),90)];
    end
    
    %     plot(bdStarts/fs,counts);
    %     hold on
    
    %% finding peaks in the burst counts, counts has the burstCount when the NB starts from a given burst
    
    if nnz(counts)>0
        
        waitbar(0.5,h,'Gather bursts into network bursts');
        
        %% Gather bursts to peaks on different levels
        levels = sort(unique(counts),'descend');
        assigned = [];
        nbStore = [];
        
        for k=1:length(levels)-1
            %get the peaks of this level
            peak = levels(k);
            starts = find(counts==peak);
            
            for j=1:length(starts)
                % if the burst has not already been assigned
                if ismember(starts(j),assigned)==0
                    includedBursts = starts(j):starts(j)+peak;
                    
                    %if any of the bursts captured in its count are not assigned
                    if nnz(ismember(includedBursts,assigned))<=0
                        nbStore = vertcat(nbStore,[NBFirstBurst(starts(j)),NBLastBurst(starts(j)),peak]);
                        
                        assigned = horzcat(assigned,includedBursts);
                        assigned = unique(assigned);
                        
                        %scatter(bdStarts(starts(j))/fs,peak,'markerfacecolor','green');
                        
                    end
                end
            end
        end
        
        nbStore = sortrows(nbStore,1);
        %%Filter valid burst starts and ends
        NBFirstBurst = nbStore(:,1);
        NBLastBurst = nbStore(:,2);
        
        
        %close(f);
        
        %%Delete net bursts that have lower than half the no of channels in them
        numBursts = NBLastBurst-NBFirstBurst;
        
        NBFirstBurst(numBursts<numElecTh*0.5)=[];
        NBLastBurst(numBursts<numElecTh*0.5)=[];
        
        waitbar(0.7,h,'Adding pre/post bursts');
        
        %Add bursts that start or end within a NB but not assigned to any other NB
        %and not spanning any other NB
        %good to catch prebursts
        assignedBursts = [];
        for i=1:length(NBFirstBurst)
            
            
            %%ends in the NB or spans NB
            if i>1
                bdIndices = find((BDTrainsSorted(NBFirstBurst(i),2)-BDTrainsSorted(NBLastBurst(i-1)+1:NBFirstBurst(i)-1,3))<0); % & (BDTrainsSorted(NBLastBurst(i-1)+1:NBFirstBurst(i)-1,2)-BDTrainsSorted(NBFirstBurst(i),2))<ibiThresh); % & (burstEnd-BDTrainsSorted(1:NBFirstBurst(i)-1,3))<0);
                bdIndices = bdIndices + NBLastBurst(i-1);
                
                if ~isempty(bdIndices)
                    bdIndices = bdIndices(~ismember(bdIndices,assignedBursts));
                    if ~isempty(bdIndices)
                        NBFirstBurst(i) = bdIndices(1);
                    end
                end
            end
            
            %starts in the NB
            if i<length(NBFirstBurst)
                
                burstEnds = BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),3);
                
                burstEnds(burstEnds>=BDTrainsSorted(NBFirstBurst(i+1),2)) = [];
                burstEnd = max(burstEnds);
                
                if ~isempty(burstEnd)
                    % if a start of a burst falls after the start of the NB and before
                    % the end of the NB, where the end is defined as the last end
                    bdIndices = find((BDTrainsSorted(NBFirstBurst(i),2)-BDTrainsSorted(NBLastBurst(i)+1:NBFirstBurst(i+1),2))<0 & ...
                        (burstEnd-BDTrainsSorted(NBLastBurst(i)+1:NBFirstBurst(i+1),2))>0);
                    
                    if ~isempty(bdIndices)
                        NBLastBurst(i) = NBLastBurst(i)+bdIndices(end);
                    end
                end
            end
            
            assignedBursts = [assignedBursts,NBFirstBurst(i):NBLastBurst(i)];
        end
        
        
        waitbar(0.8,h,'Merging network bursts');
        
        %% Merge netbursts that have more than 20% of bursts spanning across the latter
        numNB = length(NBFirstBurst);
        
        if numNB>1
            NBFirstBurstMerged = NBFirstBurst(1);
            NBLastBurstMerged = NBLastBurst(1);
            
            for i = 2:numNB
                
                %         disp(sprintf('%d %d',NBFirstBurst(i),NBLastBurst(i)));
                %         disp(sprintf('%d %d',NBFirstBurstMerged(end),NBLastBurstMerged(end)));
                
                prevBurstChans = BDTrainsSorted(NBFirstBurstMerged(end):NBLastBurstMerged(end),1);
                %  prevBurstStarts = BDTrainsSorted(NBFirstBurstMerged(end):NBLastBurstMerged(end),2);
                prevBurstEnds = BDTrainsSorted(NBFirstBurstMerged(end):NBLastBurstMerged(end),3);
                uniqueChans1 = unique(prevBurstChans);
                for t=1:length(prevBurstChans)
                    prevBurstChans(t) = find(channels==prevBurstChans(t));
                end
                count = 0;
                
                % overlapChans = [];
                for j=1:length(prevBurstEnds)
                    if prevBurstEnds(j)>BDTrainsSorted(NBFirstBurst(i),2)
                        % disp(sprintf('%f %f',prevBurstEnds(j),BDTrainsSorted(NBFirstBurst(i),2)));
                        count = count+1;
                        % overlapChans = [overlapChans;prevBurstChans(j)];
                        % line([prevBurstStarts(j),prevBurstEnds(j)]./fs,[prevBurstChans(j),prevBurstChans(j)],'color','red');
                    end
                end
                
                uniqueChans2 = unique(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),1));
                
                if ((count/length(uniqueChans1))>0.5 || (count/length(uniqueChans2))>0.5) && (length(uniqueChans1)/length(uniqueChans2)>=2 || length(uniqueChans2)/length(uniqueChans1)>=2) %&& count>=noOfBurstChans*0.1
                    NBLastBurstMerged(end) = NBLastBurst(i);
                    lastBurstEnd = max(BDTrainsSorted(NBFirstBurstMerged(end):NBLastBurstMerged(end),3));
                    line([BDTrainsSorted(NBFirstBurstMerged(end),2),lastBurstEnd]./fs,[0.75,0.75],'color','red');
                else
                    NBFirstBurstMerged = vertcat(NBFirstBurstMerged,NBFirstBurst(i));
                    NBLastBurstMerged = vertcat(NBLastBurstMerged,NBLastBurst(i));
                end
            end
            
            NBFirstBurst = NBFirstBurstMerged;
            NBLastBurst = NBLastBurstMerged;
            clear 'NBFirstBurstMerged', 'NBLastBurstMerged';
        end
        
        numNB = length(NBFirstBurst);
        numActElec = zeros(numNB,1);
        totBurstSize = zeros(numNB,1);
        totAmplitude = zeros(numNB,1);
        avgPeakAmplitude = zeros(numNB,1);
        avgAmplitude = zeros(numNB,1);
        
        waitbar(0.9,h,'Saving network bursts');
        
        %% gather all bursts whose starts or end fall within a given net burst start-end into that net burst
        for i = 1:numNB
            % list of bursting electrodes (in the i-th NB)
            actElec = unique(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),1));
            % counts number of active electrodes
            numActElec(i) = length(actElec);
            
            totBurstSize(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),4)); %total number of spikes included in the NB (only the ones inside bursts are considered
            totAmplitude(i) = mean(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),5)); %sum of the amplitudes of all peaks
            avgPeakAmplitude(i) = mean(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),6)); %mean of the avg peak amplitudes in all bursts
            avgAmplitude(i) = mean(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),7)); % mean of the durational avg amplitude of all bursts
        end
        
        %% group bursts into network bursts
        
        NB2save = numActElec>=numElecTh;
        newNBFirstBurst = NBFirstBurst(NB2save);
        newNBLastBurst = NBLastBurst(NB2save);
        newNumNB = length(newNBFirstBurst);
        newNumActElec = numActElec(NB2save);
        newTotBurstSize = totBurstSize(NB2save);
        newTotAmp = totAmplitude(NB2save);
        newAvgPeakAmp = avgPeakAmplitude(NB2save);
        newAvgAmp = avgAmplitude(NB2save);
        
        NB = zeros(newNumNB,8);
        NBpattern = cell(newNumNB,1);
        for jj = 1:newNumNB
            burstBegin = BDTrainsSorted(newNBFirstBurst(jj),2);
            burstEnd = max(BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),3));
            if jj ~= newNumNB
                succBurstBegin = BDTrainsSorted(newNBFirstBurst(jj+1),2);
                if burstEnd >= succBurstBegin
                    burstEnd = succBurstBegin-1;
                end
            end
            NB(jj,1:4) = [burstBegin, ... % ts of the begin of the first burst [samples]
                burstEnd, ...  % ts of the end of the longest burst [samples]
                newNBLastBurst(jj)-newNBFirstBurst(jj)+1,...        % number of bursts
                burstEnd-burstBegin]; % duration [samples]
            NB(jj,5) = newNumActElec(jj);
            NB(jj,6) = newTotBurstSize(jj); %total number of spikes
            NB(jj,7) = newTotAmp(jj); % sum of all amplitudes
            NB(jj,8) = newAvgPeakAmp(jj); % average amplitude per peak
            NB(jj,9) = newAvgAmp(jj); % average amplitude per duration
            NBpattern{jj} = BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),1:3);
        end
        
        %%find global bursts
        noOfChannels = NB(:,5);
        bins = 1:max(noOfChannels);
        counts = histc(noOfChannels,bins);
        counts = smooth(counts,5);
        [~,pos] = min(counts(max([1,floor(max(noOfChannels)*0.4)]):floor(max(noOfChannels)*0.9)));
        globalThresh = min([floor(max(noOfChannels)*0.4)+pos,0.6*max(noOfChannels)]);
        
        globals = find(noOfChannels>=globalThresh);
        localsTails = find(noOfChannels<globalThresh);
        
        NB = [NB,zeros(size(NB,1),2)]; %%column 10 - global burst or not, 11 - tail or not
        NB(globals,10) = 1;
        
        %%label local bursts vs tails
        for i=1:length(localsTails)
            if localsTails(i) ~= 1
                startOfTail = NB(localsTails(i),1);
                endOfPrevNB = NB(localsTails(i)-1,2);
                if (NB(localsTails(i)-1,10) == 1 && startOfTail-endOfPrevNB < 2) || (NB(localsTails(i)-1,11) == 1 && startOfTail-endOfPrevNB < 2)
                    NB(localsTails(i),11) = 1;
                end
            end
        end
        
        close(h);
        
        %% Initilaize figure
        f = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
        ylim([0,60]);
        hold on
        
        %% draw bursts
        for k = 1:length(burstEl)
            BDcurElec = BDTrains(find(BDTrains(:,1)==burstEl(k)),:);
            
            for i=1:size(BDcurElec)-1
                percentileX = [BDcurElec(i,2),BDcurElec(i,3)]/fs;
                chanNo = find(channels==burstEl(k));
                threshPercY = [chanNo chanNo];
                line(percentileX,threshPercY,'lineWidth',2);
            end
        end
        
        %draw NBs
        NBursts = {NB};
        NBurstsPattern = {NBpattern};
        
        nbMarkerHeight = 0.4;
        for i=1:size(NB,1)
            percentileX = [NB(i,1), NB(i,2)]/fs;
            threshPercY = [nbMarkerHeight nbMarkerHeight];
            if NB(i,10)==1
                line(percentileX,threshPercY,'Color','red','lineWidth',2);
                line([NB(i,1) NB(i,1)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
                line([NB(i,2) NB(i,2)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
            elseif NB(i,10)==0 && NB(i,11) ==1
                line(percentileX,threshPercY,'Color','black','lineWidth',2);
                line([NB(i,1) NB(i,1)]/fs,[0 nbMarkerHeight],'Color','black','lineWidth',3);
                line([NB(i,2) NB(i,2)]/fs,[0 nbMarkerHeight],'Color','black','lineWidth',3);
            else
                line(percentileX,threshPercY,'Color','green','lineWidth',2);
                line([NB(i,1) NB(i,1)]/fs,[0 nbMarkerHeight],'Color','green','lineWidth',3);
                line([NB(i,2) NB(i,2)]/fs,[0 nbMarkerHeight],'Color','green','lineWidth',3);
            end
        end
        
        set(gca,'YTick',1:60);
        set(gca,'YTickLabel',channels);
        xlabel('Time(s)');
        ylabel('Channels');
        title('Network burst detection: Cumulative bursts method');
        
        %close(f);
    else
        NB = [];
        NBpattern = [];
        NBursts = {NB};
        NBurstsPattern = {NBpattern};
    end
    
else
    NB = [];
    NBpattern = [];
    NBursts = {NB};
    NBurstsPattern = {NBpattern};
    
end


