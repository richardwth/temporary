function [NBursts, NBurstsPattern] = netBurstDetectionVanPeltOld(pathPeakFile,fs,recordingTime,binWidth,mergeInt)

%%Initialize variables

scrsz = get(0,'ScreenSize');
channels = getMEA60Channels();
binWidth = binWidth*fs/1000;


%% Go into the spike detection folder
cd(pathPeakFile);

list = dir('*');
cd(list(3).name);

list = dir('*ptrain*.mat');
noOfChannels = length(list);

totalSamples = recordingTime*fs;
noOfBins = floor(totalSamples/binWidth);

%% Create spike-count time bins
spikeCountBins = zeros(noOfBins,1);
channelCountBins = zeros(noOfBins,1);
for k = 1:noOfChannels
    fileName = list(k).name;
    load(fileName);
    
    timestamps = find(peak_train);
    bins = floor(timestamps/binWidth)+1;
    
    for i=1:length(bins)
        if bins(i)<length(spikeCountBins)
            spikeCountBins(bins(i))=spikeCountBins(bins(i))+1;
        end
    end
    
    uniqueBins = unique(bins);
    for i=1:length(uniqueBins)
        if uniqueBins(i)<length(channelCountBins)
            channelCountBins(uniqueBins(i))=channelCountBins(uniqueBins(i))+1;
        end
    end
end

clear 'peak_train';

productBins = spikeCountBins.*channelCountBins;

f = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
hold on
x=0:binWidth/fs:totalSamples/fs;
plot(x(2:end),productBins);
grid minor
answer = inputdlg({'Cutoff threshold'},'Threshold Selection',1,{'50'});
threshold = str2double(answer{1});
  
nbStartTimes =  (find(diff([0;productBins>threshold])==1)-1)*binWidth;
nbStartTimes(nbStartTimes==0)=1;
nbEndTimes = find(diff([0;productBins>threshold])==-1)*binWidth;
nbEndTimes(nbEndTimes==0)=1;

%%Merge NBs within 2s
nbStartsMerged = nbStartTimes(1);
nbEndsMerged = nbEndTimes(1);

mergeInt = mergeInt*fs/1000;
count=2;
while count<length(nbStartTimes)
    thisEnd = nbEndsMerged(end);
    nbsAdjInds = find((nbStartTimes-thisEnd)<=mergeInt & (nbStartTimes-thisEnd)>=0);
    if ~isempty(nbsAdjInds)
        maxEnd = max(nbEndTimes(nbsAdjInds));
        nbEndsMerged(end) = maxEnd;  
    else
        nbStartsMerged = vertcat(nbStartsMerged,nbStartTimes(count));
        nbEndsMerged = vertcat(nbEndsMerged,nbEndTimes(count));  
    end
    count = count+length(nbsAdjInds)+1;
end

nbStartTimes = nbStartsMerged;
nbEndTimes = nbEndsMerged;
clear 'nbStartsMerged', 'nbEndsMerged';

%%Remove 0 duration NBs
removeInds = find(nbEndTimes==nbStartTimes);
nbStartTimes(removeInds)=[];
nbEndTimes(removeInds)=[];


scatter(nbStartTimes/fs,productBins(ceil(nbStartTimes/binWidth)),'markerfacecolor','green');
scatter(nbEndTimes/fs,productBins(ceil(nbEndTimes/binWidth)),'markerfacecolor','red');
close(f);

channelCountStarts = ceil(nbStartTimes/binWidth);
channelCountEnds= ceil(nbEndTimes/binWidth);
channelCounts = zeros(length(channelCountStarts),1);
for i = 1:length(channelCountStarts)
channelCounts(i) = max(channelCountBins(channelCountStarts(i):channelCountEnds(i)));
end

%%start burst detection section
%% load burst detection file
% cd(pathBurstFile);
% 
% BDfiles = dirr(pathBurstFile);
% fileName = BDfiles(1).name;
% load(fileName);
% 
% %% get all the bursts of all channels into BDTrains and draw the bursts
% burstEl = find(~cellfun('isempty', burst_detection_cell));
% activeChannels = length(find(isActiveChannel==1));
% BDTrains = [];
%  
% %%Initialize figure
% f2 = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
% ylim([0,60]);
% hold on
% 
%  %% Draw bursts
% for k = 1:length(burstEl)
%     BDcurElec = burst_detection_cell{burstEl(k)};
%     NumBcurElec = size(BDcurElec,1);
%     BDTrains = [BDTrains; burstEl(k)*ones(NumBcurElec,1) BDcurElec(:,[1,2,7,8,9])];
%     BDTrains = BDTrains(1:end-1,:);
%     for i=1:size(BDcurElec)-1
%         x = [BDcurElec(i,1),BDcurElec(i,2)]/fs;
%         chanNo = find(channels==burstEl(k));
%         y = [chanNo chanNo];
%         line(x,y,'lineWidth',2);
%     end
% end


numNB = length(nbStartTimes);
numActElec = zeros(numNB,1);
totBurstSize = zeros(numNB,1);
avgPeakSize = zeros(numNB,1);
noOfSpikesInBurst = zeros(numNB,1);


%% gather all bursts that span a netBurst peak to that network burst
for i = 1:numNB   
 
    % counts number of active electrodes
    numActElec(i) = channelCounts(i);
    
%     totBurstSize(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),4));
%     avgPeakSize(i) = mean(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),5));
%     noOfSpikesInBurst(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),6));
end




%% group bursts into network bursts
NB = zeros(numNB,8);
NBpattern = cell(numNB,1);
for jj = 1:numNB  
    NB(jj,1:4) = [nbStartTimes(jj), ... % ts of the begin of the first burst [samples]
        nbEndTimes(jj), ...  % ts of the end of the longest burst [samples]
        0,...        % number of bursts
        nbEndTimes(jj)-nbStartTimes(jj)]; % duration [samples]
    NB(jj,5) = numActElec(jj);
%     NB(jj,6) = newTotBurstSize(jj); %sum of all peak amplitudes within burst
%     NB(jj,7) = newAvgPeakSize(jj); % average peak size in the burst
%     NB(jj,8) = newTotBurstSize(jj)/(burstEnd-burstBegin); % average amplitude during the burst
%     NB(jj,9) = newNoOfSpikesInBurst(jj); % average amplitude during the burst
%    NBpattern{jj} = BDTrainsSorted(nbStartTimes(jj):nbEndTimes(jj),1:2);
end

% nbMarkerHeight = 0.4;
% for i=1:size(NB,1)
%     x = [NB(i,1), NB(i,2)]/fs;
%     y = [nbMarkerHeight nbMarkerHeight];
%     line(x,y,'Color','red','lineWidth',2);
%     line([NB(i,1) NB(i,1)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
%     line([NB(i,2) NB(i,2)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
% end
% set(gca,'YTick',1:60);
% set(gca,'YTickLabel',channels);

NBPattern = [];
NBursts = {NB};
NBurstsPattern = {NBpattern};


%close(f2);
