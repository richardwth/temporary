function [NBursts, NBurstsPattern] = nbDetectCumul4(path,maxIBI,channelPercentage,variability,fs,removeOutliers)
%%Finds an ibi thresh and then does the same thing as logibei method

%% initialize parameters
channels = getMEA60Channels();

scrsz = get(0,'ScreenSize');
f = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);


%% load the burst detection file
cd(path);

BDfiles = dirr(path);
fileName = BDfiles(1).name;
load(fileName);

%% get all the bursts of all channels into BDTrains
burstEl = find(~cellfun('isempty', burst_detection_cell));
activeChannels = length(burstEl); %length(find(isActiveChannel==1));
BDTrains = [];
burstDurations = [];

for k = 1:length(burstEl)
    BDcurElec = burst_detection_cell{burstEl(k)};
    NumBcurElec = size(BDcurElec,1);
    BDTrains = [BDTrains; burstEl(k)*ones(NumBcurElec,1) BDcurElec(:,[1,2,7,8,9])];
    BDTrains = BDTrains(1:end-1,:);
    if ~isempty(BDcurElec)
        burstDurations = vertcat(burstDurations,BDcurElec(1:end-1,4)*fs);
        
    end
end

%% select bursts that are within the valid burst duration
if removeOutliers==1
    percentileX = 1:100;
    threshs = prctile(burstDurations,percentileX);
    [p,S] = polyfit(percentileX(1:95),threshs(1:95),5);
    [threshPercY,delta] = polyval(p,percentileX,S);
    outliers = abs(threshs - threshPercY) > 2*std(threshPercY);
    percentileX(outliers)=[];
    %     stem(threshs);
    %     hold on
    %     plot(threshPercY,'r','linewidth',2);
    %     scatter(percentileX(end),0,'markerfacecolor','red');
    maxBurstDuration = prctile(burstDurations,percentileX(end));
    validBursts = find((BDTrains(:,3)-BDTrains(:,2))<maxBurstDuration);
    BDTrains = BDTrains(validBursts,:);
end

%% find threshold number of channels
numElecTh = activeChannels*channelPercentage;

%% get the starts and ends of net bursts
BDTrainsSorted = sortrows(BDTrains,2);
bdStarts = BDTrainsSorted(:,2);

NBFirstBurst = [];
NBLastBurst = [];
counts = [];

ibiThreshs = 5:5:maxIBI;

countMat = zeros(length(ibiThreshs),3);

ibiThresh = 0; %increasing in 1ms intervals
j = 0;
ibei = 0;

while ibiThresh<maxIBI
    ibiThresh = ibiThresh+100;
    NBFirstBurst = [];
    NBLastBurst = [];
    largestIBI = [];
        
    counts = zeros(length(bdStarts),1);
    for i=1:length(bdStarts)
        count = 1;
        while count>0 && (i+count)<=length(bdStarts)
            if (bdStarts(i+count)-bdStarts(i))<ibiThresh*fs/1000
                count=count+1;
            else
                break
            end
        end
        NBFirstBurst = horzcat(NBFirstBurst,i);
        NBLastBurst = horzcat(NBLastBurst,i+count-1);
        tempStarts = bdStarts(i:i+count-1);
        ibis = diff(tempStarts);
        largestIBI = horzcat(largestIBI,max(ibis));
        
        counts(i) = count-1;
        ibei = max([ibei,max(diff(bdStarts(i:i+count-1)))]);
    end
    if mode(counts)>=1
        ibiThresh = ibiThresh-100;
        while ibiThresh<maxIBI
            ibiThresh = ibiThresh+10;
            NBFirstBurst = [];
            NBLastBurst = [];
            counts = zeros(length(bdStarts),1);
            for i=1:length(bdStarts)
                count = 1;
                while count>0 && (i+count)<=length(bdStarts)
                    if (bdStarts(i+count)-bdStarts(i))<ibiThresh*fs/1000
                        count=count+1;
                    else
                        break
                    end
                end
                NBFirstBurst = horzcat(NBFirstBurst,i);
                NBLastBurst = horzcat(NBLastBurst,i+count-1);
                tempStarts = bdStarts(i:i+count-1);
                ibis = diff(tempStarts);
                largestIBI = horzcat(largestIBI,max(ibis));
        
                counts(i) = count-1;
                ibei = max([ibei,max(diff(bdStarts(i:i+count-1)))]);
            end
            if mode(counts)>=1
                ibiThresh = ibiThresh-10;
                while ibiThresh<maxIBI
                    ibiThresh = ibiThresh+1;
                    NBFirstBurst = [];
                    NBLastBurst = [];
                    counts = zeros(length(bdStarts),1);
                    for i=1:length(bdStarts)
                        count = 1;
                        while count>0 && (i+count)<=length(bdStarts)
                            if (bdStarts(i+count)-bdStarts(i))<ibiThresh*fs/1000
                                count=count+1;
                            else
                                break
                            end
                        end
                        NBFirstBurst = horzcat(NBFirstBurst,i);
                        NBLastBurst = horzcat(NBLastBurst,i+count-1);
                        tempStarts = bdStarts(i:i+count-1);
                        ibis = diff(tempStarts);
                        largestIBI = horzcat(largestIBI,max(ibis));
        
                        counts(i) = count-1;
                        ibei = max([ibei,max(diff(bdStarts(i:i+count-1)))]);
                    end
                    if mode(counts)>=1
                        break
                    end
                end
                break
            end
        end
        break
    end
    %             j=j+1;
    %             countMat(j,1)=mode(counts);
    %             countMat(j,2)=prctile(counts,50);
    %             countMat(j,3)=max(counts);
end

disp(ibiThresh);
% subplot(1,3,1);
% stem(ibiThreshs,countMat(:,1));
% subplot(1,3,2);
% stem(ibiThreshs,countMat(:,2));
% subplot(1,3,3);
% stem(ibiThreshs,countMat(:,3));


IBeITh_sample = prctile(largestIBI,90);
disp(prctile(largestIBI,90)*1000/fs);


plot(bdStarts/fs,counts);
hold on

%% finding peaks in the burst counts, counts has the burstCount when the NB starts from a given burst
[peakVal,peakLoc]= findpeaks(counts);
scatter(bdStarts(peakLoc)/fs,peakVal,'markerfacecolor','red');

close(f);

%% Initilaize figure
f = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
ylim([0,60]);
hold on

%% draw bursts
for k = 1:length(burstEl)
    BDcurElec = BDTrains(find(BDTrains(:,1)==burstEl(k)),:);
    
    for i=1:size(BDcurElec)-1
        percentileX = [BDcurElec(i,2),BDcurElec(i,3)]/fs;
        chanNo = find(channels==burstEl(k));
        threshPercY = [chanNo chanNo];
        line(percentileX,threshPercY,'lineWidth',2);
    end
end


 NBtrn = [0; diff(bdStarts)<=IBeITh_sample; 0]; % check places where inter burst times are lower than IB threshold --> intra burst, different channels
    NBedges = diff(NBtrn);
    NBFirstBurst = find(NBedges == 1); % get network burst edges
    NBLastBurst = find(NBedges == -1);
    numNB = length(NBFirstBurst); % number of network bursts
    numActElec = zeros(numNB,1);
    totBurstSize = zeros(numNB,1);
    avgPeakSize = zeros(numNB,1);
    noOfSpikesInBurst = zeros(numNB,1);
     
    for i = 1:numNB
        % list of bursting electrodes (in the i-th NB)
        actElec = unique(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),1));
        % counts number of active electrodes
        numActElec(i) = length(actElec);
        
        totBurstSize(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),4));
        avgPeakSize(i) = mean(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),5));
        noOfSpikesInBurst(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),6));
    end


%% group bursts into network bursts

numElecTh = 5;
NB2save = numActElec>=numElecTh;
newNBFirstBurst = NBFirstBurst(NB2save);
newNBLastBurst = NBLastBurst(NB2save);
newNumNB = length(newNBFirstBurst);
newNumActElec = numActElec(NB2save);
newTotBurstSize = totBurstSize(NB2save);
newAvgPeakSize= avgPeakSize(NB2save);
newNoOfSpikesInBurst= noOfSpikesInBurst(NB2save);

NB = zeros(newNumNB,8);
NBpattern = cell(newNumNB,1);
for jj = 1:newNumNB
    burstBegin = BDTrainsSorted(newNBFirstBurst(jj),2);
    burstEnd = max(BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),3));
    if jj ~= newNumNB
        succBurstBegin = BDTrainsSorted(newNBFirstBurst(jj+1),2);
        if burstEnd >= succBurstBegin
            burstEnd = succBurstBegin-1;
        end
    end
    NB(jj,1:4) = [burstBegin, ... % ts of the begin of the first burst [samples]
        burstEnd, ...  % ts of the end of the longest burst [samples]
        newNBLastBurst(jj)-newNBFirstBurst(jj)+1,...        % number of bursts
        burstEnd-burstBegin]; % duration [samples]
    NB(jj,5) = newNumActElec(jj);
    NB(jj,6) = newTotBurstSize(jj); %sum of all peak amplitudes within burst
    NB(jj,7) = newAvgPeakSize(jj); % average peak size in the burst
    NB(jj,8) = newTotBurstSize(jj)/(burstEnd-burstBegin); % average amplitude during the burst
    NB(jj,9) = newNoOfSpikesInBurst(jj); % average amplitude during the burst
    NBpattern{jj} = BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),1:2);
end

NBursts = {NB};
NBurstsPattern = {NBpattern};

nbMarkerHeight = 0.4;
for i=1:size(NB,1)
    percentileX = [NB(i,1), NB(i,2)]/fs;
    threshPercY = [nbMarkerHeight nbMarkerHeight];
    line(percentileX,threshPercY,'Color','red','lineWidth',2);
    line([NB(i,1) NB(i,1)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
    line([NB(i,2) NB(i,2)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
end


set(gca,'YTick',1:60);
set(gca,'YTickLabel',channels);


close(f);

