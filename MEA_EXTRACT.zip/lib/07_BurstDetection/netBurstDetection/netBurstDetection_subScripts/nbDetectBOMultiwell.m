function [NB, NBpattern] = nbDetectBOMultiwell(saveFolder,path,fs,channelPercentage,split, channels,peakfolder)
%nbDetectBOMultiwell Implements the network burst detection using the
%single channel bursts detected earlier. Authored by Dulini Mendis,
%Annotated by Damith Senanayake(2017)
%   nbDetectBO is called by PTSDAutoMultiwell.m to preserve dependencies. Be
%   advised when running separately.


display=0;
warning('off','all');

% initialize parameters


scrsz = get(0,'ScreenSize');

%Read channel labels in the peak folder. 
cd(peakfolder)   
channel_labels=[];

peakDir= pwd;
    peakFiles= dir('*.mat');
    noPeakFiles= length(peakFiles);
    for i= 1:noPeakFiles % FOR cycle on the single directory files
        filename = peakFiles(i).name;    % current PKD file
        channel_labels{i}= filename(end-5:end-4); 
    end
% load the burst detection file from the SC Burst detection
cd(path);

h = waitbar(0,'Removing outlier bursts...');

BDfiles = dirr(path);
fileName = BDfiles(1).name;
load(fileName);

% get all the bursts of all channels into BDTrains
burstEl = find(~cellfun('isempty', burst_detection_cell)); % The channels where bursts are non-empty i.e. a burst happens
BDTrains = [];
burstDurations = []; % stores burst durations for non-empty burst channels
noOfBurstChans = 0; % counts the non-empty burst channels






for k = 1:length(burstEl) % iterate for each channel with a burst : 
    BDcurElec = burst_detection_cell{burstEl(k)}; % extract the burst
    NumBcurElec = size(BDcurElec,1);
    BDTrains = [BDTrains; burstEl(k)*ones(NumBcurElec,1) BDcurElec(:,[1,2,7,8,3])];
    BDTrains = BDTrains(1:end-1,:); % drop the last record
    if ~isempty(BDcurElec)
        burstDurations = vertcat(burstDurations,BDcurElec(1:end-1,4)*fs); % update the burst durations matrix
        noOfBurstChans = noOfBurstChans +1; % update the burst channel counter
    end
end

numElecTh = max([2,floor(noOfBurstChans*channelPercentage)]);

if ~isempty(BDTrains)
    
    % select bursts that are within the valid burst duration
    
    maxBurstDuration = prctile(burstDurations,99);%percentileX(end)
    validBursts = find((BDTrains(:,3)-BDTrains(:,2))<maxBurstDuration);
    BDTrains = BDTrains(validBursts,:);
    
    waitbar(0.1,h,'Gathering bursts into network bursts...');
    
    % get the starts of net bursts
    % since the values extracted from the burst_detection_cell mat file are
    % time instance recordings, sorting the rows at the starting time of
    % the bursts will order the bursts
    BDTrainsSorted = sortrows(BDTrains,2);
    
    NBFirstBurst = [];
    NBLastBurst = [];
    
    if ~isempty(BDTrainsSorted)
        NBFirstBurst = 1;
        NBLastBurst = 1;
        for k = 2:size(BDTrainsSorted,1)
            % find the last time point when a burst ended by getting the
            % maximum of the third column for the range of First Burst to
            % Last Burst
            lastBurstEnd = max(BDTrainsSorted(NBFirstBurst(end):NBLastBurst(end),3));
            
            if BDTrainsSorted(k,2)>=BDTrainsSorted(NBFirstBurst(end),2) && BDTrainsSorted(k,2)<=lastBurstEnd
                % check if the first burst of the current burst is in the interval of the beginning of the first burst, and the newly found last time point when a burst ended
                % if so : record the current burst as where the last burst
                % ended
                NBLastBurst(end) = k;
            else
                % otherwise append the current burst to the first and last
                % burst arrays. By doing this, we identify the network
                % burst. 
                NBFirstBurst = vertcat(NBFirstBurst,k);
                NBLastBurst = vertcat(NBLastBurst,k);
            end
        end
    end
    % By this point NBFirstBurst is an array of starting
    % burst(indices) of each network burst. And the NBLastBurst contains
    % the ending burst of each such network burst. Example 
    %   NBFirstBurst = [1 2 3 7 12 . . .]
    %   NBLastBurst  = [1 2 6 10 . . . ]
    % This means that the first network burst only contains the very first
    % single channel burst. The Second one also the same. The third one,
    % however begins at the third single channel burst and ends at the
    % sixth. The fourth network burst begins at the 7th single channel
    % burst and ends at the tenth and so on...
    
    
    %Delete net bursts that have less than 2 or half times the number of electrode threshold, bursts in them
    numBursts = NBLastBurst-NBFirstBurst+1; % difference gives the number of bursts in a network burst
    NBFirstBurst(find(numBursts<max(0.5*numElecTh,2)))=[];
    NBLastBurst(find(numBursts<max(0.5*numElecTh,2)))=[];
    
    waitbar(0.2,h,'Splitting network bursts');
      
        
    if split ==1
        %Separating merged network bursts
        NBFirstBurstSep = [];
        NBLastBurstSep = [];
        NBBegin = [];
        NBEnd = [];
        for k = 1:length(NBFirstBurst)
            %for each detected burst in the previous step
            waitbar(0.2+(0.8-0.2)*k/length(NBFirstBurst),h,'Splitting network bursts');
            
            voidParamTh = 0.75;
            try
                % get the beginnings of each burst
                burstStarts = BDTrainsSorted(NBFirstBurst(k):NBLastBurst(k),2);
            catch
                disp();
            end
            
            % get the ends of each burst
            burstEnds = BDTrainsSorted(NBFirstBurst(k):NBLastBurst(k),3);
            
            minStart = min(burstStarts);
            
            [maxEnd,maxEndBurst] = max(burstEnds);
            
            % simBursts calculates the number of simultaneous bursts at
            % each time point
            simBursts = zeros(maxEnd-minStart+1,1);
            
            for j=1:length(burstStarts);
                simBursts(burstStarts(j)-minStart+1:burstEnds(j)-minStart+1) = simBursts(burstStarts(j)-minStart+1:burstEnds(j)-minStart+1)+1;
            end
            
            if length(burstStarts)>1 %otherwise a single flat burst line becomes jagged because of smoothing
                simBursts = smooth(simBursts,round(fs/25),'lowess');
            end
            
            % find the local peak network burst activity
            [vals,pos] = findpeaks([0;simBursts;0],'minpeakdistance',ceil(length(simBursts)/10),'minpeakheight', max([0.2*max(simBursts),numElecTh*0.5]));
            pos = pos-1;
            
            if display==1
                f=figure();
                plot(simBursts);
                hold on
                scatter(pos,vals,'markerfacecolor','green');
                xlabel('Time (s)');
                ylabel('No. of simultaneous bursts');
            end
            % if there are more than one peak of network (simultaneous
            % bursts)
            if length(vals)>1
                
                numOfSecondPeaks = length(vals)-1;
                sepInds = 1; % take 0 as the starting point to seperate bursts
                
                j = 1;
                while  j<=numOfSecondPeaks
                    % do for each secondary peak 
                    y1 = vals(j);
                    found = 0;
                    for m=j+1:length(vals)
                        % for each subsequent peak y2:
                        y2 = vals(m);
                        [yMin,tempIdxMin] = min(simBursts(pos(j):pos(m)));
                        % the void parameter is a measure of the degree of separation
                        % between the two peaks through the minimum
                        voidParameter = 1-(yMin/sqrt(y1.*y2));
                        if voidParameter>=voidParamTh
                            sepInds = [sepInds;tempIdxMin+pos(j)-1];
                            found = 1;
                            % discontinue loop if a separable peak is found
                            break;
                        end
                    end
                    if found==1
                        j=m;
                    else
                        j=j+1;
                    end
                end
                
                % sepInds now contains the indices where each peak of
                % network bursts is separable
                sepInds = [sepInds;length(simBursts)]; %add the last index as the ending point to separate bursts
                
                if display==1
                    scatter(sepInds,zeros(length(sepInds),1),'markerfacecolor','red');
                end
                
                sepIndsInSB = sepInds;
                sepInds = minStart+sepInds;
                %sepInds = [1;sepInds;length(simBursts)];
                
                for j=1:length(sepInds)-1
                    % We now separate the multiple bursts
                    NBBegin = [NBBegin;sepInds(j)];
                    
                    NBEnd = [NBEnd;sepInds(j+1)];
                    
                    firstBurst = NBFirstBurst(k)+find(burstStarts<sepInds(j+1) & burstStarts>=sepInds(j),1)-1;
                    lastBurst = NBFirstBurst(k)+find(burstStarts<sepInds(j+1) & burstStarts>=sepInds(j),1,'last')-1;
                    NBFirstBurstSep = [NBFirstBurstSep;firstBurst];
                    NBLastBurstSep = [NBLastBurstSep;lastBurst];
                    
                    BDTrainsSorted(firstBurst,2) = NBBegin(end);
                    
                    burstEnds = BDTrainsSorted(firstBurst:lastBurst,3);
                    [maxEnd,maxEndBurst] = max(burstEnds);
                    BDTrainsSorted(firstBurst-1+maxEndBurst,3) = NBEnd(end);
                    
                end
            elseif length(vals)==1
                % If only one peak is found
                NBBegin = [NBBegin;minStart];
                NBEnd = [NBEnd;maxEnd];
                
                NBFirstBurstSep = [NBFirstBurstSep;NBFirstBurst(k)];
                NBLastBurstSep = [NBLastBurstSep;NBLastBurst(k)];
                
                if display==1
                    scatter([1,length(simBursts)],zeros(2,1),'markerfacecolor','red');
                end
            end
            
            if display==1
                ticks = get(gca,'XTick');
                set(gca,'XTickLabels',ticks./fs);
                close(f);
            end            
           
        end
        % once separator indices are found we assign them for burst
        % delimiters
         NBFirstBurst = NBFirstBurstSep;
         NBLastBurst = NBLastBurstSep;
    else
        
        NBBegin = zeros(length(NBFirstBurst),1);
        NBEnd = zeros(length(NBFirstBurst),1);
        
        for k = 1:length(NBFirstBurst)
            burstStarts = BDTrainsSorted(NBFirstBurst(k):NBLastBurst(k),2);
            burstEnds = BDTrainsSorted(NBFirstBurst(k):NBLastBurst(k),3);
            
            minStart = min(burstStarts);
            [maxEnd,maxEndBurst] = max(burstEnds);
            
            NBBegin(k) = minStart;
            NBEnd(k) = maxEnd;
            
        end    
               
    end
       
    waitbar(0.9,h,'Saving network bursts');
    
    numNB = length(NBFirstBurst);
    numActElec = zeros(numNB,1);
    totBurstSize = zeros(numNB,1);
    avgPeakSize = zeros(numNB,1);
    noOfSpikesInBurst = zeros(numNB,1);
    
    
    % gather all bursts whose starts or end fall within a given net burst start-end into that net burst
    for i = 1:numNB
        % list of bursting electrodes (in the i-th NB)
        actElec = unique(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),1));
        % counts number of active electrodes
        numActElec(i) = length(actElec);
        
        totBurstSize(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),4));
        avgPeakSize(i) = mean(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),5));
        noOfSpikesInBurst(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),6));
    end
    
    % group bursts into network bursts
    
    NB2save = numActElec>=numElecTh;
    % Extract only those with the number of active electrodes higher than
    % the active electrode threshold
    newNBFirstBurst = NBFirstBurst(NB2save);
    newNBLastBurst = NBLastBurst(NB2save);
    newNumNB = length(newNBFirstBurst);
    newNumActElec = numActElec(NB2save);
    newTotBurstSize = totBurstSize(NB2save);
    newAvgPeakSize= avgPeakSize(NB2save);
    newNoOfSpikesInBurst= noOfSpikesInBurst(NB2save);
    
    NBBegin = NBBegin(NB2save);
    NBEnd = NBEnd(NB2save);
    
    NB = zeros(newNumNB,8);
    NBpattern = cell(newNumNB,1);
    
    
    for jj = 1:newNumNB
        burstBegin = NBBegin(jj); % = BDTrainsSorted(newNBFirstBurst(jj),2);
        burstEnd = NBEnd(jj); % = max(BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),3));
        if jj ~= newNumNB
            succBurstBegin = BDTrainsSorted(newNBFirstBurst(jj+1),2);
            if burstEnd >= succBurstBegin
                burstEnd = succBurstBegin-1;
            end
        end
        NB(jj,1:4) = [burstBegin, ... % ts of the begin of the first burst [samples]
            burstEnd, ...  % ts of the end of the longest burst [samples]
            newNBLastBurst(jj)-newNBFirstBurst(jj)+1,...        % number of bursts
            burstEnd-burstBegin]; % duration [samples]
        NB(jj,5) = newNumActElec(jj);
        NB(jj,6) = newTotBurstSize(jj); %sum of all peak amplitudes within burst
        NB(jj,7) = newAvgPeakSize(jj); % average peak size in the burst
        NB(jj,8) = newTotBurstSize(jj)/(burstEnd-burstBegin); % average amplitude during the burst
        
        NB(jj,9) = newNoOfSpikesInBurst(jj); % total number of spikes during the burst
        NBpattern{jj} = BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),1:3);
    end
    
    
    
    % Initilaize figure
    f = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
    ylim([0,12]);
    hold on
    
    % draw bursts
    for k = 1:length(burstEl)
        BDcurElec = BDTrains(find(BDTrains(:,1)==burstEl(k)),:);
        
        for i=1:size(BDcurElec)-1
            percentileX = [BDcurElec(i,2),BDcurElec(i,3)]/fs;
            %Match burstEL(k) against the channels vector, this is trickier
            %when extending to single well, as the channel labels are not
            %integers, but String, hence the burstEl(k) which refer to the
            %index of channels with non empty bursts is compared against the channel
            %labels vector.
            chanNo = find([channels{:}] ==channel_labels(burstEl(k)));
            if (~isempty(chanNo))
            threshPercY = [chanNo chanNo];
            line(percentileX,threshPercY,'lineWidth',2);
            end
        end
    end
    
    nbMarkerHeight = 0.4;
    for i=1:size(NB,1)
        percentileX = [NB(i,1), NB(i,2)]/fs;
        threshPercY = [nbMarkerHeight nbMarkerHeight];
        line(percentileX,threshPercY,'Color','red','lineWidth',2);
        line([NB(i,1) NB(i,1)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
        line([NB(i,2) NB(i,2)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
        
    end
    
    
    set(gca,'YTick',1:12);
    set(gca,'YTickLabel',channels);
    xlabel('Time(s)');
    ylabel('Channels');
    title('Network burst detection: Burst overlap method');
    
    close(f);
else
    NB = [];
    NBpattern = [];
    
    
end

close(h);

warning('on','all');

netBursts = NB;
        netBurstsPattern = NBpattern;
        fileName = fullfile(saveFolder,['NetworkBurstDetection.mat']);
        save(fileName,'netBursts','netBurstsPattern','-mat');
