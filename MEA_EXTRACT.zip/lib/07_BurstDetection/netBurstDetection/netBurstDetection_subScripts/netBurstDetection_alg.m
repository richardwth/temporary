function [NB, NBpattern] = netBurstDetection_alg(BDTrains, IBeITh, numElecTh, userParam)
% BDTrains:
% 1st col: elec number
% 2nd col: burst init ([sample])
% 3rd col: burst end([sample])
% sorting bursts in chronological order


fs = 10000;
    
%Drawing bursts
scrsz = get(0,'ScreenSize');

channels = [12:17,21:28,31:38,41:48,51:58,61:68,71:78,82:87];


if ~isempty(BDTrains) && size(BDTrains,1)>0
    
    f = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
ylim([0,60]);
hold on

burstEl = unique(BDTrains(:,1));

for k = 1:length(burstEl)
    ind = find(BDTrains(:,1)==burstEl(k));
    BDcurElec = BDTrains(ind,:);
 for i=1:size(BDcurElec,1)
    x = [BDcurElec(i,2),BDcurElec(i,3)]/fs;
    chanNo = find(channels==burstEl(k));
    y = [chanNo chanNo];
    line(x,y,'lineWidth',2);
 end
end
    
if (~isempty(BDTrains))
    BDTrainsSorted = sortrows(BDTrains,2); % sort by burst start time
    
   
    tsBE = BDTrainsSorted(:,2); % start of bursts
    % %%%%%%%
    if IBeITh(1,2) %-- commented by DULINI
        IBeITh_sample = round(userParam.IBeIThDef/1000*userParam.sf);%round(IBeITh(1,1)/1000*userParam.sf);
    else
        IBeITh_sample = round(userParam.IBeIThDef/1000*userParam.sf);
    end
    
    disp(IBeITh_sample*1000/userParam.sf);
    % %%%%%%%%%%%%
    NBtrn = [0; diff(tsBE)<=IBeITh_sample; 0]; % check places where inter burst times are lower than IB threshold --> intra burst, different channels
    NBedges = diff(NBtrn);
    NBFirstBurst = find(NBedges == 1); % get network burst edges
    NBLastBurst = find(NBedges == -1);
    numNB = length(NBFirstBurst); % number of network bursts
    numActElec = zeros(numNB,1);
    totBurstSize = zeros(numNB,1);
    avgPeakSize = zeros(numNB,1);
    noOfSpikesInBurst = zeros(numNB,1);
     
    for i = 1:numNB
        % list of bursting electrodes (in the i-th NB)
        actElec = unique(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),1));
        % counts number of active electrodes
        numActElec(i) = length(actElec);
        
        totBurstSize(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),4));
        avgPeakSize(i) = mean(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),5));
        noOfSpikesInBurst(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),6));
    end
    numElecTh = max([3,numElecTh]);
    NB2save = numActElec>=numElecTh;
    newNBFirstBurst = NBFirstBurst(NB2save);
    newNBLastBurst = NBLastBurst(NB2save);
    newNumNB = length(newNBFirstBurst);
    newNumActElec = numActElec(NB2save);
    newTotBurstSize = totBurstSize(NB2save);
    newAvgPeakSize= avgPeakSize(NB2save);
    newNoOfSpikesInBurst= noOfSpikesInBurst(NB2save);
    
    NB = zeros(newNumNB,8);
    NBpattern = cell(newNumNB,1);
    for jj = 1:newNumNB
        burstBegin = BDTrainsSorted(newNBFirstBurst(jj),2);
        burstEnd = max(BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),3));
        if jj ~= newNumNB
            succBurstBegin = BDTrainsSorted(newNBFirstBurst(jj+1),2);
            if burstEnd >= succBurstBegin
                burstEnd = succBurstBegin-1;
            end
        end
        NB(jj,1:4) = [burstBegin, ... % ts of the begin of the first burst [samples]
            burstEnd, ...  % ts of the end of the longest burst [samples]
            newNBLastBurst(jj)-newNBFirstBurst(jj)+1,...        % number of bursts
            burstEnd-burstBegin]; % duration [samples]
        NB(jj,5) = newNumActElec(jj);
        NB(jj,6) = newTotBurstSize(jj); %sum of all peak amplitudes within burst
        NB(jj,7) = newAvgPeakSize(jj); % average peak size in the burst
        NB(jj,8) = newTotBurstSize(jj)/(burstEnd-burstBegin); % average amplitude during the burst
        NB(jj,9) = newNoOfSpikesInBurst(jj); % average amplitude during the burst
        NBpattern{jj} = BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),1:2);
    end
else
    NB = [];
    NBpattern = [];
end

nbMarkerHeight = 0.4;
for i=1:size(NB,1)
    x = [NB(i,1), NB(i,2)]/fs;
    y = [nbMarkerHeight nbMarkerHeight];
    line(x,y,'Color','red','lineWidth',2);
    line([NB(i,1) NB(i,1)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',2);
    line([NB(i,2) NB(i,2)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',2);
end
set(gca,'YTick',1:60);
set(gca,'YTickLabel',channels);
xlabel('Time(s)');
ylabel('Channel');
close(f);

else
    NB = [];
    NBpattern = [];
end

