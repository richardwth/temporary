function [NBursts, NBurstsPattern] = netBurstDetectionVanPelt(pathPeakFile,pathBurstFile,fs,recordingTime,binWidth,ibiThresh,channelPercentage,detectionPercentage)

%%Initialize variables

scrsz = get(0,'ScreenSize');
channels = getMEA60Channels();
binWidth = binWidth*fs/1000;
ibiThresh = ibiThresh*fs/1000;

%% Go into the spike detection folder
cd(pathPeakFile);

list = dir('*');
cd(list(3).name);

list = dir('*ptrain*.mat');
noOfChannels = length(list);


totalSamples = recordingTime*fs;
noOfBins = floor(totalSamples/binWidth);

%% Create spike-count time bins
spikeCountBins = zeros(noOfBins,1);
channelCountBins = zeros(noOfBins,1);
for k = 1:noOfChannels
    fileName = list(k).name;
    load(fileName);
    
    timestamps = find(peak_train);
    bins = floor(timestamps/binWidth)+1;
    
    for i=1:length(bins)
        if bins(i)<length(spikeCountBins)
            spikeCountBins(bins(i))=spikeCountBins(bins(i))+1;
        end
    end
    
    uniqueBins = unique(bins);
    for i=1:length(uniqueBins)
        if uniqueBins(i)<length(channelCountBins)
            channelCountBins(uniqueBins(i))=channelCountBins(uniqueBins(i))+1;
        end
    end
end

clear 'peak_train';


productBins = spikeCountBins.*channelCountBins;
productBins = (productBins-min(productBins))./(max(productBins)-min(productBins));

[peakVal,peakLoc]= findpeaks(productBins,'minpeakheight',0.1);

peakThresh = 0.1;
truePeakInd = find(peakVal>peakThresh);

validNBCenters = peakLoc(truePeakInd);


%% If there are nearby peaks<ibiThresh remove the smaller peaks
% turns = [0;diff(validNBCenters)<ibiThresh;0];
% edges = diff(turns);
% ups = find(edges==1);
% downs=find(edges==-1);
% nbToRemove = [];
% for i=1:length(ups)
%     [val,ind] = max(productBins(validNBCenters(ups(i):downs(i))));
%     toRemove = ups(i):downs(i);
%     toRemove(ind) = [];
%     nbToRemove = horzcat(nbToRemove,toRemove);
% end
% validNBCenters(nbToRemove) = [];

f = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
hold on
x=0:binWidth/fs:totalSamples/fs;
plot(x(2:end),productBins);
scatter(peakLoc*binWidth/fs,peakVal,'markerfacecolor','red');
scatter(validNBCenters*binWidth/fs,productBins(validNBCenters),'markerfacecolor','green');

close(f);

f = figure();
percentiles = zeros(100,1);
for k=1:100
    percentiles(k) = prctile(productBins,k);
end

stem(percentiles);
close(f);

validNBCenters = validNBCenters*binWidth-binWidth/2;

%%start burst detection section
%% load burst detection file
cd(pathBurstFile);

BDfiles = dirr(pathBurstFile);
fileName = BDfiles(1).name;
load(fileName);

%% get all the bursts of all channels into BDTrains and draw the bursts
burstEl = find(~cellfun('isempty', burst_detection_cell));
activeChannels = length(find(isActiveChannel==1));
BDTrains = [];
 
%%Initialize figure
f2 = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
ylim([0,60]);
hold on

 %% Draw bursts
burstDurations = [];
for k = 1:length(burstEl)
    BDcurElec = burst_detection_cell{burstEl(k)};
    NumBcurElec = size(BDcurElec,1);
    BDTrains = [BDTrains; burstEl(k)*ones(NumBcurElec,1) BDcurElec(:,[1,2,7,8,9])];
    BDTrains = BDTrains(1:end-1,:);
    for i=1:size(BDcurElec)-1
        x = [BDcurElec(i,1),BDcurElec(i,2)]/fs;
        chanNo = find(channels==burstEl(k));
        y = [chanNo chanNo];
        line(x,y,'lineWidth',2);
    end
     if ~isempty(BDcurElec)
        burstDurations = vertcat(burstDurations,BDcurElec(:,4)*fs);
    end
end


%Remove outlier bursts
percentileX = 1:100;
    threshs = prctile(burstDurations,percentileX);
    [p,S] = polyfit(percentileX(1:95),threshs(1:95),5);
    threshPercY = polyval(p,percentileX,S);
    outliers = abs(threshs - threshPercY) > 1.5*std(threshPercY);  
    percentileX(outliers)=[];   
    maxBurstDuration = prctile(burstDurations,percentileX(end));
    validBursts = find((BDTrains(:,3)-BDTrains(:,2))<maxBurstDuration);
    BDTrains = BDTrains(validBursts,:);


%% Sort bursts by start time
BDTrainsSorted = sortrows(BDTrains,2);

numNB = length(validNBCenters);
NBFirstBurst = zeros(numNB,1);
NBLastBurst = zeros(numNB,1);
previousIndices = [];

%%Find starting and ending bursts for each NB
for i = 1:numNB
    bdIndices = find(BDTrainsSorted(:,2) < validNBCenters(i) & BDTrainsSorted(:,3) > validNBCenters(i));
   
    %if previous bursts are spanning across this netBurst, remove them
    ism = ~ismember(bdIndices,previousIndices);
    previousIndices = unique(vertcat(previousIndices,bdIndices));
    bdIndices = bdIndices(find(ism));
    
    if ~isempty(bdIndices)
     NBFirstBurst(i) = bdIndices(1);
        NBLastBurst(i) = bdIndices(end);
    else
         NBFirstBurst(i) = NaN;
         NBLastBurst(i) = NaN;
    end
end

NBFirstBurst(isnan(NBFirstBurst)) = [];
NBLastBurst(isnan(NBLastBurst)) = [];

 %% Join netBursts with starts<ibiThresh
if numel(NBFirstBurst)>0
    nbFirst = NBFirstBurst(1);
    nbLast = NBLastBurst(1);   
       
    for i=2:length(NBFirstBurst)
        if (BDTrainsSorted(NBFirstBurst(i),2)-BDTrainsSorted(nbLast(end),2))<ibiThresh
            nbLast(end) = NBLastBurst(i);
        else
            nbFirst = vertcat(nbFirst,NBFirstBurst(i));
            nbLast = vertcat(nbLast,NBLastBurst(i));
        end
    end
    
    NBFirstBurst = nbFirst;
    NBLastBurst = nbLast;
    clear 'nbFirst', 'nbLast';
end

%% Merge netbursts that have more than 5% of bursts are spanning across the latter
numNB = length(NBFirstBurst);

if numNB>1
NBFirstBurstMerged = NBFirstBurst(1);
NBLastBurstMerged = NBLastBurst(1);

for i = 2:numNB
    prevBurstEnds = BDTrainsSorted(NBFirstBurstMerged(end):NBLastBurstMerged(end),3);
    count = 0;
    for j=1:length(prevBurstEnds)
        if prevBurstEnds(j)>BDTrainsSorted(NBFirstBurst(i),2)
            count = count+1;
        end
    end
    if (count/length(prevBurstEnds))>0.05
        NBLastBurstMerged(end) = NBLastBurst(i);     
    else
        NBFirstBurstMerged = vertcat(NBFirstBurstMerged,NBFirstBurst(i));
        NBLastBurstMerged = vertcat(NBLastBurstMerged,NBLastBurst(i));
    end
end

NBFirstBurst = NBFirstBurstMerged;
NBLastBurst = NBLastBurstMerged;
clear 'NBFirstBurstMerged', 'NBLastBurstMerged';
end

numNB = length(NBFirstBurst);
numActElec = zeros(numNB,1);
totBurstSize = zeros(numNB,1);
avgPeakSize = zeros(numNB,1);
noOfSpikesInBurst = zeros(numNB,1);


%% gather all bursts that span a netBurst peak to that network burst
for i = 1:numNB    
    % list of bursting electrodes (in the i-th NB)
    actElec = unique(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),1));
    % counts number of active electrodes
    numActElec(i) = length(actElec);
    
    totBurstSize(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),4));
    avgPeakSize(i) = mean(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),5));
    noOfSpikesInBurst(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),6));
end



%% find threshold number of channels

numElecTh = activeChannels*channelPercentage;

%% group bursts into network bursts
NB2save = numActElec>=numElecTh;
newNBFirstBurst = NBFirstBurst(NB2save);
newNBLastBurst = NBLastBurst(NB2save);
newNumNB = length(newNBFirstBurst);
newNumActElec = numActElec(NB2save);
newTotBurstSize = totBurstSize(NB2save);
newAvgPeakSize= avgPeakSize(NB2save);
newNoOfSpikesInBurst= noOfSpikesInBurst(NB2save);

NB = zeros(newNumNB,8);
NBpattern = cell(newNumNB,1);
for jj = 1:newNumNB
    burstBegin = BDTrainsSorted(newNBFirstBurst(jj),2);
    burstEnd = max(BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),3));
    if jj ~= newNumNB
        succBurstBegin = BDTrainsSorted(newNBFirstBurst(jj+1),2);
        if burstEnd >= succBurstBegin
            burstEnd = succBurstBegin-1;
        end
    end
    NB(jj,1:4) = [burstBegin, ... % ts of the begin of the first burst [samples]
        burstEnd, ...  % ts of the end of the longest burst [samples]
        newNBLastBurst(jj)-newNBFirstBurst(jj)+1,...        % number of bursts
        burstEnd-burstBegin]; % duration [samples]
    NB(jj,5) = newNumActElec(jj);
    NB(jj,6) = newTotBurstSize(jj); %sum of all peak amplitudes within burst
    NB(jj,7) = newAvgPeakSize(jj); % average peak size in the burst
    NB(jj,8) = newTotBurstSize(jj)/(burstEnd-burstBegin); % average amplitude during the burst
    NB(jj,9) = newNoOfSpikesInBurst(jj); % average amplitude during the burst
    NBpattern{jj} = BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),1:2);
end

nbMarkerHeight = 0.4;
for i=1:size(NB,1)
    x = [NB(i,1), NB(i,2)]/fs;
    y = [nbMarkerHeight nbMarkerHeight];
    line(x,y,'Color','red','lineWidth',2);
    line([NB(i,1) NB(i,1)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
    line([NB(i,2) NB(i,2)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
end

%plot(validNBCenters/fs,0.2,'+g');

NBursts = {NB};
NBurstsPattern = {NBpattern};
 set(gca,'YTick',1:60);
    set(gca,'YTickLabel',channels);
close(f2);
