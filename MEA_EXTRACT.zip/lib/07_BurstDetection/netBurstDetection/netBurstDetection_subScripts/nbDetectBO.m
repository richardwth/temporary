function [NBursts, NBurstsPattern] = nbDetectBO(saveFolder,path,fs,channelPercentage)

display=0;
warning('off','all');

%% initialize parameters
channels = getMEA60Channels();

scrsz = get(0,'ScreenSize');


%% load the burst detection file
cd(path);

h = waitbar(0,'Removing outlier bursts...');

BDfiles = dirr(path);
fileName = BDfiles(1).name;
load(fileName);

%% get all the bursts of all channels into BDTrains
burstEl = find(~cellfun('isempty', burst_detection_cell));
BDTrains = [];
burstDurations = [];
noOfBurstChans = 0;



for k = 1:length(burstEl)
    BDcurElec = burst_detection_cell{burstEl(k)};
    NumBcurElec = size(BDcurElec,1);
    BDTrains = [BDTrains; burstEl(k)*ones(NumBcurElec,1) BDcurElec(:,[1,2,7,8,3])];
    BDTrains = BDTrains(1:end-1,:);
    if ~isempty(BDcurElec)
        burstDurations = vertcat(burstDurations,BDcurElec(1:end-1,4)*fs);
        noOfBurstChans = noOfBurstChans +1;
    end
end

numElecTh = max([3,floor(noOfBurstChans*channelPercentage)]);
 
if ~isempty(BDTrains)
    
    %% select bursts that are within the valid burst duration
    
        maxBurstDuration = prctile(burstDurations,99);%percentileX(end)
        validBursts = find((BDTrains(:,3)-BDTrains(:,2))<maxBurstDuration);
        BDTrains = BDTrains(validBursts,:);
    
 waitbar(0.1,h,'Gathering bursts into network bursts...');   
    
    %% get the starts of net bursts
    BDTrainsSorted = sortrows(BDTrains,2);
    
    NBFirstBurst = [];
    NBLastBurst = [];
    
    if ~isempty(BDTrainsSorted)
        NBFirstBurst = 1;
        NBLastBurst = 1;
        for k = 2:size(BDTrainsSorted,1)
            lastBurstEnd = max(BDTrainsSorted(NBFirstBurst(end):NBLastBurst(end),3));
            if BDTrainsSorted(k,2)>=BDTrainsSorted(NBFirstBurst(end),2) && BDTrainsSorted(k,2)<=lastBurstEnd
                NBLastBurst(end) = k;
            else
                NBFirstBurst = vertcat(NBFirstBurst,k);
                NBLastBurst = vertcat(NBLastBurst,k);
            end
        end
    end
    
    %%Delete net bursts that have less than 2 bursts in them
    numBursts = NBLastBurst-NBFirstBurst;
    NBFirstBurst(find(numBursts<0.5*numElecTh))=[];
    NBLastBurst(find(numBursts<0.5*numElecTh))=[];
    
    waitbar(0.2,h,'Splitting network bursts');
    
    %%Separating merged network bursts
    NBFirstBurstSep = [];
    NBLastBurstSep = [];
    NBBegin = [];
    NBEnd = [];
    for k = 1:length(NBFirstBurst)
        
        waitbar(0.2+(0.8-0.2)*k/length(NBFirstBurst),h,'Splitting network bursts');
                
        voidParamTh = 0.75;
        burstStarts = BDTrainsSorted(NBFirstBurst(k):NBLastBurst(k),2);
        burstEnds = BDTrainsSorted(NBFirstBurst(k):NBLastBurst(k),3);
        minStart = min(burstStarts);

        [maxEnd,maxEndBurst] = max(burstEnds);
        simBursts = zeros(maxEnd-minStart+1,1);
        
        for j=1:length(burstStarts);
            simBursts(burstStarts(j)-minStart+1:burstEnds(j)-minStart+1) = simBursts(burstStarts(j)-minStart+1:burstEnds(j)-minStart+1)+1;
        end
        
        simBursts = smooth(simBursts,round(fs/25),'lowess');
        
        [vals,pos] = findpeaks([0;simBursts;0],'minpeakdistance',ceil(length(simBursts)/10),'minpeakheight', max([0.2*max(simBursts),numElecTh*0.5]));
        pos = pos-1;
        
         if display==1
        f=figure();
        plot(simBursts);
        hold on
        scatter(pos,vals,'markerfacecolor','green');
        xlabel('Time (s)');
        ylabel('No. of simultaneous bursts');
         end
        
        if length(vals)>1
            
            numOfSecondPeaks = length(vals)-1;
            sepInds = 1; % take 0 as the starting point to seperate bursts
            
            j = 1;
            while  j<=numOfSecondPeaks
                y1 = vals(j);
                found = 0;
                for m=j+1:length(vals)
                    y2 = vals(m);
                    [yMin,tempIdxMin] = min(simBursts(pos(j):pos(m)));
                    % the void parameter is a measure of the degree of separation
                    % between the two peaks through the minimum
                    voidParameter = 1-(yMin/sqrt(y1.*y2));
                    if voidParameter>=voidParamTh
                        sepInds = [sepInds;tempIdxMin+pos(j)-1];
                        found = 1;
                        break;
                    end
                end
                if found==1
                    j=m;
                else
                    j=j+1;
                end
            end
            
            
            sepInds = [sepInds;length(simBursts)]; %add the last index as the ending point to separate bursts
            
            if display==1
            scatter(sepInds,zeros(length(sepInds),1),'markerfacecolor','red');
            end
            
            sepIndsInSB = sepInds;
            sepInds = minStart+sepInds;
            %sepInds = [1;sepInds;length(simBursts)];
            
            for j=1:length(sepInds)-1
                edges = diff([0;simBursts(sepIndsInSB(j):sepIndsInSB(j+1))>=2;0]);
                starts = find(edges==1);
                ends = find(edges==-1);
             if ~isempty(starts)
                NBBegin = [NBBegin;sepInds(j)+starts(1)];                
             else
                 NBBegin = [NBBegin;sepInds(j)];
             end
             if ~isempty(ends)
                NBEnd = [NBEnd;sepInds(j)+ends(end)];               
             else
                NBEnd = [NBEnd;sepInds(j+1)];
             end
                firstBurst = NBFirstBurst(k)+find(burstStarts<sepInds(j+1) & burstStarts>=sepInds(j),1)-1;
                lastBurst = NBFirstBurst(k)+find(burstStarts<sepInds(j+1) & burstStarts>=sepInds(j),1,'last')-1;
                NBFirstBurstSep = [NBFirstBurstSep;firstBurst];
                NBLastBurstSep = [NBLastBurstSep;lastBurst];
                
                BDTrainsSorted(firstBurst,2) = NBBegin(end);  
                
                 burstEnds = BDTrainsSorted(firstBurst:lastBurst,3);       
                [maxEnd,maxEndBurst] = max(burstEnds);
                BDTrainsSorted(firstBurst-1+maxEndBurst,3) = NBEnd(end);                
                             
            end
        elseif length(vals)==1
             edges = diff([0;simBursts>=2;0]);
             starts = find(edges==1);
             ends = find(edges==-1);
             if ~isempty(starts) 
                NBBegin = [NBBegin;BDTrainsSorted(NBFirstBurst(k),2)+starts(1)];
                BDTrainsSorted(NBFirstBurst(k),2) = NBBegin(end);   
             else
                 NBBegin = [NBBegin;minStart];
             end
             if ~isempty(ends)                 
                NBEnd = [NBEnd;minStart+ends(end)];
                BDTrainsSorted(NBFirstBurst(k)-1+maxEndBurst,3) = NBEnd(end);
             else
                NBEnd = [NBEnd;maxEnd];
             end
            NBFirstBurstSep = [NBFirstBurstSep;NBFirstBurst(k)];
            NBLastBurstSep = [NBLastBurstSep;NBLastBurst(k)];            
        end
        
        if display==1
            ticks = get(gca,'XTick');
            set(gca,'XTickLabels',ticks./fs);
         close(f);
        end
    end
    
    NBFirstBurst = NBFirstBurstSep;
    NBLastBurst = NBLastBurstSep;
    
    waitbar(0.9,h,'Saving network bursts');
    
    numNB = length(NBFirstBurst);
    numActElec = zeros(numNB,1);
    totBurstSize = zeros(numNB,1);
    avgPeakSize = zeros(numNB,1);
    noOfSpikesInBurst = zeros(numNB,1);
    
    
    %% gather all bursts whose starts or end fall within a given net burst start-end into that net burst
    for i = 1:numNB
        % list of bursting electrodes (in the i-th NB)
        actElec = unique(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),1));
        % counts number of active electrodes
        numActElec(i) = length(actElec);
        
        totBurstSize(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),4));
        avgPeakSize(i) = mean(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),5));
        noOfSpikesInBurst(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),6));
    end
    
    %% group bursts into network bursts
   
    NB2save = numActElec>=numElecTh;
    newNBFirstBurst = NBFirstBurst(NB2save);
    newNBLastBurst = NBLastBurst(NB2save);
    newNumNB = length(newNBFirstBurst);
    newNumActElec = numActElec(NB2save);
    newTotBurstSize = totBurstSize(NB2save);
    newAvgPeakSize= avgPeakSize(NB2save);
    newNoOfSpikesInBurst= noOfSpikesInBurst(NB2save);
    
    NBBegin = NBBegin(NB2save);
    NBEnd = NBEnd(NB2save);
    
    NB = zeros(newNumNB,8);
    NBpattern = cell(newNumNB,1);
    for jj = 1:newNumNB
        burstBegin = NBBegin(jj); %BDTrainsSorted(newNBFirstBurst(jj),2);
        burstEnd = NBEnd(jj); %max(BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),3));
        if jj ~= newNumNB
            succBurstBegin = BDTrainsSorted(newNBFirstBurst(jj+1),2);
            if burstEnd >= succBurstBegin
                burstEnd = succBurstBegin-1;
            end
        end
        NB(jj,1:4) = [burstBegin, ... % ts of the begin of the first burst [samples]
            burstEnd, ...  % ts of the end of the longest burst [samples]
            newNBLastBurst(jj)-newNBFirstBurst(jj)+1,...        % number of bursts
            burstEnd-burstBegin]; % duration [samples]
        NB(jj,5) = newNumActElec(jj);
        NB(jj,6) = newTotBurstSize(jj); %sum of all peak amplitudes within burst
        NB(jj,7) = newAvgPeakSize(jj); % average peak size in the burst
        NB(jj,8) = newTotBurstSize(jj)/(burstEnd-burstBegin); % average amplitude during the burst
        
        NB(jj,9) = newNoOfSpikesInBurst(jj); % total number of spikes during the burst
        NBpattern{jj} = BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),1:3);
    end
    
    
    NBursts = {NB};
    NBurstsPattern = {NBpattern};
    
     %% Initilaize figure
    f = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
    ylim([0,60]);
    hold on
    
    %% draw bursts
    for k = 1:length(burstEl)
        BDcurElec = BDTrains(find(BDTrains(:,1)==burstEl(k)),:);
        
        for i=1:size(BDcurElec)-1
            percentileX = [BDcurElec(i,2),BDcurElec(i,3)]/fs;
            chanNo = find(channels==burstEl(k));
            threshPercY = [chanNo chanNo];
            line(percentileX,threshPercY,'lineWidth',2);
        end
    end
    
    nbMarkerHeight = 0.4;
    for i=1:size(NB,1)
        percentileX = [NB(i,1), NB(i,2)]/fs;
        threshPercY = [nbMarkerHeight nbMarkerHeight];
        line(percentileX,threshPercY,'Color','red','lineWidth',2);
        line([NB(i,1) NB(i,1)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
        line([NB(i,2) NB(i,2)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
    end
    
    
    set(gca,'YTick',1:60);
    set(gca,'YTickLabel',channels);
    xlabel('Time(s)');
    ylabel('Channels');
    title('Network burst detection: Burst overlap method');
    
    close(f);
else
    NB = [];
    NBpattern = [];
    NBursts = {NB};
    NBurstsPattern = {NBpattern};
    
    
end

    close(h);
    
warning('on','all');
netBursts = NB;
        netBurstsPattern = NBpattern;
        fileName = fullfile(saveFolder,['NetworkBurstDetection.mat']);
        save(fileName,'netBursts','netBurstsPattern','-mat');
