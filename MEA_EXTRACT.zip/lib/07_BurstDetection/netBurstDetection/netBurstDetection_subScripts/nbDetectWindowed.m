function [NBursts, NBurstsPattern] = nbDetectWindowed(path,ibiThresh,channelPercentage,fs,totalTime)

%% Initialize parameters
ibiThresh = ibiThresh*fs/1000;
channels = [12:17,21:28,31:38,41:48,51:58,61:68,71:78,82:87];
totalSamples = fs*totalTime;
binWidth = 10; %s
binWidth = binWidth*fs;

%% Initilaize figure
x=0:1/fs:totalSamples/fs;
scrsz = get(0,'ScreenSize');
f = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);

%% load burst detecitno file
cd(path);

BDfiles = dirr(path);
fileName = BDfiles(1).name;
load(fileName);

%%Calculate min active channels
activeChannels = length(find(isActiveChannel==1));
numElecTh = activeChannels*channelPercentage;

%% Create burst matrix with rows as channels and columns as sample times
% need to make this matrix in sections otherwise memory will run out
burstMat = zeros(length(channels),totalSamples);
burstDurations = [];
for i=1:length(channels)
    burstCell = burst_detection_cell{channels(i)}(1:end-1,:);
    for j=1:size(burstCell,1)
        burstMat(i,burstCell(j,1):burstCell(j,2))=1;
    end
    if ~isempty(burstCell)
        burstDurations = vertcat(burstDurations,burstCell(:,4)*fs);
    end
end
maxBurstDuration = prctile(burstDurations,90);

% Sum up all bursts and limit it to the recording time
burstMat = sum(burstMat);
burstMat = burstMat(1:totalSamples);

%% Plot the burst intensities against time
plot(x(1:end-1),burstMat);
hold on


%% find peaks and troughs of the burst intensity profile
% Binning - because local troughs need to be identified
% dataInv = max(burstMat) - burstMat;
% noOfBins = floor(totalSamples/binWidth);
% peakVal = [];
% peakLoc = [];
% minVal = [];
% minLoc = [];
% for i=1:noOfBins
%     [peakValx,peakLocx]= findpeaks(burstMat((i-1)*binWidth+1:i*binWidth));
%     [minValx,minLocx] = findpeaks(dataInv((i-1)*binWidth+1:i*binWidth),'minpeakheight',mode(dataInv((i-1)*binWidth+1:i*binWidth))-1);
%     peakLocx = peakLocx + (i-1)*binWidth;
%     minLocx = minLocx + (i-1)*binWidth;
%     minValx = burstMat(minLocx);
%     peakVal = horzcat(peakVal,peakValx);
%     peakLoc = horzcat(peakLoc,peakLocx);
%     minVal = horzcat(minVal,minValx);
%     minLoc = horzcat(minLoc,minLocx);
%     scatter(peakLoc/fs,peakVal,'markerfacecolor','red');
% scatter(minLoc/fs,minVal,'markerfacecolor','black');
% end

peakThresh = numElecTh*0.9;
[peakVal,peakLoc]= findpeaks(burstMat,'minpeakheight',peakThresh);
scatter(peakLoc/fs,peakVal,'markerfacecolor','red');
%scatter(minLoc/fs,minVal,'markerfacecolor','black');


validNBCenters = peakLoc';

%% If there are nearby peaks<ibiThresh remove the smaller peaks
turns = [0;diff(validNBCenters)<ibiThresh;0];
edges = diff(turns);
ups = find(edges==1);
downs=find(edges==-1);
nbToRemove = [];
for i=1:length(ups)
    [val,ind] = max(burstMat(validNBCenters(ups(i):downs(i))));
    toRemove = ups(i):downs(i);
    toRemove(ind) = [];
    nbToRemove = horzcat(nbToRemove,toRemove);
end
validNBCenters(nbToRemove) = [];

scatter(validNBCenters/fs,burstMat(validNBCenters),'markerfacecolor','green');

close(f);

%% get all the bursts of all channels into BDTrains and draw the bursts
burstEl = find(~cellfun('isempty', burst_detection_cell));

BDTrains = [];

f2 = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
ylim([0,60]);
hold on
for k = 1:length(burstEl)
    BDcurElec = burst_detection_cell{burstEl(k)};
    NumBcurElec = size(BDcurElec,1);
    BDTrains = [BDTrains; burstEl(k)*ones(NumBcurElec,1) BDcurElec(:,[1,2,7,8,9])];
    BDTrains = BDTrains(1:end-1,:);
    for i=1:size(BDcurElec)-1
        x = [BDcurElec(i,1),BDcurElec(i,2)]/fs;
        chanNo = find(channels==burstEl(k));
        y = [chanNo chanNo];
        line(x,y,'lineWidth',2);
    end
end

%% Sort bursts by start time
BDTrainsSorted = sortrows(BDTrains,2);

numNB = length(validNBCenters);
NBFirstBurst = zeros(numNB,1);
NBLastBurst = zeros(numNB,1);
previousIndices = [];

%% select bursts that are within the valid burst duration
validBursts = find((BDTrainsSorted(:,3)-BDTrainsSorted(:,2))<maxBurstDuration);

for i = 1:numNB
    bdIndices = find((BDTrainsSorted(:,2)<=validNBCenters(i)) & (BDTrainsSorted(:,3)>=validNBCenters(i)));
    
    %take out long burst --> wrongly identified
    bdIndices = bdIndices(ismember(bdIndices,validBursts));
    
    %if previous bursts are spanning across this netBurst, remove them
    ism = ~ismember(bdIndices,previousIndices);
    previousIndices = unique(vertcat(previousIndices,bdIndices));
    bdIndices = bdIndices(find(ism));
    
     if ~isempty(bdIndices)
     NBFirstBurst(i) = bdIndices(1);
        NBLastBurst(i) = bdIndices(end);
    else
         NBFirstBurst(i) = NaN;
         NBLastBurst(i) = NaN;
    end
end

NBFirstBurst(isnan(NBFirstBurst)) = [];
NBLastBurst(isnan(NBLastBurst)) = [];

numNB = length(NBFirstBurst);

numActElec = zeros(numNB,1);
totBurstSize = zeros(numNB,1);
avgPeakSize = zeros(numNB,1);
noOfSpikesInBurst = zeros(numNB,1);

%% gather all bursts that span a netBurst peak to that network burst
for i = 1:numNB
    % list of bursting electrodes (in the i-th NB)
    actElec = unique(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),1));
    % counts number of active electrodes
    numActElec(i) = length(actElec);
    
    totBurstSize(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),4));
    avgPeakSize(i) = mean(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),5));
    noOfSpikesInBurst(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),6));
end

%% find threshold number of channels

numElecTh = activeChannels*channelPercentage;

%% group bursts into network bursts
NB2save = numActElec>=numElecTh;
newNBFirstBurst = NBFirstBurst(NB2save);
newNBLastBurst = NBLastBurst(NB2save);
newNumNB = length(newNBFirstBurst);
newNumActElec = numActElec(NB2save);
newTotBurstSize = totBurstSize(NB2save);
newAvgPeakSize= avgPeakSize(NB2save);
newNoOfSpikesInBurst= noOfSpikesInBurst(NB2save);

NB = zeros(newNumNB,8);
NBpattern = cell(newNumNB,1);
for jj = 1:newNumNB
    burstBegin = BDTrainsSorted(newNBFirstBurst(jj),2);
    burstEnd = max(BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),3));
    if jj ~= newNumNB
        succBurstBegin = BDTrainsSorted(newNBFirstBurst(jj+1),2);
        if burstEnd >= succBurstBegin
            burstEnd = succBurstBegin-1;
        end
    end
    NB(jj,1:4) = [burstBegin, ... % ts of the begin of the first burst [samples]
        burstEnd, ...  % ts of the end of the longest burst [samples]
        newNBLastBurst(jj)-newNBFirstBurst(jj)+1,...        % number of bursts
        burstEnd-burstBegin]; % duration [samples]
    NB(jj,5) = newNumActElec(jj);
    NB(jj,6) = newTotBurstSize(jj); %sum of all peak amplitudes within burst
    NB(jj,7) = newAvgPeakSize(jj); % average peak size in the burst
    NB(jj,8) = newTotBurstSize(jj)/(burstEnd-burstBegin); % average amplitude during the burst
    NB(jj,9) = newNoOfSpikesInBurst(jj); % average amplitude during the burst
    NBpattern{jj} = BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),1:2);
end

nbMarkerHeight = 0.4;
for i=1:size(NB,1)
    x = [NB(i,1), NB(i,2)]/fs;
    y = [nbMarkerHeight nbMarkerHeight];
    line(x,y,'Color','red','lineWidth',2);
    line([NB(i,1) NB(i,1)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
    line([NB(i,2) NB(i,2)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
end

NBursts = {NB};
NBurstsPattern = {NBpattern};
 set(gca,'YTick',1:60);
    set(gca,'YTickLabel',channels);
close(f2);





