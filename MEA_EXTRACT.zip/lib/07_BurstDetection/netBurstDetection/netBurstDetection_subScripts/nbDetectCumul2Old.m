function [NBursts, NBurstsPattern] = nbDetectCumul2Old(path,maxIBI,channelPercentage,variability,fs,removeOutliers)

%% initialize parameters
channels = getMEA60Channels();

scrsz = get(0,'ScreenSize');
f = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);


%% load the burst detection file
cd(path);

BDfiles = dirr(path);
fileName = BDfiles(1).name;
load(fileName);

%% get all the bursts of all channels into BDTrains
burstEl = find(~cellfun('isempty', burst_detection_cell));
activeChannels = length(burstEl); %length(find(isActiveChannel==1));
BDTrains = [];
burstDurations = [];

noOfBurstChans = 0;

for k = 1:length(burstEl)
    BDcurElec = burst_detection_cell{burstEl(k)};
    NumBcurElec = size(BDcurElec,1);
    BDTrains = [BDTrains; burstEl(k)*ones(NumBcurElec,1) BDcurElec(:,[1,2,7,8,9])];
    BDTrains = BDTrains(1:end-1,:);
    if ~isempty(BDcurElec)
        burstDurations = vertcat(burstDurations,BDcurElec(1:end-1,4)*fs);
        noOfBurstChans = noOfBurstChans + 1;
    end
end

if ~isempty(BDTrains)
%% select bursts that are within the valid burst duration
if removeOutliers==1
%     percentileX = 1:100;
%     threshs = prctile(burstDurations,percentileX);
%     [p,S] = polyfit(percentileX(1:95),threshs(1:95),6);
%     [threshPercY,delta] = polyval(p,percentileX,S);
%     outliers = abs(threshs - threshPercY) > delta;
%     percentileX(outliers)=[];
%         stem(threshs);
%         hold on
%         plot(threshPercY,'r','linewidth',2);
%         plot(threshPercY+delta,'g','linewidth',2);
%         scatter(percentileX(end),0,'markerfacecolor','red');
    maxBurstDuration = mean(burstDurations)+3*std(burstDurations); %prctile(burstDurations,99);%percentileX(end)
    validBursts = find((BDTrains(:,3)-BDTrains(:,2))<maxBurstDuration);
    BDTrains = BDTrains(validBursts,:);
end

%% find threshold number of channels
numElecTh = activeChannels*channelPercentage;

%% get the starts and ends of net bursts
BDTrainsSorted = sortrows(BDTrains,2);
bdStarts = BDTrainsSorted(:,2);

counts = zeros(length(bdStarts),1);

ibiThreshs = [];
 countMat = [];

minIbiThresh = 50;
ibiThresh = minIbiThresh; %increasing in 1ms intervals


% ibei = 0;
% countStore = [];
% maxIBEI = [];
% 
% a=0;
% b=0;
% 
% decayThresh = 0;
% modeThresh = 0;
while ibiThresh<maxIBI
    disp(ibiThresh);
    ibiThresh = ibiThresh+5;
    NBLastBurst = zeros(length(bdStarts),1);
    prevCounts = counts;
    counts = zeros(length(bdStarts),1);
    %ibei = zeros(length(bdStarts),1);
    %     for i=1:length(bdStarts)
    %         count = 1;
    %         while count>0 && (i+count)<=length(bdStarts)
    %             if (bdStarts(i+count)-bdStarts(i))<ibiThresh*fs/1000
    %                 count=count+1;
    %             else
    %                 break
    %             end
    %         end
    %         NBFirstBurst = horzcat(NBFirstBurst,i);
    %         NBLastBurst = horzcat(NBLastBurst,i+count-1);
    %         counts(i) = count-1;
    %         ibei = max([ibei,max(diff(bdStarts(i:i+count-1)))]);
    %     end
    %     if mode(counts)>=1
    %         ibiThresh = ibiThresh-20;
    %         while ibiThresh<maxIBI
    %             ibiThresh = ibiThresh+10;
    %             NBFirstBurst = [];
    %             NBLastBurst = [];
    %             counts = zeros(length(bdStarts),1);
    %             for i=1:length(bdStarts)
    %                 count = 1;
    %                 while count>0 && (i+count)<=length(bdStarts)
    %                     if (bdStarts(i+count)-bdStarts(i))<ibiThresh*fs/1000
    %                         count=count+1;
    %                     else
    %                         break
    %                     end
    %                 end
    %                 NBFirstBurst = horzcat(NBFirstBurst,i);
    %                 NBLastBurst = horzcat(NBLastBurst,i+count-1);
    %                 counts(i) = count-1;
    %                 ibei = max([ibei,max(diff(bdStarts(i:i+count-1)))]);
    %             end
    %             if mode(counts)>=1
    %                 ibiThresh = ibiThresh-10;
    %                 while ibiThresh<maxIBI
    %                     ibiThresh = ibiThresh+1;
    %                     NBFirstBurst = [];
    %                     NBLastBurst = [];
    %                     counts = zeros(length(bdStarts),1);
    for i=1:length(bdStarts) 
        diffs = bdStarts(i+1:end)-bdStarts(i);
        withinThresh = find(diffs<=ibiThresh*fs/1000);
        if ~isempty(withinThresh)
            count = max(withinThresh);
        else
            count = 0;
        end
        NBLastBurst(i) = i+count; %horzcat(NBLastBurst,i+count-1);
        counts(i) = count;
        %ibei(i) = mean(diff(bdStarts(i:i+count-1)));
    end
    %                     if mode(counts)>=1
    %                         modeFound=1;
    %                         break
    %                     end
    %                 end
    %                 break
    %             end
    %         end
    %         break
    %     end
    
   % topCountsThresh = prctile(counts,80);
   % topCountInds = find(counts>=topCountsThresh);    
    
    diffCounts = prctile(counts-prevCounts,99); %%earlier it was MEAN
%     ibiThreshs = [ibiThreshs;ibiThresh];
%     countMat = [countMat;[diffCounts,mode(counts)]]; % ibiThresh/mean(ibei(topCountInds))
    
   % countStore = [countStore;counts'];
    %maxIBEI = [maxIBEI;prctile(ibei,25)];
    
    if prctile(counts,10)>=noOfBurstChans*0.1 %&& a==0
%         modeThresh = ibiThresh;
%         a=1;
disp('condition1');
        break
    elseif ibiThresh > minIbiThresh && max(counts)>5
            if diffCounts <= 1 %&& b==0
                %decayThres = ibiThresh;
                %b=1;
                disp('condition2');
                break
            end
    end
    
end

    if ibiThresh ~= 1000
ibiThresh = ibiThresh-5;
    end


% modeThresh = find(countMat(:,2)==1);
% if ~isempty(modeThresh)
%     modeThresh = ibiThreshs(modeThresh(1));
% else
%     modeThresh = ibiThresh;
% end

% countPat = countMat(:,1);
% countPat = smooth(countPat,10,'lowess');
% countPat = (countPat-min(countPat))./(max(countPat)-min(countPat));
% decayThresh = find(countPat<0.05);
% decayThresh = ibiThreshs(decayThresh(1));
% 
% ibiThresh = min([modeThresh,decayThresh]);

disp(ibiThresh);

% f2 = figure();
% subplot(2,1,1);
% stem(ibiThreshs,countMat(:,1));
% hold on
% if decayThresh ~= 0
% scatter(decayThresh,0,'markerfacecolor','red');
% end
% subplot(2,1,2);
% stem(ibiThreshs,countMat(:,2));
% hold on
% if modeThresh ~=0
% scatter(modeThresh,0,'markerfacecolor','red');
% end
% close(f2);


counts = zeros(length(bdStarts),1);
NBFirstBurst = [];
NBLastBurst = [];
%%Get the correct counts for the chose ibi thresh
for i=1:length(bdStarts)
    count = 1;
    while count>0 && (i+count)<=length(bdStarts)
        if (bdStarts(i+count)-bdStarts(i))<ibiThresh*fs/1000
            count=count+1;
        else
            break
        end
    end
    NBFirstBurst = horzcat(NBFirstBurst,i);
    NBLastBurst = horzcat(NBLastBurst,i+count-1);
    counts(i) = count-1;
    %ibei = [ibei;prctile(diff(bdStarts(i:i+count-1)),90)];
end

plot(bdStarts/fs,counts);
hold on

%% finding peaks in the burst counts, counts has the burstCount when the NB starts from a given burst
[peakVal,peakLoc]= findpeaks(counts);
scatter(bdStarts(peakLoc)/fs,peakVal,'markerfacecolor','red');


%% Gather bursts to peaks on different levels
levels = sort(unique(counts),'descend');
assigned = [];
nbStore = [];

for k=1:length(levels)-1
    %get the peaks of this level
    peak = levels(k);
    starts = find(counts==peak);
    
    for j=1:length(starts)
        % if the burst has not already been assigned
        if ismember(starts(j),assigned)==0
            includedBursts = starts(j):starts(j)+peak;
            
            %if any of the bursts captured in its count are not assigned
            if nnz(ismember(includedBursts,assigned))<=0
                nbStore = vertcat(nbStore,[NBFirstBurst(starts(j)),NBLastBurst(starts(j)),peak]);
                
                assigned = horzcat(assigned,includedBursts);
                assigned = unique(assigned);
                
                scatter(bdStarts(starts(j))/fs,peak,'markerfacecolor','green');
                
            
            end
        end
    end
end

nbStore = sortrows(nbStore,1);
%%Filter valid burst starts and ends
NBFirstBurst = nbStore(:,1);
NBLastBurst = nbStore(:,2);


close(f);

%% Initilaize figure
f = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
ylim([0,60]);
hold on

%% draw bursts
for k = 1:length(burstEl)
    BDcurElec = BDTrains(find(BDTrains(:,1)==burstEl(k)),:);
    
    for i=1:size(BDcurElec)-1
        percentileX = [BDcurElec(i,2),BDcurElec(i,3)]/fs;
        chanNo = find(channels==burstEl(k));
        threshPercY = [chanNo chanNo];
        line(percentileX,threshPercY,'lineWidth',2);
    end
end


% if numel(NBFirstBurst)>0
%     nbFirst = NBFirstBurst(1);
%     nbLast = NBLastBurst(1);
%
%     %% Join netBursts with starts<ibiThresh
%     ibiThresh = ibiThresh*fs/1000;
%     for i=2:length(NBFirstBurst)
%         if (bdStarts(NBFirstBurst(i))-bdStarts(nbLast(end)))<ibiThresh
%             nbLast(end) = NBLastBurst(i);
%         else
%             nbFirst = vertcat(nbFirst,NBFirstBurst(i));
%             nbLast = vertcat(nbLast,NBLastBurst(i));
%         end
%     end
%
%     NBFirstBurst = nbFirst;
%     NBLastBurst = nbLast;
%     clear 'nbFirst', 'nbLast';
% end


%%Delete net bursts that have lower than 5 bursts in them
numBursts = NBLastBurst-NBFirstBurst;

NBFirstBurst(numBursts<2)=[];
NBLastBurst(numBursts<2)=[];

%Add bursts that start or end within a NB but not assigned to any other NB
%and not spanning any other NB
%good to catch prebursts
assignedBursts = [];
for i=1:length(NBFirstBurst)

   
    %%ends in the NB or spans NB
    if i>1
    bdIndices = find((BDTrainsSorted(NBFirstBurst(i),2)-BDTrainsSorted(NBLastBurst(i-1)+1:NBFirstBurst(i)-1,3))<0 & (BDTrainsSorted(NBLastBurst(i-1)+1:NBFirstBurst(i)-1,2)-BDTrainsSorted(NBFirstBurst(i),2))<ibiThresh); % & (burstEnd-BDTrainsSorted(1:NBFirstBurst(i)-1,3))<0);
    bdIndices = bdIndices + NBLastBurst(i-1);
    
    if ~isempty(bdIndices)
        bdIndices = bdIndices(~ismember(bdIndices,assignedBursts));
        if ~isempty(bdIndices)
            NBFirstBurst(i) = bdIndices(1);
        end
    end
    end

    %starts in the NB
    if i<length(NBFirstBurst)
        
        burstEnds = BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),3);
    
    burstEnds(burstEnds>=BDTrainsSorted(NBFirstBurst(i+1),2)) = [];
    burstEnd = max(burstEnds);    

    if ~isempty(burstEnd)
        % if a start of a burst falls after the start of the NB and before
        % the end of the NB, where the end is defined as the last end 
    bdIndices = find((BDTrainsSorted(NBFirstBurst(i),2)-BDTrainsSorted(NBLastBurst(i)+1:NBFirstBurst(i+1),2))<0 & ...
        (burstEnd-BDTrainsSorted(NBLastBurst(i)+1:NBFirstBurst(i+1),2))>0);

    if ~isempty(bdIndices)
        NBLastBurst(i) = NBLastBurst(i)+bdIndices(end);
    end
    end
    end
    
    assignedBursts = [assignedBursts,NBFirstBurst(i):NBLastBurst(i)];
end


%% Add bursts that start an ibiThresh before or after the netBurst
% 
% for i=1:length(NBFirstBurst)
%     bdIndices = find((BDTrainsSorted(NBFirstBurst(i),2)-BDTrainsSorted(1:NBFirstBurst(i)-1,2))<ibiThresh);
% 
%     if ~isempty(bdIndices)
%         NBFirstBurst(i) = bdIndices(1);
%     end
% 
%     bdIndices = find((BDTrainsSorted(NBLastBurst(i)+1:end,2)-BDTrainsSorted(NBLastBurst(i),2))<ibiThresh);
% 
%     if ~isempty(bdIndices)
%         NBLastBurst(i) = NBLastBurst(i)+bdIndices(end);
%     end
% end


%% Merge netbursts that have more than 20% of bursts spanning across the latter
numNB = length(NBFirstBurst);

if numNB>1
    NBFirstBurstMerged = NBFirstBurst(1);
    NBLastBurstMerged = NBLastBurst(1);

    for i = 2:numNB
        
%         disp(sprintf('%d %d',NBFirstBurst(i),NBLastBurst(i)));
%         disp(sprintf('%d %d',NBFirstBurstMerged(end),NBLastBurstMerged(end)));
        
        prevBurstChans = BDTrainsSorted(NBFirstBurstMerged(end):NBLastBurstMerged(end),1);
      %  prevBurstStarts = BDTrainsSorted(NBFirstBurstMerged(end):NBLastBurstMerged(end),2);
        prevBurstEnds = BDTrainsSorted(NBFirstBurstMerged(end):NBLastBurstMerged(end),3);
        uniqueChans1 = unique(prevBurstChans);
        for h=1:length(prevBurstChans)
            prevBurstChans(h) = find(channels==prevBurstChans(h));
        end
        count = 0;
        
       % overlapChans = [];
        for j=1:length(prevBurstEnds)
            if prevBurstEnds(j)>BDTrainsSorted(NBFirstBurst(i),2)
               % disp(sprintf('%f %f',prevBurstEnds(j),BDTrainsSorted(NBFirstBurst(i),2)));
                count = count+1;
               % overlapChans = [overlapChans;prevBurstChans(j)];
               % line([prevBurstStarts(j),prevBurstEnds(j)]./fs,[prevBurstChans(j),prevBurstChans(j)],'color','red');
            end
        end
       
        uniqueChans2 = unique(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),1));        
              
        if ((count/length(uniqueChans1))>0.2 || (count/length(uniqueChans2))>0.2) && (length(uniqueChans1)/length(uniqueChans2)>=2 || length(uniqueChans2)/length(uniqueChans1)>=2) && count>=noOfBurstChans*0.1
          %  disp(sprintf('%f %f %f',count,length(uniqueChans1),length(uniqueChans2)));
          %  disp(sprintf('%f %f %f %f',count/length(uniqueChans1),count/length(uniqueChans2),length(uniqueChans1)/length(uniqueChans2),length(uniqueChans2)/length(uniqueChans1)));
            NBLastBurstMerged(end) = NBLastBurst(i);  
           lastBurstEnd = max(BDTrainsSorted(NBFirstBurstMerged(end):NBLastBurstMerged(end),3));
           line([BDTrainsSorted(NBFirstBurstMerged(end),2),lastBurstEnd]./fs,[0.75,0.75],'color','red');
          %  disp('');
        else
            NBFirstBurstMerged = vertcat(NBFirstBurstMerged,NBFirstBurst(i));
            NBLastBurstMerged = vertcat(NBLastBurstMerged,NBLastBurst(i));
        end
    end

    NBFirstBurst = NBFirstBurstMerged;
    NBLastBurst = NBLastBurstMerged;
    clear 'NBFirstBurstMerged', 'NBLastBurstMerged';
end



%%Separating merged network bursts
% for k = 1:length(NBFirstBurst)
%     f = figure();
%     burstStarts = BDTrainsSorted(NBFirstBurst(k):NBLastBurst(k),2);
%     burstEnds = BDTrainsSorted(NBFirstBurst(k):NBLastBurst(k),3);
%     minStart = min(burstStarts);
%     maxEnd = max(burstEnds);
%     simBursts = zeros(maxEnd-minStart+1,1);
%
%     for j=1:length(burstStarts);
%         simBursts(burstStarts(j)-minStart+1:burstEnds(j)-minStart+1) = simBursts(burstStarts(j)-minStart+1:burstEnds(j)-minStart+1)+1;
%     end
%
%     simBursts = smooth(simBursts,round(fs/20),'lowess');
%     plot(simBursts);
%     close(f);
% end


numNB = length(NBFirstBurst);
numActElec = zeros(numNB,1);
totBurstSize = zeros(numNB,1);
avgPeakSize = zeros(numNB,1);
noOfSpikesInBurst = zeros(numNB,1);



%% gather all bursts whose starts or end fall within a given net burst start-end into that net burst
for i = 1:numNB
    % list of bursting electrodes (in the i-th NB)
    actElec = unique(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),1));
    % counts number of active electrodes
    numActElec(i) = length(actElec);
    
    totBurstSize(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),4));
    avgPeakSize(i) = mean(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),5));
    noOfSpikesInBurst(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),6));
end

%% group bursts into network bursts
numElecTh = 5;
NB2save = numActElec>=numElecTh;
newNBFirstBurst = NBFirstBurst(NB2save);
newNBLastBurst = NBLastBurst(NB2save);
newNumNB = length(newNBFirstBurst);
newNumActElec = numActElec(NB2save);
newTotBurstSize = totBurstSize(NB2save);
newAvgPeakSize= avgPeakSize(NB2save);
newNoOfSpikesInBurst= noOfSpikesInBurst(NB2save);

NB = zeros(newNumNB,8);
NBpattern = cell(newNumNB,1);
for jj = 1:newNumNB
    burstBegin = BDTrainsSorted(newNBFirstBurst(jj),2);
    burstEnd = max(BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),3));
    if jj ~= newNumNB
        succBurstBegin = BDTrainsSorted(newNBFirstBurst(jj+1),2);
        if burstEnd >= succBurstBegin
            burstEnd = succBurstBegin-1;
        end
    end
    NB(jj,1:4) = [burstBegin, ... % ts of the begin of the first burst [samples]
        burstEnd, ...  % ts of the end of the longest burst [samples]
        newNBLastBurst(jj)-newNBFirstBurst(jj)+1,...        % number of bursts
        burstEnd-burstBegin]; % duration [samples]
    NB(jj,5) = newNumActElec(jj);
    NB(jj,6) = newTotBurstSize(jj); %sum of all peak amplitudes within burst
    NB(jj,7) = newAvgPeakSize(jj); % average peak size in the burst
    NB(jj,8) = newTotBurstSize(jj)/(burstEnd-burstBegin); % average amplitude during the burst
    NB(jj,9) = newNoOfSpikesInBurst(jj); % average amplitude during the burst
    NBpattern{jj} = BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),1:2);
end

%%find global bursts
noOfChannels = NB(:,5);
bins = 1:max(noOfChannels);
counts = histc(noOfChannels,bins);
counts = smooth(counts,5);
[val,pos] = min(counts(floor(max(noOfChannels)*0.4):floor(max(noOfChannels)*0.9)));
globalThresh = floor(max(noOfChannels)*0.4)+pos;

globals = find(noOfChannels>=globalThresh);
localsTails = find(noOfChannels<globalThresh);

NB = [NB,zeros(size(NB,1),2)]; %%column 10 - global burst or not, 11 - tail or not
NB(globals,10) = 1;

%%label local bursts vs tails
for i=1:length(localsTails)   
    if localsTails(i) ~= 1
         startOfTail = NB(localsTails(i),1);   
         endOfPrevNB = NB(localsTails(i)-1,2);
        if (NB(localsTails(i)-1,10) == 1 && startOfTail-endOfPrevNB < 2) || (NB(localsTails(i)-1,11) == 1 && startOfTail-endOfPrevNB < 2)
            NB(localsTails(i),11) = 1;        
        end 
    end    
end


%%group super bursts
%globalNBIBIs = diff(netBursts(globals,1));

%draw NBs
NBursts = {NB};
NBurstsPattern = {NBpattern};

nbMarkerHeight = 0.4;
for i=1:size(NB,1)
    percentileX = [NB(i,1), NB(i,2)]/fs;
    threshPercY = [nbMarkerHeight nbMarkerHeight];
    if NB(i,10)==1
    line(percentileX,threshPercY,'Color','red','lineWidth',2);
    line([NB(i,1) NB(i,1)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
    line([NB(i,2) NB(i,2)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
    elseif NB(i,10)==0 && NB(i,11) ==1
        line(percentileX,threshPercY,'Color','black','lineWidth',2);
    line([NB(i,1) NB(i,1)]/fs,[0 nbMarkerHeight],'Color','black','lineWidth',3);
    line([NB(i,2) NB(i,2)]/fs,[0 nbMarkerHeight],'Color','black','lineWidth',3);
    else
        line(percentileX,threshPercY,'Color','green','lineWidth',2);
    line([NB(i,1) NB(i,1)]/fs,[0 nbMarkerHeight],'Color','green','lineWidth',3);
    line([NB(i,2) NB(i,2)]/fs,[0 nbMarkerHeight],'Color','green','lineWidth',3);
    end
end

set(gca,'YTick',1:60);
set(gca,'YTickLabel',channels);
xlabel('Time(s)');
ylabel('Channel');


else
NB = [];
NBpattern = [];
NBursts = {NB};
NBurstsPattern = {NBpattern};


end
close(f);
