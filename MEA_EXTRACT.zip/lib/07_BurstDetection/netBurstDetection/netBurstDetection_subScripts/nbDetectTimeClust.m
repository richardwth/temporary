function [NBursts, NBurstsPattern] = nbDetectTimeClust(path,binWidth,threshold,fs)

%% initialize parameters
binWidthSec = binWidth/1000;

channels = getMEA60Channels();

scrsz = get(0,'ScreenSize');


%% load the burst detection file
cd(path);

BDfiles = dirr(path);
fileName = BDfiles(1).name;
load(fileName);

%% get all the bursts of all channels into BDTrains
burstEl = find(~cellfun('isempty', burst_detection_cell));
BDTrains = [];

for k = 1:length(burstEl)
    BDcurElec = burst_detection_cell{burstEl(k)};
    NumBcurElec = size(BDcurElec,1);
    BDTrains = [BDTrains; burstEl(k)*ones(NumBcurElec,1) BDcurElec(:,[1,2,7,8,9])];
    BDTrains = BDTrains(1:end-1,:);
end

if ~isempty(BDTrains)
    

%% get the starts and ends of net bursts
BDTrainsSorted = sortrows(BDTrains,2);

burstCores = (BDTrainsSorted(:,3)+BDTrainsSorted(:,2))./(fs*2);
BDTrainsSortByCore = [BDTrainsSorted,burstCores,[1:length(burstCores)]']; % the last column correspond to the row number of the matching entry in BDTrainsSorted
BDTrainsSortByCore = sortrows(BDTrainsSortByCore,size(BDTrainsSortByCore,2)-1);

burstCores = BDTrainsSortByCore(:,end-1);

[tt,chcnt,dtt,starts,stops] = timeclust(burstCores,binWidthSec,[],threshold);

totMat = [tt',chcnt',dtt',starts',stops'];
            totMat(isnan(totMat(:,1)),:) = [];
            totMat(isnan(totMat(:,3)),:) = [];
            
NBFirstBurst = zeros(size(totMat,1),1);
NBLastBurst = zeros(size(totMat,1),1);


for i=1:size(totMat,1)
    burstsInNB = find(burstCores >= totMat(i,4) & burstCores <= (totMat(i,5)));
    burstInds = BDTrainsSortByCore(burstsInNB,end);
    NBFirstBurst(i) = min(burstInds);
    NBLastBurst(i) = max(burstInds);
end

a = [NBFirstBurst,NBLastBurst]; %sort NBFirstBurst and lastBurst again -- needed to avoid log spanning bursts from distorting results
a = sortrows(a,1);
NBFirstBurst = a(:,1);
NBLastBurst = a(:,2);

numNB = length(NBFirstBurst);
numActElec = zeros(numNB,1);
totBurstSize = zeros(numNB,1);
avgPeakSize = zeros(numNB,1);
noOfSpikesInBurst = zeros(numNB,1);

%%Are there overlaps?
elems = find((NBFirstBurst(2:end)-NBLastBurst(1:end-1))<0);

%% gather all bursts whose starts or end fall within a given net burst start-end into that net burst
for i = 1:numNB
    % list of bursting electrodes (in the i-th NB)
    actElec = unique(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),1));
    % counts number of active electrodes
    numActElec(i) = length(actElec);
    
    totBurstSize(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),4));
    avgPeakSize(i) = mean(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),5));
    noOfSpikesInBurst(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),6));
end

%% group bursts into network bursts
numElecTh = 0;
NB2save = numActElec>=numElecTh;
newNBFirstBurst = NBFirstBurst(NB2save);
newNBLastBurst = NBLastBurst(NB2save);
newNumNB = length(newNBFirstBurst);
newNumActElec = numActElec(NB2save);
newTotBurstSize = totBurstSize(NB2save);
newAvgPeakSize= avgPeakSize(NB2save);
newNoOfSpikesInBurst= noOfSpikesInBurst(NB2save);

NB = zeros(newNumNB,8);
NBpattern = cell(newNumNB,1);
for jj = 1:newNumNB
    burstBegin = BDTrainsSorted(newNBFirstBurst(jj),2);
    burstEnd = max(BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),3));
    
    if jj ~= newNumNB
        succBurstBegin = BDTrainsSorted(newNBFirstBurst(jj+1),2);
        if burstEnd >= succBurstBegin
            burstEnd = succBurstBegin-1;
        end
    end
   
    NB(jj,1:4) = [burstBegin, ... % ts of the begin of the first burst [samples]
        burstEnd, ...  % ts of the end of the longest burst [samples]
        newNBLastBurst(jj)-newNBFirstBurst(jj)+1,...        % number of bursts
        burstEnd-burstBegin]; % duration [samples]
    NB(jj,5) = newNumActElec(jj);
    NB(jj,6) = newTotBurstSize(jj); %sum of all peak amplitudes within burst
    NB(jj,7) = newAvgPeakSize(jj); % average peak size in the burst
    NB(jj,8) = newTotBurstSize(jj)/(burstEnd-burstBegin); % average amplitude during the burst
    NB(jj,9) = newNoOfSpikesInBurst(jj); % average amplitude during the burst
    NBpattern{jj} = BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),1:2);
end

NBursts = {NB};
NBurstsPattern = {NBpattern};

%% Initilaize figure
f = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
ylim([0,60]);
hold on

%% draw bursts
for k = 1:length(burstEl)
    BDcurElec = BDTrains(find(BDTrains(:,1)==burstEl(k)),:);
    
    for i=1:size(BDcurElec)-1
        percentileX = [BDcurElec(i,2),BDcurElec(i,3)]/fs;
        chanNo = find(channels==burstEl(k));
        threshPercY = [chanNo chanNo];
        line(percentileX,threshPercY,'lineWidth',2);
    end
end

nbMarkerHeight = 0.4;
for i=1:size(NB,1)
    percentileX = [NB(i,1), NB(i,2)]/fs;
    threshPercY = [nbMarkerHeight nbMarkerHeight];
    line(percentileX,threshPercY,'Color','red','lineWidth',2);
    line([NB(i,1) NB(i,1)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
    line([NB(i,2) NB(i,2)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
end


set(gca,'YTick',1:60);
set(gca,'YTickLabel',channels);
xlabel('Time(s)');
ylabel('Channels');
title('Network burst detection: Time clustering method');

close(f);
else
NB = [];
NBpattern = [];
NBursts = {NB};
NBurstsPattern = {NBpattern};

end

