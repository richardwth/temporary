function [NBursts, NBurstsPattern] = nbDetectCumul(path,maxIBI,channelPercentage,variability,fs,removeOutliers)

%% initialize parameters
channels = getMEA60Channels();


%% load the burst detection file
cd(path);

BDfiles = dirr(path);
fileName = BDfiles(1).name;
load(fileName);

%% get all the bursts of all channels into BDTrains
burstEl = find(~cellfun('isempty', burst_detection_cell));

if ~isempty(burstEl)
    
    
scrsz = get(0,'ScreenSize');
f = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
    
activeChannels = length(burstEl); %length(find(isActiveChannel==1));
BDTrains = [];
burstDurations = [];

for k = 1:length(burstEl)
    BDcurElec = burst_detection_cell{burstEl(k)};
    NumBcurElec = size(BDcurElec,1);
    BDTrains = [BDTrains; burstEl(k)*ones(NumBcurElec,1) BDcurElec(:,[1,2,7,8,9])];
    BDTrains = BDTrains(1:end-1,:);
    if ~isempty(BDcurElec)
        burstDurations = vertcat(burstDurations,BDcurElec(1:end-1,4)*fs);
        
    end
end

%% select bursts that are within the valid burst duration
if removeOutliers==1
    percentileX = 1:100;
    threshs = prctile(burstDurations,percentileX);
    [p,S] = polyfit(percentileX(1:95),threshs(1:95),5);
    [threshPercY,delta] = polyval(p,percentileX,S);
    outliers = abs(threshs - threshPercY) > 1.5*std(threshPercY);  
    percentileX(outliers)=[];
%     stem(threshs);
%     hold on
%     plot(threshPercY,'r','linewidth',2);
%     scatter(percentileX(end),0,'markerfacecolor','red');
    maxBurstDuration = prctile(burstDurations,percentileX(end));
    validBursts = find((BDTrains(:,3)-BDTrains(:,2))<maxBurstDuration);
    BDTrains = BDTrains(validBursts,:);
end

%% find threshold number of channels
numElecTh = activeChannels*channelPercentage;

%% get the starts and ends of net bursts
BDTrainsSorted = sortrows(BDTrains,2);
bdStarts = BDTrainsSorted(:,2);

NBFirstBurst = [];
NBLastBurst = [];
counts = [];

ibiThreshs = 5:5:maxIBI;

countMat = zeros(length(ibiThreshs),3);

ibiThresh = 0; %increasing in 1ms intervals
j = 0;
ibei = 0;

while ibiThresh<maxIBI
    ibiThresh = ibiThresh+10;
    NBFirstBurst = [];
    NBLastBurst = [];
    counts = zeros(length(bdStarts),1);
    for i=1:length(bdStarts)
        count = 1;
        while count>0 && (i+count)<=length(bdStarts)
            if (bdStarts(i+count)-bdStarts(i))<ibiThresh*fs/1000
                count=count+1;
            else
                break
            end
        end
        NBFirstBurst = horzcat(NBFirstBurst,i);
        NBLastBurst = horzcat(NBLastBurst,i+count-1);
        counts(i) = count-1;
        ibei = max([ibei,max(diff(bdStarts(i:i+count-1)))]);
    end
    if mode(counts)>=1
        ibiThresh = ibiThresh-10;
        while ibiThresh<maxIBI
            ibiThresh = ibiThresh+1;
            NBFirstBurst = [];
            NBLastBurst = [];
            counts = zeros(length(bdStarts),1);
            for i=1:length(bdStarts)
                count = 1;
                while count>0 && (i+count)<=length(bdStarts)
                    if (bdStarts(i+count)-bdStarts(i))<ibiThresh*fs/1000
                        count=count+1;
                    else
                        break
                    end
                end
                NBFirstBurst = horzcat(NBFirstBurst,i);
                NBLastBurst = horzcat(NBLastBurst,i+count-1);
                counts(i) = count-1;
                ibei = max([ibei,max(diff(bdStarts(i:i+count-1)))]);
            end
            if mode(counts)>=1
                break
            end
        end
        break
    end
    %             j=j+1;
    %             countMat(j,1)=mode(counts);
    %             countMat(j,2)=prctile(counts,50);
    %             countMat(j,3)=max(counts);
end


% subplot(1,3,1);
% stem(ibiThreshs,countMat(:,1));
% subplot(1,3,2);
% stem(ibiThreshs,countMat(:,2));
% subplot(1,3,3);
% stem(ibiThreshs,countMat(:,3));
disp(ibiThresh);

plot(bdStarts/fs,counts);
hold on

%% finding peaks in the burst counts, counts has the burstCount when the NB starts from a given burst
if length(counts)>=3 % findpeaks need atleast 3 samples
[peakVal,peakLoc]= findpeaks(counts);
scatter(bdStarts(peakLoc)/fs,peakVal,'markerfacecolor','red');
    
countThresh = max([5,min([numElecTh*variability,prctile(counts,98)])]);

peakLoc = peakLoc(peakVal>=countThresh);
peakVal = peakVal(peakVal>=countThresh);

scatter(bdStarts(peakLoc)/fs,peakVal,'markerfacecolor','green');
else
    peakLoc = 1;
end

close(f);


%%Filter valid burst starts and ends
NBFirstBurst = NBFirstBurst(peakLoc);
NBLastBurst = NBLastBurst(peakLoc);


%% Find burst ends
BDTrainsSortedByEnds = sortrows(BDTrains,3);
bdEnds = BDTrainsSortedByEnds(:,3); % ends in ascending order
NBFirstBurstEnds = [];
NBLastBurstEnds = [];
countsEnds = zeros(length(bdEnds),1);

for i=length(bdEnds):-1:1
    count = 1;
    while (i-count)>0
        if (bdEnds(i)-bdEnds(i-count))<ibiThresh*fs/1000
            count=count+1;
        else
            break
        end
    end
    
    burstStartsInThisNB = BDTrainsSortedByEnds(i-(count-1):i,2);
    [firstBurstStartTime,firstBurstInd] = min(burstStartsInThisNB);
    firstBurstInd = i-(count-1)-1+firstBurstInd;
    
    [lastBurstStartTime,lastBurstInd] = max(burstStartsInThisNB);
    lastBurstInd = i-(count-1)-1+lastBurstInd;
    
    NBFirstBurstEnds = horzcat(NBFirstBurstEnds,firstBurstInd);
    NBLastBurstEnds = horzcat(NBLastBurstEnds,lastBurstInd);
    countsEnds(i) = count-1;
    
end

%NBxxxx values correspond to indices in the bdTrain

f = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
plot(bdEnds/fs,countsEnds);
hold on

if length(countsEnds)>=3
[peakValEnds,peakLocEnds]= findpeaks(countsEnds);
scatter(bdEnds(peakLocEnds)/fs,peakValEnds,'markerfacecolor','red');

countThreshEnds = max([5,min([numElecTh*variability,prctile(countsEnds,98)])]);

peakLocEnds = peakLocEnds(peakValEnds>=countThreshEnds);
peakValEnds = peakValEnds(peakValEnds>=countThreshEnds);

scatter(bdEnds(peakLocEnds)/fs,peakValEnds,'markerfacecolor','green');
else
    peakLocEnds = 1;
end

close(f);

%% Sort ascending
NBFirstBurstEnds = fliplr(NBFirstBurstEnds);
NBLastBurstEnds = fliplr(NBLastBurstEnds);

NBFirstBurstEnds = NBFirstBurstEnds(peakLocEnds);
NBLastBurstEnds = NBLastBurstEnds(peakLocEnds);

for i=1:length(NBFirstBurstEnds)
    thisStart = BDTrainsSortedByEnds(NBFirstBurstEnds(i),2); % the start time of the firstBurst in this netBurst
    a = thisStart>bdStarts(NBFirstBurst); %compare with the starts of other bursts
    b = thisStart<bdStarts(NBLastBurst);
    %if thisStart is between some start-end pair
    if ~isempty(find(a&b))
        ind = find(a&b);
        thisEnd = BDTrainsSortedByEnds(NBLastBurstEnds(i),2); % the start time of the lastBurst in this netBurst
        c = thisEnd>bdStarts(NBFirstBurst);
        d = thisEnd<bdStarts(NBLastBurst);
        %if thisEnd is between some start-end pair
        if ~isempty(find(c&d))
            ind2 = find(c&d);
            %if thisEnd is not between some start-end pair
        else
            indInBdStarts = find(bdStarts==BDTrainsSortedByEnds(NBLastBurstEnds(i),2));
            NBLastBurst(ind) = indInBdStarts(1);
        end
        %if thisStart is not between some start-end pair
    else
        thisEnd = BDTrainsSortedByEnds(NBLastBurstEnds(i),2); % the start time of the lastBurst in this netBurst
        c = thisEnd>bdStarts(NBFirstBurst);
        d = thisEnd<bdStarts(NBLastBurst);
        %if thisEnd is between some start-end pair
        if ~isempty(find(c&d))
            ind = find(c&d);
            indInBdStarts = find(bdStarts==BDTrainsSortedByEnds(NBFirstBurstEnds(i),2));
            NBFirstBurst(ind) =  indInBdStarts(1);
        else
            startIndInBdStarts = find(bdStarts==BDTrainsSortedByEnds(NBFirstBurstEnds(i),2));
            endIndInBdStarts = find(bdStarts==BDTrainsSortedByEnds(NBLastBurstEnds(i),2));
            NBFirstBurst = horzcat(NBFirstBurst,startIndInBdStarts(1));
            NBLastBurst = horzcat(NBLastBurst,endIndInBdStarts(1));
        end
    end
end

%% Sort by firstBurst
nbMergeTemp = horzcat(NBFirstBurst',NBLastBurst');
if ~isempty(nbMergeTemp)
    nbMergeTemp = sortrows(nbMergeTemp,1);
    NBFirstBurst = nbMergeTemp(:,1)';
NBLastBurst = nbMergeTemp(:,2)';
end



%% Initilaize figure
f2 = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
ylim([0,60]);
hold on

%% draw bursts
for k = 1:length(burstEl)
    BDcurElec = BDTrains(find(BDTrains(:,1)==burstEl(k)),:);
    
    for i=1:size(BDcurElec)-1
        percentileX = [BDcurElec(i,2),BDcurElec(i,3)]/fs;
        chanNo = find(channels==burstEl(k));
        threshPercY = [chanNo chanNo];
        line(percentileX,threshPercY,'lineWidth',2);
    end
end

% peakDiffs = [0;diff(peaks)<ibiThresh;0];
% peaks = peaks(peakDiffs==1);

if numel(NBFirstBurst)>0
    nbFirst = NBFirstBurst(1);
    nbLast = NBLastBurst(1);
    
    %% Join netBursts with starts<ibiThresh
    ibiThresh = ibiThresh*fs/1000;
    for i=2:length(NBFirstBurst)
        if (bdStarts(NBFirstBurst(i))-bdStarts(nbLast(end)))<ibiThresh
            nbLast(end) = NBLastBurst(i);
        else
            nbFirst = vertcat(nbFirst,NBFirstBurst(i));
            nbLast = vertcat(nbLast,NBLastBurst(i));
        end
    end
    
    NBFirstBurst = nbFirst;
    NBLastBurst = nbLast;
    clear 'nbFirst', 'nbLast';
end


%% Add bursts that start an ibiThresh before or after the netBurst
for i=1:length(NBFirstBurst)
    bdIndices = find((BDTrainsSorted(NBFirstBurst(i),2)-BDTrainsSorted(1:NBFirstBurst(i)-1,2))<ibiThresh);

    if ~isempty(bdIndices)
        NBFirstBurst(i) = bdIndices(1);
    end

    bdIndices = find((BDTrainsSorted(NBLastBurst(i)+1:end,2)-BDTrainsSorted(NBLastBurst(i),2))<ibiThresh);

    if ~isempty(bdIndices)
        NBLastBurst(i) = NBLastBurst(i)+bdIndices(end);
    end
end


%% Merge netbursts that have more than 5% of bursts are spanning across the latter
numNB = length(NBFirstBurst);

if numNB>1
NBFirstBurstMerged = NBFirstBurst(1);
NBLastBurstMerged = NBLastBurst(1);

for i = 2:numNB
    prevBurstEnds = BDTrainsSorted(NBFirstBurstMerged(end):NBLastBurstMerged(end),3);
    count = 0;
    for j=1:length(prevBurstEnds)
        if prevBurstEnds(j)>BDTrainsSorted(NBFirstBurst(i),2)
            count = count+1;
        end
    end
    if (count/length(prevBurstEnds))>0.05
        NBLastBurstMerged(end) = NBLastBurst(i);     
    else
        NBFirstBurstMerged = vertcat(NBFirstBurstMerged,NBFirstBurst(i));
        NBLastBurstMerged = vertcat(NBLastBurstMerged,NBLastBurst(i));
    end
end

NBFirstBurst = NBFirstBurstMerged;
NBLastBurst = NBLastBurstMerged;
clear 'NBFirstBurstMerged', 'NBLastBurstMerged';
end

numNB = length(NBFirstBurst);
numActElec = zeros(numNB,1);
totBurstSize = zeros(numNB,1);
avgPeakSize = zeros(numNB,1);
noOfSpikesInBurst = zeros(numNB,1);

%%Are there overlaps?
elems = find((NBFirstBurst(2:end)-NBLastBurst(1:end-1))<0);

%% gather all bursts whose starts or end fall within a given net burst start-end into that net burst
for i = 1:numNB
    % list of bursting electrodes (in the i-th NB)
    actElec = unique(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),1));
    % counts number of active electrodes
    numActElec(i) = length(actElec);
    
    totBurstSize(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),4));
    avgPeakSize(i) = mean(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),5));
    noOfSpikesInBurst(i) = sum(BDTrainsSorted(NBFirstBurst(i):NBLastBurst(i),6));
end

%% group bursts into network bursts
numElecTh = 12;
NB2save = numActElec>=numElecTh;
newNBFirstBurst = NBFirstBurst(NB2save);
newNBLastBurst = NBLastBurst(NB2save);
newNumNB = length(newNBFirstBurst);
newNumActElec = numActElec(NB2save);
newTotBurstSize = totBurstSize(NB2save);
newAvgPeakSize= avgPeakSize(NB2save);
newNoOfSpikesInBurst= noOfSpikesInBurst(NB2save);

NB = zeros(newNumNB,8);
NBpattern = cell(newNumNB,1);
for jj = 1:newNumNB
    burstBegin = BDTrainsSorted(newNBFirstBurst(jj),2);
    burstEnd = max(BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),3));
    if jj ~= newNumNB
        succBurstBegin = BDTrainsSorted(newNBFirstBurst(jj+1),2);
        if burstEnd >= succBurstBegin
            burstEnd = succBurstBegin-1;
        end
    end
    NB(jj,1:4) = [burstBegin, ... % ts of the begin of the first burst [samples]
        burstEnd, ...  % ts of the end of the longest burst [samples]
        newNBLastBurst(jj)-newNBFirstBurst(jj)+1,...        % number of bursts
        burstEnd-burstBegin]; % duration [samples]
    NB(jj,5) = newNumActElec(jj);
    NB(jj,6) = newTotBurstSize(jj); %sum of all peak amplitudes within burst
    NB(jj,7) = newAvgPeakSize(jj); % average peak size in the burst
    NB(jj,8) = newTotBurstSize(jj)/(burstEnd-burstBegin); % average amplitude during the burst
    NB(jj,9) = newNoOfSpikesInBurst(jj); % average amplitude during the burst
    NBpattern{jj} = BDTrainsSorted(newNBFirstBurst(jj):newNBLastBurst(jj),1:2);
end

NBursts = {NB};
NBurstsPattern = {NBpattern};

nbMarkerHeight = 0.4;
for i=1:size(NB,1)
    percentileX = [NB(i,1), NB(i,2)]/fs;
    threshPercY = [nbMarkerHeight nbMarkerHeight];
    line(percentileX,threshPercY,'Color','red','lineWidth',2);
    line([NB(i,1) NB(i,1)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
    line([NB(i,2) NB(i,2)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
end


set(gca,'YTick',1:60);
set(gca,'YTickLabel',channels);

close(f);

else
    NBursts = [];
    NBurstsPattern = [];
end



