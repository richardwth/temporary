% Get user inputs
% INPUT folder
peakFolder = uigetdir(pwd,'Select the folder that contains the PeakDetactionMAT Files:');
if strcmp(num2str(peakFolder),'0')          % halting case
    warndlg('Select a folder!','!!Warning!!')
    return
end
[path, folderName] = fileparts(peakFolder);

cd(peakFolder);
cd ..

% BDResFolder = uigetdir(pwd,'Select the folder that contains the BurstDetectionFiles results:');
% if strcmp(num2str(BDResFolder),'0')          % halting case
%     warndlg('Select a folder!','!!Warning!!')
%     return
% end
% [path, filename] = fileparts(BDResFolder);

% OUTPUT folder
string = 'NetworkBurstDetectionFilesVP';
[NBDResFolder, overwriteFlag] = createResultFolder(path, string);
if(isempty(NBDResFolder))
    errordlg('Error creating output folder!','!!Error!!')
    return
end
% INPUT parameters
[parameters, flag] = netBurstDetectionVanPelt_uigetParam();
if(flag)
%     tic
    % Launch algorithm to detect NB
    [NBursts, NBurstsPattern] = netBurstDetectionVanPeltOld(peakFolder,parameters.fs,parameters.recordingTime,parameters.binWidth,parameters.mergeInt);
    % saves results
    %netBurstDetection_save(BDResFolder, NBDResFolder, parameters, NBursts, NBurstsPattern);
    numExp = find_expnum(NBDResFolder, '_NetworkBurstDetection');
    fileName = fullfile(NBDResFolder,[numExp,'_NetworkBurstDetection.mat']);
    netBursts = NBursts{1,1};
    netBurstsPattern = NBurstsPattern{1,1};
    save(fileName,'netBursts','netBurstsPattern','-mat');
    
    msgbox('Network Burst Detection','End Of Session','warn')
else
    errordlg('Selection failed: end of session','Error')
end