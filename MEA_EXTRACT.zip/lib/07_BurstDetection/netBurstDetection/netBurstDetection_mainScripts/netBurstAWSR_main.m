% Get user inputs
% INPUT folder
peakFolder = uigetdir(pwd,'Select the folder that contains the PeakDetactionMAT Files:');
if strcmp(num2str(peakFolder),'0')          % halting case
    warndlg('Select a folder!','!!Warning!!')
    return
end

cd(peakFolder);
cd ..

BDResFolder = uigetdir(pwd,'Select the folder that contains the BurstDetectionFiles results:');
if strcmp(num2str(BDResFolder),'0')          % halting case
    warndlg('Select a folder!','!!Warning!!')
    return
end
[path, filename] = fileparts(BDResFolder);

% OUTPUT folder
string = 'NetworkBurstDetectionFilesVP';
[NBDResFolder, overwriteFlag] = createResultFolder(path, string);
if(isempty(NBDResFolder))
    errordlg('Error creating output folder!','!!Error!!')
    return
end
% INPUT parameters
[parameters, flag] = netBurstDetectionVanPelt_uigetParam();
if(flag)
%     tic
    % Launch algorithm to detect NB
    [NBursts, NBurstsPattern] = netBurstDetectionAWSR(peakFolder,BDResFolder,parameters.fs,parameters.recordingTime,parameters.binWidth,parameters.detectionPercentage);
 %[NBursts, NBurstsPattern] = netBurstDetectionVanPelt(peakFolder,BDResFolder,parameters.fs,parameters.recordingTime,parameters.binWidth,parameters.ibiThresh,parameters.channelPercentage,parameters.detectionPercentage);
%     toc
    % saves results
    netBurstDetection_save(BDResFolder, NBDResFolder, parameters, NBursts, NBurstsPattern);
    msgbox('Network Burst Detection','End Of Session','warn')
else
    errordlg('Selection failed: end of session','Error')
end