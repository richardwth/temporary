%find hierarchical bursts
answer = inputdlg({'Burst Detection File Name','Network Burst Detection File Name','fs (Hz)','Type (Single well-1, Multiwell-2)','min spikes for burst'},...
    'Net Patterns Parameters',1,{'BurstDetectionMAT_3-BAFR','*NetworkBurstDetectionFilesBO*','20000','2','3'});
burstDetectionStr = strcat('*',answer{1},'*');
nbDetectionStr = strcat('*',answer{2},'*');
fs = str2double(answer{3});
wellType = str2double(answer{4});
minSpikes = str2double(answer{5});

startTime = 120;
endTime =180;
display = 0;
voidParamTh =0.5;

upperRootFolder = uigetdir(pwd,'Select the root folder');
cd(upperRootFolder);

% saveFolder = uigetdir(pwd,'Select the folder to save files in');

folderList = dir('*');

channels = getMultiwell12Channels();

for z=3:length(folderList)
    cd(upperRootFolder);
    lowerRootFolder = fullfile(pwd,folderList(z).name);
    cd(lowerRootFolder);
    disp(lowerRootFolder);
    
    subFolderList = dir('*');
    for x=3:length(subFolderList)
        
        cd(lowerRootFolder);
        
        rootFolder = subFolderList(x).name;
        cd(rootFolder);
        disp(rootFolder);
        rootFolderPath = pwd;
     
        list = dir('*PeakDetectionMAT*');
        cd(list(1).name);
        list = dir('*ptrain*');
        try
            cd(list(1).name);
        end
        list = dir('*ptrain*');
        
        spikes = [];
        recordingTime = 0;
        peakFolder = pwd;
        
        for i=1:length(list)
            load(list(i).name);
            recordingTime = length(peak_train)/fs; %in seconds
            
            timestamps = find(peak_train);
            [~,fileName,~] = fileparts(list(i).name);
            inds = strfind(fileName,'_');
            elNum = fileName(inds(end)+1:end);
            elNum = str2num(elNum);
            elNum = find(channels==elNum);
            spikes = [spikes;[elNum*ones(length(timestamps),1),timestamps,full(peak_train(timestamps))]];
        end
        
        spikes = sortrows(spikes,2);
        
        %bin spikes
%         afr = zeros(recordingTime*1000,1); %1ms bins
%         for i=1:10
%         bins = (i-1)*fs/1000+1:fs/100:recordingTime*fs; %10ms bins
%         binCounts = histc(spikes(:,2),bins);
%         afr((i-1)+1:10:recordingTime*1000) = binCounts;
%         end
%       low = prctile(afr,50);
%       high = prctile(afr,100);
%         mfrRatio = zeros(100,1);
%         bins = low:(high-low)/100:high;
%       parfor count=1:100
%           
%           disp(count);
%           i=bins(count);
%          edges = [0;diff(afr>i)];
%          starts = find(edges==1);
%          ends = find(edges==-1);
%          spikesInNBs = 0;
%          NBtime = 0;
%          for j=1:length(starts)
%             spikesInNBs = spikesInNBs + nnz(spikes(:,2)>starts(j) & spikes(:,2)<ends(j));
%             NBtime = NBtime + ends(j)-starts(j);
%          end
%          mfrIn = spikesInNBs/NBtime;
%          
%          mfrOut = (length(spikes(:,2))-spikesInNBs)/(length(afr)-NBtime);
%       
%          mfrRatio(count) = mfrIn/mfrOut;
%         
%        
%       end
%       f= figure();
%       plot(mfrRatio)
%       close(f);
      
        cd(rootFolderPath);
        
     
        list = dir(burstDetectionStr);
        cd(list(1).name);
        burstFolder = pwd;
        
        %     list = dir('*BurstDetectionFiles*');
        %     cd(list(1).name);
        %     list = dir('*burst_detection*');
        %     load(list(1).name);
        
        list = dir(nbDetectionStr);
        cd(list(1).name);
        list = dir('*NetworkBurstDetection*.mat');
        for i=1:length(list)
            if isempty(strfind(list(i).name,'parameters'))
                fileName = list(i).name;
                break;
            end
        end
        
        load(fullfile(pwd,fileName));
        binWidth = 10; %ms
        binWidth = 10*fs/1000;
        
        nbNew = [];
        nbPatternsNew = [];
        for i=1:size(netBursts,1)
            spikesInNB = spikes(spikes(:,2)>netBursts(i,1) & spikes(:,2)<netBursts(i,2),2);
            bins = netBursts(i,1):binWidth:netBursts(i,2);
            counts = histc(spikesInNB,bins);
            counts = smooth(counts);
            
            if display==1
                f = figure();
                plot(counts);
            end
            
            try
                warning ('off','all');
                [vals,pos] = findpeaks(counts,'minpeakheight',0.2*max(counts));
                
            catch
                vals = 0;
                
            end
            warning ('on','all');
            
            sepInds = 1; % take 0 as the starting point to seperate bursts
            if length(vals)>1
                numOfSecondPeaks = length(vals)-1;
                
                j = 1;
                while  j<=numOfSecondPeaks
                    y1 = vals(j);
                    found = 0;
                    for m=j+1:length(vals)
                        y2 = vals(m);
                        [yMin,tempIdxMin] = min(counts(pos(j):pos(m)));
                        voidParameter = 1-(yMin/sqrt(y1.*y2));
                        if voidParameter>=voidParamTh
                            sepInds = [sepInds;tempIdxMin+pos(j)-1];
                            found = 1;
                            break;
                        end
                    end
                    if found==1
                        j=m;
                    else
                        j=j+1;
                    end
                end
                
            end
            sepInds = [sepInds;length(counts)];
            
            if display==1
                hold on
                scatter(sepInds,zeros(length(sepInds),1),'markerfacecolor','red');
                close(f);
            end
            
            if length(sepInds)<=2
                NB = netBursts(i,:);
                nbPattern = netBurstsPattern{i};
                
                nbNew = [nbNew;NB];
                nbPatternsNew = [nbPatternsNew;num2cell(nbPattern,[1,2])];
                
            else
                for j=1:length(sepInds)-1
                    burstBegin = bins(sepInds(j));
                    if j == length(sepInds)-1
                        burstEnd = netBursts(i,2);
                    else
                        burstEnd = bins(sepInds(j+1));
                    end
                    spikesInNB = spikes(spikes(:,2)>burstBegin & spikes(:,2)<burstEnd,:);
                    channelsInNB = spikesInNB(:,1);
                    heightsInNB = spikesInNB(:,3);
                    spikesInNB = spikesInNB(:,1);
                    uniqueChansInNB  = unique(channelsInNB);
                    
                    nbPattern  = [];
                    burstChanCount = 0;
                    for k=1:length(uniqueChansInNB)
                        noOfSpikesInChan = nnz(channelsInNB==uniqueChansInNB(k));
                        if noOfSpikesInChan>=3
                            burstChanCount = burstChanCount+1;
                            el = channels(uniqueChansInNB(k));
                            spikesInMB = spikesInNB(channelsInNB==uniqueChansInNB(k));
                            nbPattern = [nbPattern;[el,min(spikesInMB),max(spikesInMB)]];
                        end
                    end
                    if ~isempty(nbPattern)
                        nbPattern = sortrows(nbPattern,2);
                    end
                    
                    if length(uniqueChansInNB)>0.25*length(channels)
                        NB = [burstBegin, ... % ts of the begin of the first burst [samples]
                            burstEnd, ...  % ts of the end of the longest burst [samples]
                            burstChanCount,...        % number of bursts
                            burstEnd-burstBegin,... % duration [samples]
                            length( uniqueChansInNB),...
                            sum(heightsInNB),... %sum of all peak amplitudes within burst
                            sum(heightsInNB)/length(heightsInNB),... % average peak size in the burst
                            sum(heightsInNB)/(burstEnd-burstBegin),... % average amplitude during the burst
                            length(heightsInNB)]; % total number of spikes during the burst
                        
                        nbNew = [nbNew;NB];
                        if ~isempty(nbPattern)
                            nbPatternsNew = [nbPatternsNew;num2cell(nbPattern,[1,2])];
                        else
                            nbPatternsNew = [nbPatternsNew;{}];
                        end
                    end
                end
            end
            
        end
        
        if display ==1
            scrsz = get(0,'ScreenSize');
            
            %%Draw the spikes
            if wellType ==1
                f = figure('Position',[1+10 scrsz(1)+100 scrsz(3)-150 scrsz(4)-200]);
            else
                f = figure('Position',[1+10 scrsz(1)+100 scrsz(3)-150 scrsz(4)/3]);
            end
            
            
            if startTime>0
                spikes = spikes(spikes(:,2)>startTime*fs,:);
            end
            if endTime<recordingTime
                spikes = spikes(spikes(:,2)<endTime*fs,:);
            end
            
            hold on
            for i=1:size(spikes,1)
                line([spikes(i,2),spikes(i,2)]./fs,[spikes(i,1),spikes(i,1)+0.4],'color','black');
            end
            
            
            nbMarkerHeight = 0.4;
            
            netBursts = nbNew;
            netBurstsPattern = nbPatternsNew;
            
            if ~isempty(netBursts)
                if startTime>0
                    netBursts = netBursts(netBursts(:,1)>startTime*fs,:);
                end
                if endTime<recordingTime
                    netBursts = netBursts(netBursts(:,2)<endTime*fs,:);
                end
                
                for i=1:size(netBursts,1)
                    percentileX = [netBursts(i,1), netBursts(i,2)]/fs;
                    threshPercY = [nbMarkerHeight nbMarkerHeight];
                    line(percentileX,threshPercY,'Color','red','lineWidth',2);
                    line([netBursts(i,1) netBursts(i,1)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
                    line([netBursts(i,2) netBursts(i,2)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
                end
            end
            
            if wellType ==1
                ylim([0,61]);
            else
                ylim([0,13]);
            end
            
            
        end
        
        save(fullfile(pwd,fileName),'netBursts','netBurstsPattern');
        
        cd ..
        list = dir('BurstdetectionFiles*');
        cd(list(1).name);
        list = dir('*burst_detection*');
        burstFileName = list(1).name;
        burstFolder = pwd;
        load(burstFileName);
        
        burstEl = find(~cellfun('isempty', burst_detection_cell));
        
        for k = 1:length(burstEl)
            
            el = burstEl(k);
            channel = find(channels==el);
            burstData = burst_detection_cell{burstEl(k)};
            burstData = burstData(1:end-1,:);
            
            burstMetaData = burstData(end,:);
            noOfBursts = size(burstData,1);
            
            burstNew = [];
            
            cd(peakFolder);
            peakFile =dir(strcat('*',num2str(el),'*.mat'));
            load(peakFile(1).name);
            timestamps = full(find(peak_train));
            
            if ~isempty(netBursts)
                for m=1:noOfBursts
                    
                    inds = find(netBursts(:,1)>burstData(m,1) & netBursts(:,1)<burstData(m,2)); %find NBs that might split a given burst
                    
                    if ~isempty(inds)
                        sep = [burstData(m,1);netBursts(inds,1);burstData(m,2)];
                        
                        for n=1:length(sep)-1
                            spikes = timestamps(timestamps>=sep(n) & timestamps<=sep(n+1));
                            
                            if ~isempty(spikes)
                                burstBegin = spikes(1);
                                burstEnd = spikes(end);
                                burstDur = (burstEnd-burstBegin)/fs;
                                nspikes = length(spikes);
                            else
                                nspikes = 0;
                            end
                            
                            
                            if nspikes>=minSpikes
                                sumHeights = sum(peak_train(burstBegin:burstEnd)); % sum of all peak heights (was peak amps before) in the burst
                                avgHeightPeak = sumHeights/nspikes; % average peak heights per spike in the burst
                                avgHeightDur = sumHeights/burstDur; % average peak heights during the burst duration
                                sumAmps = sum(amp_train(burstBegin:burstEnd)); % sum of all peak amplitudes in the burst
                                avgAmpPeak = sumAmps/nspikes; % average peak amplitude per spike in the burst
                                avgAmpDur = sumAmps/burstDur; % average peak amplitude during the burst duration
                                
                                burstNew = [burstNew;[burstBegin,burstEnd,nspikes,burstDur,0,0,sumHeights,avgHeightPeak,avgHeightDur,sumAmps,avgAmpPeak,avgAmpDur]];
                                
                                %                             if display==1
                                %                                 if burstBegin/fs>startTime && burstEnd/fs<endTime
                                %                                     line([burstBegin,burstEnd]./fs,[channel+0.5,channel+0.5]);
                                %                                 end
                                %                             end
                            end
                        end
                    else
                        spikes = timestamps(timestamps>=burstData(m,1) & timestamps<=burstData(m,2));
                        if length(spikes)>= minSpikes
                            burstBegin = spikes(1);
                            burstEnd = spikes(end);
                            burstDur = (burstEnd-burstBegin)/fs;
                            nspikes = length(spikes);
                            sumHeights = sum(peak_train(burstBegin:burstEnd)); % sum of all peak heights (was peak amps before) in the burst
                            avgHeightPeak = sumHeights/nspikes; % average peak heights per spike in the burst
                            avgHeightDur = sumHeights/burstDur; % average peak heights during the burst duration
                            sumAmps = sum(amp_train(burstBegin:burstEnd)); % sum of all peak amplitudes in the burst
                            avgAmpPeak = sumAmps/nspikes; % average peak amplitude per spike in the burst
                            avgAmpDur = sumAmps/burstDur; % average peak amplitude during the burst duration
                            
                            burstNew = [burstNew;[burstBegin,burstEnd,nspikes,burstDur,0,0,sumHeights,avgHeightPeak,avgHeightDur,sumAmps,avgAmpPeak,avgAmpDur]];
                            
                            %                     if display==1
                            %                         if burstBegin/fs>startTime && burstEnd/fs<endTime
                            %                             line([burstBegin,burstEnd]./fs,[channel+0.5,channel+0.5]);
                            %                         end
                            %                     end
                        end
                    end
                end
                
                [r,c]=size(burstNew);
                acq_time=fix(length(peak_train)/fs); % Acquisition time  [sec]
                mbr=r/(acq_time/60);                 % Mean Bursting Rate [bpm]
                if ~isempty(burstNew)
                binit= burstNew(:,1); % Burst init [samples]
                bp= [diff(binit)/fs; 0];     % Burst Period [sec] - start-to-start
                ibi= [((burstNew(2:end,1)- burstNew(1:end-1,2))/fs); 0]; % Inter Burst Interval, IBI [sec] - end-to-start
                lastRow=[acq_time, length(find(peak_train)), r, sum(burstNew(:,3)), mbr, 0, 0, 0, 0, 0, 0, 0];
                burstNew(:,[5,6]) = [ibi,bp];
                burstNew = [burstNew;lastRow];
                burst_detection_cell{el} = burstNew;
                end
                    
            end
            
        end
        
        
        
        
        if display==1
            for i=1:length(burst_detection_cell)
                if ~isempty(burst_detection_cell(i))
                    bursts = burst_detection_cell{i};
                    channel = find(channels==i);
                    if startTime>0 && ~isempty(bursts)
                        bursts = bursts(bursts(:,1)>startTime*fs,:);
                    end
                    if endTime<recordingTime && ~isempty(bursts)
                        bursts = bursts(bursts(:,2)<endTime*fs,:);
                    end
                    for j=1:size(bursts,1)
                        line([bursts(j,1),bursts(j,2)]./fs,[channel+0.5,channel+0.5]);
                    end
                end
            end
            close(f);
        end
        cd(burstFolder);
        save(burstFileName,'burst_detection_cell');
    end
end


