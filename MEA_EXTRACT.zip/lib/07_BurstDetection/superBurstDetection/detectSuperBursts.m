function detectSuperBursts()

[fileName,path] = uigetfile('.mat','Select netBurst file');

cd(path);
load(fileName);

nbStarts = netBursts(:,1);
durs = netBursts(:,2)-netBursts(:,1);
inbis = diff(nbStarts);
inbis = log10(inbis);

X = [inbis,durs(2:end)];

f=figure();
bins = logspace(log10(min(inbis)),log10(max(inbis)),100);
counts = histc(inbis,bins);
bar(counts);


scatter(inbis,durs(2:end),10,'ko');

[idx2] = kmeans(X,2);
[silh2,h] = silhouette(X,idx2,'city');
cluster2 = mean(silh2);
set(get(gca,'Children'),'FaceColor',[.8 .8 1]);
xlabel('Silhouette Value');
ylabel('Cluster');

close(f);