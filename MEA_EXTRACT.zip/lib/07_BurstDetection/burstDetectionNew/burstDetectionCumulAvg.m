function burstDetectionCumulAvg(peakfolder, end_folder1, end_folder2, end_folder3, nspikes,fs)
% Function for producing the Burst Detection files

scrsz = get(0,'ScreenSize');

% DEFINE LOCAL VARIABLES
first=3;

% START PROCESSING
cd(peakfolder)                       % start_folder in the MAIN program
peakfolderdir=dir;                   % struct containing the peak-det folders
NumPeakFolder=length(peakfolderdir); % number of experimental phases


for m= first:NumPeakFolder  % FOR cycle on the phase directories
    phasedir=peakfolderdir(m).name;
    newdir=strcat (phasedir(8:end));
    cd (phasedir)
    phasedir= pwd;
    phasefiles= dir;
    NumPhaseFiles= length(phasefiles);
    
    if(NumPhaseFiles>first)
        h = waitbar(0,'Initializing waitbar...');
    end

    burst_detection_cell = cell(88,1);  % cell array containing the burst features for each channel
    burst_event_cell     = cell (88,1); % cell array containing the burst_event train for each channel
    outburst_spikes_cell = cell(88,1);  % cell array containing the random spikes features for each channel
    
    isActiveChannel = zeros(88,1); % array to store whether the channel has any peaks --> active
    
    isiChans = zeros(NumPhaseFiles-2,4);
     
    for i= first:NumPhaseFiles % FOR cycle on the single directory files
        filename = phasefiles(i).name;    % current PKD file
        electrode= filename(end-5:end-4); % current electrode [char]
        el= str2num(electrode);           % current electrode [num]
        waitbar((i-first+1)/(NumPhaseFiles-first+1),h,sprintf('%d out %d channels',i-first+1,NumPhaseFiles-first+1));
        
        load (filename);                  % 'peak_train' and 'artifact' are loaded
        
        %         if (~exist('artifact','var') || isempty(artifact) || artifact==0) % if artifact exists
        %             [peak_train]= delartcontr (peak_train, artifact, cancwinsample); % Delete the artifact contribution
        %         end
        
        if sum(peak_train)>0 && nnz(peak_train)>1
            
            timestamps = find(peak_train);
            afr = length(timestamps)/length(peak_train);
            
            
            %% Find the isi using cumulative averages of isi histogram
            isi = diff(find(peak_train))*1000/fs;
            
            bins = 0:max(isi); %doesn't matter what the max bin is
            isiCounts = histc(isi,bins);
            
            x=1:length(isiCounts);
            cumAvg = cumsum(isiCounts)'./x;
            
            f = figure();
            %bar(bins,isiCounts);
            hold on
            plot(bins,cumAvg,'-r');
            xlim([0,max(isi)]);
            
            skew = skewness(isi,0);
            
           
            if skew<1
                alpha1 = 1;
                alpha2 = 0.5;
            elseif skew<4
                alpha1 = 0.7;
                alpha2 = 0.5;
            elseif skew<9
                alpha1 = 0.5;
                alpha2 = 0.3;
            else
                alpha1 = 0.3;
                alpha2 = 0.1;
            end
            
            %% Find alpha1 threshold
            [maxVal,maxInd] = max(cumAvg);
            cumThreshCount1 = maxVal*alpha1;
            [~, idx1] = min(abs(cumAvg(maxInd+1:end) - cumThreshCount1));
            ISImaxsample1 = bins(maxInd+idx1);
            line([0,max(isi)],[cumThreshCount1,cumThreshCount1],'color','blue');
            line([ISImaxsample1,ISImaxsample1],[0,max(isiCounts)],'color','blue');
            
             
            %ISImaxsample1 = min([100*fs/1000,ISImaxsample1*fs/1000]);
            ISImaxsample1 = ISImaxsample1*fs/1000;
            
            %%Find alpha2 threshold
            cumThreshCount2 = maxVal*alpha2;
            [~, idx2] = min(abs(cumAvg(maxInd+1:end) - cumThreshCount2));
            ISImaxsample2 = bins(maxInd+idx2);
            
            line([0,max(isi)],[cumThreshCount2,cumThreshCount2],'color','blue');
            line([ISImaxsample2,ISImaxsample2],[0,max(isiCounts)],'color','blue');
            
            grid on
            close(f);
                        
            %ISImaxsample2 = min([200*fs/1000,ISImaxsample2*fs/1000]);
            ISImaxsample2 = ISImaxsample2*fs/1000;
            
            %displayed in ms
            %disp(sprintf('%f %f',ISImaxsample1*1000/fs,ISImaxsample2*1000/fs));
            %disp(1000/(fs*afr));
            %gather isi theshold info to a matrix
            isiChans(i-2,:)=[el,ISImaxsample1*1000/fs,ISImaxsample2*1000/fs,1000/(fs*afr)];
             
            isActiveChannel(el)=1;            
            
            timestamp=find(peak_train); % Vector with dimension [nx1]
            allisi  =[-sign(diff(timestamp)-ISImaxsample1)];
            allisi(find(allisi==0))=1;  % If the difference is exactly ISImax, I have to accept the two spikes as part of the burst
            edgeup1  =find(diff(allisi)>1)+1;  % Beginning of burst
            edgedown1=find(diff(allisi)<-1)+1; % End of burst
            
            allisi  =[-sign(diff(timestamp)-ISImaxsample2)];
            allisi(find(allisi==0))=1;  % If the difference is exactly ISImax, I have to accept the two spikes as part of the burst
            edgeup2  =find(diff(allisi)>1)+1;  % Beginning of burst
            edgedown2=find(diff(allisi)<-1)+1; % End of burst
            
            if ((length(edgedown1)>=2) && (length(edgeup1)>=2) && (length(edgedown2)>=2) && (length(edgeup2)>=2))
                
                %% Get bursts with intra burst spikes only
                barray_init=[];
                barray_end=[];
                
                if (edgedown1(1)<edgeup1(1))
                    barray_init=[timestamp(1), timestamp(edgedown1(1)), edgedown1(1), ...
                        (timestamp(edgedown1(1))-timestamp(1))/fs];
                    edgedown1=edgedown1(2:end);
                end
                
                if(edgeup1(end)>edgedown1(end))
                    barray_end= [timestamp(edgeup1(end)), timestamp(end), length(timestamp)-edgeup1(end)+1, ...
                        (timestamp(end)-timestamp(edgeup1(end)))/fs];
                    edgeup1=edgeup1(1:end-1);
                end
                
                barray1= [timestamp(edgeup1), timestamp(edgedown1), (edgedown1-edgeup1+1), ...
                    (timestamp(edgedown1)-timestamp(edgeup1))/fs];      % [init end nspikes duration-sec]
                barray1= [barray_init;barray1;barray_end];
                
                %% Get bursts with burst related spikes
                barray_init=[];
                barray_end=[];
                
                if (edgedown2(1)<edgeup2(1))
                    barray_init=[timestamp(1), timestamp(edgedown2(1)), edgedown2(1), ...
                        (timestamp(edgedown2(1))-timestamp(1))/fs];
                    edgedown2=edgedown2(2:end);
                end
                
                if(edgeup2(end)>edgedown2(end))
                    barray_end= [timestamp(edgeup2(end)), timestamp(end), length(timestamp)-edgeup2(end)+1, ...
                        (timestamp(end)-timestamp(edgeup2(end)))/fs];
                    edgeup2=edgeup2(1:end-1);
                end
                
                barray2= [timestamp(edgeup2), timestamp(edgedown2), (edgedown2-edgeup2+1), ...
                    (timestamp(edgedown2)-timestamp(edgeup2))/fs];      % [init end nspikes duration-sec]
                barray2= [barray_init;barray2;barray_end];
                 
                for t=1:size(barray2,1)
                    barray1Inds = find(barray1(:,1)>=barray2(t,1) &  barray1(:,2)<=barray2(t,2));
                    if ~isempty(barray1Inds)
                        barray1(barray1Inds(1),:)=barray2(t,:);
                        if length(barray1Inds>1)
                            barray1(barray1Inds(2:end),:)=[];
                        end
                    end
                end
                
                
               %% merge bursts that have a distance < isi2
               count = 1;
               while count<size(barray1,1)
                   if barray1(count+1,1)-barray1(count,2) <= ISImaxsample2
                       barray1(count,2) = barray1(count+1,2);
                       barray1(count,3) = nnz(timestamps >= barray1(count,1) & timestamps <= barray1(count+1,2));
                       barray1(count,4) = (barray1(count+1,2)-barray1(count,1))/fs;
                       barray1(count+1,:) = [];
                   else
                       count = count+1;
                   end
               end
               
                barray = barray1;
     
                
                clear 'barray1', 'barray2';
                burst_detection=barray(find(barray(:,3)>=nspikes),:); % Real burst statistics
                
                burstSize = zeros(size(burst_detection,1),3);
                for x=1:size(burst_detection,1)
                    
                    burstSize(x,1) = sum(peak_train(burst_detection(x,1):burst_detection(x,2))); % sum of all peak amplitudes in the burst
                    burstSize(x,2) = burstSize(x,1)/burst_detection(x,3); % average peak amplitude per spike in the burst
                    burstSize(x,3) = burstSize(x,1)/burst_detection(x,4); % average peak amplitude during the burst duration
                end
                
                
                [r,c]=size(burst_detection);
                acq_time=fix(length(peak_train)/fs); % Acquisition time  [sec]
                mbr=r/(acq_time/60);                 % Mean Bursting Rate [bpm]
                clear  edgeup edgedown
                
                % THRESHOLD EVALUATION
                if (mbr>0) % Save only if the criterion is met
                    
                    % OUTSIDE BURST Parameters
                    %%%%%%%%%%%%%%%%%%%%%% !!!!!WARNING!!!!! %%%%%%%%%%%%%%%%%%%%%%
                    tempburst= [(burst_detection(:,1)-1), (burst_detection(:,2)+1)];
                    % There is no check here: the +1 and -1 could be
                    % dangerous when indexing the peak_train vector
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    out_burst=reshape(tempburst',[],1);
                    out_burst=[1;out_burst; length(peak_train)];
                    out_burst= reshape(out_burst, 2, [])';
                    [rlines, clines]=size(out_burst);
                    outburst_cell= cell(rlines,7);
                    
                    for k=1:rlines
                        outb_period=(out_burst(k,2)-out_burst(k,1))/fs; % duration [sec] of the non-burst period
                        outbspikes= find(peak_train(out_burst(k,1):out_burst(k,2)));
                        
                        n_outbspikes=length(outbspikes);
                        mfob=n_outbspikes/outb_period;       % Mean frequency in the non-burst period
                        isi_outbspikes= diff(outbspikes)/fs; % ISI [sec] - for the spikes outside the bursts
                        f_outbspikes =1./isi_outbspikes;     % frequency between two consecutive spikes outside the bursts
                        
                        outburst_cell{k,1}= out_burst(k,1);  % Init of the non-burst period
                        outburst_cell{k,2}= out_burst(k,2);  % End of the non-burst period
                        outburst_cell{k,3}= n_outbspikes;    % Number of spikes in the non-burst period
                        outburst_cell{k,4}= mfob;            % Mean Frequency in the non-burst period
                        outburst_cell{k,5}= outbspikes;      % Position of the spikes in the non-burst period
                        outburst_cell{k,6}= isi_outbspikes;  % ISI of spikes in the non-burst period
                        outburst_cell{k,7}= f_outbspikes;    % Frequency of the spikes in the non-burst period
                    end
                    ave_mfob= mean(cell2mat(outburst_cell(:,4))); % Avearge frequency outside the burst - v1: all elements
                    % ave_mfob= mean(nonzeros(cell2mat(outburst_cell(:,4)))); % Average frequency outside the burst - v2: only non zeros elements
                    
                    % INSIDE BURST Parameters
                    binit= burst_detection(:,1); % Burst init [samples]
                    burst_event =sparse(binit, ones(length(binit),1), peak_train(binit)); % Burst event
                    bp= [diff(binit)/fs; 0];     % Burst Period [sec] - start-to-start
                    ibi= [((burst_detection(2:end,1)- burst_detection(1:end-1,2))/fs); 0]; % Inter Burst Interval, IBI [sec] - end-to-start
                    lastrow=[acq_time, length(find(peak_train)), r, sum(burst_detection(:,3)), mbr, ave_mfob, 0, 0, 0];
                    
                    burst_detection=[burst_detection, ibi, bp, burstSize; lastrow];
                    % burst_detection=[init, end, nspikes, duration, ibi, bp;
                    %  acquisition time, total spikes, total bursts, total burst spikes, mbr, average mfob]
                    
                    burst_detection_cell{el,1}= burst_detection; % Update the cell array
                    burst_event_cell{el,1}= burst_event;         % Update the cell array
                    outburst_spikes_cell{el,1}= outburst_cell;   % Update the cell array
                    
                    
                    clear rlines clines out_burst tempburst
%                     
%                     f4 = figure('Position',[1+100 scrsz(4)/2+100 scrsz(3)-200 200]);
%                                                         title(el);
%                                                         ylim([0,1]);
%                                                         hold on
%                             
%                                                         for k=1:length(timestamps)
%                                                             line([timestamps(k)/fs,timestamps(k)/fs],[0,0.5]);
%                                                         end
%                             
%                                                         xlim([0,max(timestamps/fs)]);
%                                                         for k=1:size(burst_detection,1)-1
%                                                             line([burst_detection(k,1)/fs,burst_detection(k,2)/fs],[0.6,0.6],'color','green','lineWidth',3);
%                                                         end
%                             
%                                                         close(f4);
%                                                         
                end
            end
            
            clear peak_train artifact allisi acq_time mbr barray timestamp
            clear r c ibi binit burst_detection burst_event edgedown edgeup lastrow
        end
        cd (phasedir)
    end
    
    % SAVE ALL FILES
    cd(end_folder1) % Burst array
    nome=strcat('burst_detection_', newdir);
    save(nome, 'burst_detection_cell','isActiveChannel');
    
    cd(end_folder2) % Burst event
    nome=strcat('burst_event_', newdir);
    save(nome, 'burst_event_cell');
    
    cd(end_folder3) % Outside Burst Spikes
    nome=strcat('outburst_spikes_', newdir);
    save(nome, 'outburst_spikes_cell');
    
    
    cd(peakfolder)
end


%%Initialize figure
f2 = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
ylim([0,60]);
hold on
channels = getMEA60Channels();
for k = 1:length(channels)
    BDcurElec = burst_detection_cell{channels(k)};
    for i=1:size(BDcurElec)-1
        x = [BDcurElec(i,1),BDcurElec(i,2)]/fs;
        y = [k k];
        line(x,y,'lineWidth',2);
    end
end

set(gca,'YTick',1:60);
set(gca,'YTickLabel',channels);
xlabel('Time(s)');
ylabel('Channels');
title('Detected bursts: Cumulative average method');
close(h);
%close(f2);


