function burstDetectionBAFRMultiwell(peakfolder, end_folder1, end_folder2, end_folder3, nspikes, fs,channels)
%burstDetectionBAFRMultiwell produces the burst detection outputs. This is
%called by the function PTSDAutoMultiwell.m

display=0;
 
% DEFINE LOCAL VARIABLES
first=3;
%read maxChannel as number of filtered channels
%maxChannel = max(channels);
maxChannel = length(channels);
coreMult = 4;
extMult = 3;
 
% START PROCESSING
cd(peakfolder)                       % start_folder in the MAIN program
 

if length(channels) <1;
    burst_detection_cell = cell(1,1);  % cell array containing the burst features for each channel
    burst_event_cell     = cell (1,1); % cell array containing the burst_event train for each channel
    outburst_spikes_cell = cell(1,1);  % cell array containing the random spikes features for each channel
    isActiveChannel = cell(1, 1);
    cd(end_folder1) % Burst array
    name=strcat('burst_detection.mat');
    save(name, 'burst_detection_cell','isActiveChannel');
    
    cd(end_folder2) % Burst event
    name=strcat('burst_event.mat');
    save(name, 'burst_event_cell');
    
    cd(end_folder3) % Outside Burst Spikes
    name=strcat('outburst_spikes.mat');
    save(name, 'outburst_spikes_cell');
    return;
end

% Initilaize figure
scrsz = get(0,'ScreenSize');
f2 = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
try
    ylim([0,length(channels)]);
catch 
    disp(length(channels));
end
hold on
 
 
    peakDir= pwd;
    peakFiles= dir('*.mat');
    noPeakFiles= length(peakFiles);
    
    if(noPeakFiles>first)
        h = waitbar(0,'Initializing waitbar...');
    end
    
    burst_detection_cell = cell(maxChannel+1,1);  % cell array containing the burst features for each channel
    burst_event_cell     = cell (maxChannel+1,1); % cell array containing the burst_event train for each channel
    outburst_spikes_cell = cell(maxChannel+1,1);  % cell array containing the random spikes features for each channel
    
    isActiveChannel = zeros(noPeakFiles,1); % array to store whether the channel has any peaks --> active
    
    isiChans = cell(noPeakFiles,5);
    
    for i= 1:noPeakFiles % FOR cycle on the single directory files
        filename = peakFiles(i).name;    % current PKD file
        electrode= filename(end-5:end-4); % current electrode [char]
        %el= str2num(electrode);           % current electrode [num]
        el= electrode; 
        if isempty(find([channels{:}] == el)) % if the channel is identified to be silent below the threshold, do not process
            continue;
        end
        
        waitbar((i-first+1)/(noPeakFiles-first+1),h,sprintf('%d out %d channels',i-first+1,noPeakFiles-first+1));
        
        load (filename);                  % 'peak_train' and 'artifact' are loaded
        
        if nnz(peak_train)>3
            
            %separate time into 500ms bins and find bins <afr
            timestamps = find(peak_train);
            
            %%Look for silent phases
            binWidth = fs/20; %1s
            noOfBins = floor(length(peak_train)/binWidth);
            binNos = timestamps./fs;
            counts = histc(binNos,0:noOfBins-1);
            counts = smooth(counts,10);
            
            
            levels = [0;counts<0.001;0];
            levels(noOfBins+1:end)=0;
            silentStarts = find(diff(levels)==1);
            silentEnds = find(diff(levels)==-1)-1;
            %             inds = (silentStarts==silentEnds);
            %             silentEnds(silentEnds<=1)=[];
            %             silentStarts(silentStarts>=noOfBins)=[];
            
            durs = silentEnds-silentStarts;
            silentStarts(durs<10)=[];
            silentEnds(durs<10)=[];
            durs = fs*durs;
            %             silentStarts = fs*silentStarts;
            %             silentEnds = fs*silentEnds;
            %
            if ~isempty(silentStarts)
                afrAll = length(find(peak_train))/length(peak_train); %average firing rate
                
                ISImaxsample1 = min([100*fs/1000,1/(coreMult*afrAll)]);
                ISImaxsample2  = min([200*fs/1000,1/(extMult*afrAll)]);
                
                if ISImaxsample1*1000/fs<100 || ISImaxsample2*1000/fs<200
                    if display==1
                        disp('inISI');
                    end
                    binWidth = fs;
                    noOfBins = floor(length(peak_train)/binWidth);
                    binNos = timestamps./binWidth;
                    binCounts = histc(binNos,0:noOfBins-1);
                    afrs = binCounts./binWidth;
                    afrs(afrs>afrAll) = [];
                    
                    bins = linspace(min(afrs),max(afrs),50);
                    counts = histc(afrs,bins);
%                     counts = real(log10(counts));
                    f = figure();
                    bar(counts);
                    close(f);
                    counts = smooth(counts,'lowess');
                    counts(counts<0)=0;
                    counts = [0;counts;0];
                    
                    [~,peakPos] = findpeaks(counts,'minpeakdistance',10);
                    peakPos = peakPos-1;
                    counts = counts(2:end-1);
                    
                    if display==1
                        f=figure();
                        plot(bins,counts);
                        grid minor
                        hold on
                        scatter(bins(peakPos),counts(peakPos),'markerfacecolor','green');
                      %  xlim([min(bins),max(bins)]);
                        xlabel('AFRs (spikes/s)');
                        ylabel('Frequency');
                    end
                    
                    if length(peakPos)>1 && counts(peakPos(1))/counts(peakPos(end))> 0.2  && nnz(counts(peakPos(2:end-1))./counts(peakPos(1)) > 1)==0 %% if multimodal,
                        [minVal,~] = min(counts(peakPos(1):peakPos(end)));
                        minPos = peakPos(1)-1+find(counts(peakPos(1):peakPos(end))==minVal);
                        intPeaks = peakPos(peakPos>minPos(1) & peakPos<minPos(end));
                        if ~isempty(intPeaks)
                            minPos = minPos(minPos>intPeaks(end));
                        end
                        afr =  (bins(minPos(1))+bins(minPos(end)))/2; %mean(afrs(afrs <= bins(minPos(end))));
                        if display==1
                            scatter(bins(floor((minPos(1)+minPos(end))/2)),counts(floor((minPos(1)+minPos(end))/2)),'markerfacecolor','red');
                            disp('condition1');
                        end
                        %                         afr = bins(peakPos(1)+minPos(end)-1);
                    else %length(peakPos)==1 && peakPos(1)>=25
                        afr = mean(afrs);
                        if display==1
                            disp('condition2');
                        end
                    end
                    if display==1
                        close(f);
                    end
                    
                    % find isiThreshs
                    ISImaxsample1 = min([100*fs/1000,1/(coreMult*afr)]);
                    ISImaxsample2  = min([200*fs/1000,1/(extMult*afr)]);
                    ISImaxsample3 = min([100*fs/1000,1/(coreMult*afrAll)]);
                    ISImaxsample4  = min([200*fs/1000,1/(extMult*afrAll)]);
                else
                    afr = afrAll;
                end
            else
                afrAll = length(timestamps)/(length(peak_train)-sum(durs));
                
                
                ISImaxsample1 = min([100*fs/1000,1/(coreMult*afrAll)]);
                ISImaxsample2  = min([200*fs/1000,1/(extMult*afrAll)]);
                
                
                if ISImaxsample1*1000/fs<100 || ISImaxsample2*1000/fs<200
                    
                    
                    binWidth = fs;
                    noOfBins = floor(length(peak_train)/binWidth);
                    binNos = timestamps./binWidth;
                    binCounts = histc(binNos,0:noOfBins-1);
                    afrs = binCounts./binWidth;
                    
                    afrs(afrs>afrAll | levels(2:end-1)) = [];
                    
                    bins = linspace(min(afrs),max(afrs),50);
                    counts = histc(afrs,bins);
                    counts = smooth(counts,20,'lowess');
                    counts(counts<0)=0;
                    counts = [0;counts;0];
                    
                    [~,peakPos] = findpeaks(counts,'minpeakdistance',10);
                    peakPos = peakPos-1;
                    counts = counts(2:end-1);
                    
                    if display==1
                        f=figure();
                        plot(bins,counts);
                        grid on
                        hold on
                        scatter(bins(peakPos),counts(peakPos),'markerfacecolor','green');
                        xlim([min(bins),max(bins)]);
                        xlabel('AFRs (spikes/s)');
                        ylabel('Frequency');
                    end
                    
                    if length(peakPos)>1 && counts(peakPos(1))/counts(peakPos(end))> 0.2  && nnz(counts(peakPos(2:end-1))./counts(peakPos(1)) > 1.5)==0
                        [minVal,~] = min(counts(peakPos(1):peakPos(end)));
                        minPos = peakPos(1)-1+find(counts(peakPos(1):peakPos(end))==minVal);
                        intPeaks = peakPos(peakPos>minPos(1) & peakPos<minPos(end));
                        if ~isempty(intPeaks)
                            minPos = minPos(minPos>intPeaks(end));
                        end
                        afr =  (bins(minPos(1))+bins(minPos(end)))/2; %mean(afrs(afrs <= bins(minPos(end))));
                        
                        if display==1
                            disp('condition1');
                            scatter(bins(floor((minPos(1)+minPos(end))/2)),counts(floor((minPos(1)+minPos(end))/2)),'markerfacecolor', 'red');
                        end
                        %afr = bins(peakPos(1)+minPos(end)-1);
                    else %length(peakPos)==1 && peakPos(1)>=25
                        afr = mean(afrs);
                        if display==1
                            disp('condition2');
                        end
                    end
                    
                    if display==1
                        close(f);
                    end
                    % find isiThreshs
                    ISImaxsample1 = min([100*fs/1000,1/(coreMult*afr)]);
                    ISImaxsample2  = min([200*fs/1000,1/(extMult*afr)]);
                    ISImaxsample3 = min([100*fs/1000,1/(coreMult*afrAll)]);
                    ISImaxsample4  = min([200*fs/1000,1/(extMult*afrAll)]);
                else
                    afr = afrAll;
                end
            end
            
            %             try
            %             disp(sprintf('ISIs old AFR: %f %f',ISImaxsample3*1000/fs,ISImaxsample4*1000/fs));
            %             end
            %             disp(sprintf('ISIs: %f %f',ISImaxsample1*1000/fs,ISImaxsample2*1000/fs));
            isiChans(i,1:5)={el,ISImaxsample1*1000/fs,ISImaxsample2*1000/fs,1000/(fs*afr),1000/(fs*afrAll)};
            
            if ~isempty(ISImaxsample1) && ~isempty(ISImaxsample2)
                
                isActiveChannel(find([channels{:}]==el))=1;
                timestamp=find(peak_train); % Vector with dimension [nx1]
                
                allisi  =[-sign(diff(timestamp)-ISImaxsample1)];
                allisi(find(allisi==0))=1;  % If the difference is exactly ISImax, I have to accept the two spikes as part of the burst
                edgeup1  =find(diff(allisi)>1)+1;  % Beginning of burst
                edgedown1=find(diff(allisi)<-1)+1; % End of burst
                
                if ((length(edgedown1)>=2) && (length(edgeup1)>=2))
                    
                    % Get bursts with intra burst spikes only
                    barray_init=[];
                    barray_end=[];
                    
                    if (edgedown1(1)<edgeup1(1))
                        barray_init=[timestamp(1), timestamp(edgedown1(1)), edgedown1(1), ...
                            (timestamp(edgedown1(1))-timestamp(1))/fs,1,edgedown1(1)];
                        edgedown1=edgedown1(2:end);
                    end
                    
                    if(edgeup1(end)>edgedown1(end))
                        barray_end= [timestamp(edgeup1(end)), timestamp(end), length(timestamp)-edgeup1(end)+1, ...
                            (timestamp(end)-timestamp(edgeup1(end)))/fs,edgeup1(end),length(timestamp)];
                        edgeup1=edgeup1(1:end-1);
                    end
                    
                    barray1= [timestamp(edgeup1), timestamp(edgedown1), (edgedown1-edgeup1+1), ...
                        (timestamp(edgedown1)-timestamp(edgeup1))/fs,edgeup1,edgedown1];      % [init end nspikes duration-sec]
                    barray1= [barray_init;barray1;barray_end];
                    
                    barray1=barray1(barray1(:,3)>=3,:);
                    
                    
                    allisi  =[-sign(diff(timestamp)-ISImaxsample2)];
                    allisi(allisi==0)=1;  % If the difference is exactly ISImax, I have to accept the two spikes as part of the burst
                    edgeup2  =find(diff(allisi)>1)+1;  % Beginning of burst
                    edgedown2=find(diff(allisi)<-1)+1; % End of burst
                    
                    % Get bursts with burst related spikes
                    if ((length(edgedown2)>=2) && (length(edgeup2)>=2))
                        
                        barray_init=[];
                        barray_end=[];
                        
                        if (edgedown2(1)<edgeup2(1))
                            barray_init=[timestamp(1), timestamp(edgedown2(1)), edgedown2(1), ...
                                (timestamp(edgedown2(1))-timestamp(1))/fs,1,edgedown2(1)];
                            edgedown2=edgedown2(2:end);
                        end
                        
                        if(edgeup2(end)>edgedown2(end))
                            barray_end= [timestamp(edgeup2(end)), timestamp(end), length(timestamp)-edgeup2(end)+1, ...
                                (timestamp(end)-timestamp(edgeup2(end)))/fs,edgeup2(end),length(timestamp)];
                            edgeup2=edgeup2(1:end-1);
                        end
                        
                        barray2= [timestamp(edgeup2), timestamp(edgedown2), (edgedown2-edgeup2+1), ...
                            (timestamp(edgedown2)-timestamp(edgeup2))/fs,edgeup2,edgedown2];      % [init end nspikes duration-sec]
                        barray2= [barray_init;barray2;barray_end];
                        
                        
                        % If a strict burst is found inside a diluted burst, expand the edges of the strict burst
                        for t=1:size(barray2,1)
                            barray1Inds = find(barray1(:,1)>=barray2(t,1) &  barray1(:,2)<=barray2(t,2));
                            if ~isempty(barray1Inds)
                                barray1(barray1Inds(1),:)=barray2(t,:);
                                if length(barray1Inds) > 1
                                    barray1(barray1Inds(2:end),:)=[];
                                end
                            end
                        end
                        
                    end
                    
                    clear 'barray2';
                    
                    barray = [];
                    if ~isempty(barray1)
                        
                        barray = barray1;
                        
                        clear 'barray1';
                        
                        % Take bursts that have spikes above the min Number of Spikes
                        burst_detection=barray(find(barray(:,3)>=nspikes),1:4); % Real burst statistics
                        
                        burstSize = zeros(size(burst_detection,1),3);
                        for x=1:size(burst_detection,1)
                            burstSize(x,1) = sum(peak_train(burst_detection(x,1):burst_detection(x,2))); % sum of all peak heights (was peak amps before) in the burst
                            burstSize(x,2) = burstSize(x,1)/burst_detection(x,3); % average peak heights per spike in the burst
                            burstSize(x,3) = burstSize(x,1)/burst_detection(x,4); % average peak heights during the burst duration
                            burstSize(x,4) = sum(amp_train(burst_detection(x,1):burst_detection(x,2))); % sum of all peak amplitudes in the burst
                            burstSize(x,5) = burstSize(x,4)/burst_detection(x,3); % average peak amplitude per spike in the burst
                            burstSize(x,6) = burstSize(x,4)/burst_detection(x,4); % average peak amplitude during the burst duration
                        end
                        
                        
                        [r,c]=size(burst_detection);
                        acq_time=fix(length(peak_train)/fs); % Acquisition time  [sec]
                        mbr=r/(acq_time/60);                 % Mean Bursting Rate [bpm]
                        clear  edgeup edgedown
                        
                        % THRESHOLD EVALUATION
                        if ~isempty(mbr) && mbr>0 % Save only if the criterion is met
                            
                            % OUTSIDE BURST Parameters
                            %%%%%%%%%%%%%%%%%%%%%% !!!!!WARNING!!!!! %%%%%%%%%%%%%%%%%%%%%%
                            tempburst= [(burst_detection(:,1)-1), (burst_detection(:,2)+1)];
                            % There is no check here: the +1 and -1 could be
                            % dangerous when indexing the peak_train vector
                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                            out_burst=reshape(tempburst',[],1);
                            out_burst=[1;out_burst; length(peak_train)];
                            out_burst= reshape(out_burst, 2, [])';
                            [rlines, clines]=size(out_burst);
                            outburst_cell= cell(rlines,7);
                            
                            % repeatedly calling find cost time. For dense
                            % data, it'll be faster to use find on the
                            % whole data once and identify spikes in the 
                            % required range
                            outbspikes_all = find(peak_train);
                            for k=1:rlines
                                outb_period=(out_burst(k,2)-out_burst(k,1))/fs; % duration [sec] of the non-burst period
                                % outbspikes= find(peak_train(out_burst(k,1):out_burst(k,2)));
                                outbspikes = outbspikes_all(outbspikes_all>=out_burst(k,1) & outbspikes_all<=out_burst(k,2)) - out_burst(k,1) + 1;
                                
                                n_outbspikes=length(outbspikes);
                                mfob=n_outbspikes/outb_period;       % Mean frequency in the non-burst period
                                isi_outbspikes= diff(outbspikes)/fs; % ISI [sec] - for the spikes outside the bursts
                                f_outbspikes =1./isi_outbspikes;     % frequency between two consecutive spikes outside the bursts
                                
                                outburst_cell{k,1}= out_burst(k,1);  % Init of the non-burst period
                                outburst_cell{k,2}= out_burst(k,2);  % End of the non-burst period
                                outburst_cell{k,3}= n_outbspikes;    % Number of spikes in the non-burst period
                                outburst_cell{k,4}= mfob;            % Mean Frequency in the non-burst period
                                outburst_cell{k,5}= outbspikes;      % Position of the spikes in the non-burst period
                                outburst_cell{k,6}= isi_outbspikes;  % ISI of spikes in the non-burst period
                                outburst_cell{k,7}= f_outbspikes;    % Frequency of the spikes in the non-burst period
                            end
                            ave_mfob= mean(cell2mat(outburst_cell(:,4))); % Avearge frequency outside the burst - v1: all elements
                            % ave_mfob= mean(nonzeros(cell2mat(outburst_cell(:,4)))); % Average frequency outside the burst - v2: only non zeros elements
                            
                            % INSIDE BURST Parameters
                            binit= burst_detection(:,1); % Burst init [samples]
                            burst_event =sparse(binit, ones(length(binit),1), peak_train(binit)); % Burst event
                            bp= [diff(binit)/fs; 0];     % Burst Period [sec] - start-to-start
                            ibi= [((burst_detection(2:end,1)- burst_detection(1:end-1,2))/fs); 0]; % Inter Burst Interval, IBI [sec] - end-to-start
                            lastrow=[acq_time, length(find(peak_train)), r, sum(burst_detection(:,3)), mbr, ave_mfob, 0, 0, 0, 0, 0, 0];
                            
                            burst_detection=[burst_detection, ibi, bp, burstSize; lastrow];
                            % burst_detection=[init, end, nspikes, duration, ibi, bp;
                            %  acquisition time, total spikes, total bursts, total burst spikes, mbr, average mfob]
                            index= find([channels{:}] == el);
                            burst_detection_cell{index,1}= burst_detection; % Update the cell array
                            burst_event_cell{index,1}= burst_event;         % Update the cell array
                            outburst_spikes_cell{index,1}= outburst_cell;   % Update the cell array
                            
                            
                            clear rlines clines out_burst tempburst
                            
                            % draw bursts
                            figure(f2);
                            if ~isempty(burst_detection)
                                for k=1:size(burst_detection,1)-1
                                    x = [burst_detection(k,1),burst_detection(k,2)]/fs;
                                    %chanNo = find(channels == el);
                                    %y = [chanNo chanNo];
                                    y=[index index];
                                    line(x,y,'lineWidth',2);
                                end
                            end
                            
                          
                        end
                    end
                end
                
            end
            
            clear peak_train artifact allisi acq_time mbr barray timestamp
            clear r c ibi binit burst_detection burst_event edgedown edgeup lastrow
        end
        cd (peakDir);
        
    end
    
    % SAVE ALL FILES
    cd(end_folder1) % Burst array
    name=strcat('burst_detection.mat');
    save(name, 'burst_detection_cell','isActiveChannel');
    
    cd(end_folder2) % Burst event
    name=strcat('burst_event.mat');
    save(name, 'burst_event_cell');
    
    cd(end_folder3) % Outside Burst Spikes
    name=strcat('outburst_spikes.mat');
    save(name, 'outburst_spikes_cell');
    
    
    cd(peakfolder);

 
set(gca,'YTick',1:noPeakFiles);
set(gca,'YTickLabel',channels);
xlabel('Time(s)');
ylabel('Channels');
title('Detected bursts: BAFR method');
close(h);
 
close(f2);
 
 
 


