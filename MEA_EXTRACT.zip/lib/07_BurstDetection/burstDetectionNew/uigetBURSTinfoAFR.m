function [nspikes,fs, cancelFlag]= uigetBURSTinfoAFR()
% Prompt a user-window for input information regarding burst detection

cancelFlag = 0;
nspikes = [];
fs     = [];

PopupPrompt = {'Min number of spikes',  ...
               'Sampling frequency (Hz)'};         
PopupTitle  =  'Burst Detection Settings';
PopupLines  =  1;
PopupDefault= {'5','10000'};
Ianswer     = inputdlg(PopupPrompt,PopupTitle,PopupLines,PopupDefault);

if isempty(Ianswer)
    cancelFlag = 1;
else
    nspikes = str2num(Ianswer{1,1});
    fs     = str2num(Ianswer{2,1});
end

clear Ianswer PopupPrompt PopupTitle PopupLines PopupDefault
