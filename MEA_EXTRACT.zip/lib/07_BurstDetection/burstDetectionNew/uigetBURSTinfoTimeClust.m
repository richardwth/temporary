function [binWidth, threshold, nspikes,fs, cancelFlag]= uigetBURSTinfoTimeClust()
% Prompt a user-window for input information regarding burst detection

cancelFlag = 0;
binWidth = [];
threshold = [];
nspikes = [];
fs     = [];

PopupPrompt = {'Bin width (ms)',  ...
               'Threshold', ...
               'Min number of spikes',...
               'Sampling frequency (Hz)'};         
PopupTitle  =  'Burst Detection Settings';
PopupLines  =  1;
PopupDefault= {'100','5','5','10000'};
Ianswer     = inputdlg(PopupPrompt,PopupTitle,PopupLines,PopupDefault);

if isempty(Ianswer)
    cancelFlag = 1;
else
    binWidth = str2num(Ianswer{1,1});
    threshold = str2num(Ianswer{2,1});
    nspikes = str2num(Ianswer{3,1});
    fs     = str2num(Ianswer{4,1});
end

clear Ianswer PopupPrompt PopupTitle PopupLines PopupDefault
