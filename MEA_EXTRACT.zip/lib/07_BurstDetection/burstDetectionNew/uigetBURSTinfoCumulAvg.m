function [nspikes,fs, cancelFlag]= uigetBURSTinfoCumulAvg()
% Prompt a user-window for input information regarding the current
% experiment for computing PSTH
% by Michela Chiappalone (18 Gennaio 2006, 16 Marzo 2006)
% modified by Noriaki (9 giugno 2006)

cancelFlag = 0;
nspikes= [];
min_mbr= [];
fs     = [];

PopupPrompt = {'Min number of intra-burst spikes',  ...               
               'Sampling frequency [spikes/sec]'};         
PopupTitle  =  'Burst Detection Settings';
PopupLines  =  1;
PopupDefault= {'3', '10000'};
Ianswer     = inputdlg(PopupPrompt,PopupTitle,PopupLines,PopupDefault);

if isempty(Ianswer)
    cancelFlag = 1;
else
    nspikes= str2num(Ianswer{1,1});
    fs     = str2num(Ianswer{2,1});
end

clear Ianswer PopupPrompt PopupTitle PopupLines PopupDefault
