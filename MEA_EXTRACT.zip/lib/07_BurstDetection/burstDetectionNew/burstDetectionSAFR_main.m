function burstDetectionSAFR_main


[start_folder]= selectfolder('Select the PeakDetectionMAT_files folder');
if strcmp(num2str(start_folder),'0')
    errordlg('Selection Failed - End of Session', 'Error');
    return
end

% -----------> INPUT FROM THE USER
[nspikes, fs, cancelFlag]= uigetBURSTinfoAFR;

if cancelFlag
     errordlg('Selection Failed - End of Session', 'Error');
    return
end
[exp_num]=find_expnum(start_folder, '_PeakDetection'); % Experiment number

% -----------> FOLDER MANAGEMENT
cd (start_folder);
cd ..
expfolder=pwd;
burstfoldername = strcat ('BurstDetectionMAT_', num2str(nspikes),'-BAFR'); % Burst files here
[burst_folder]=createresultfolder(expfolder, exp_num, burstfoldername); % Save path
[end_folder1]=createresultfolder(burst_folder, exp_num, 'BurstDetectionFiles');
[end_folder2]=createresultfolder(burst_folder, exp_num, 'BurstEventFiles');
[end_folder3]=createresultfolder(burst_folder, exp_num, 'OutBSpikesFiles');
clear burstfoldername expfolder

cd (start_folder)

% --------------> COMPUTATION PHASE: Burst Detection
burstDetectionBAFR(start_folder, end_folder1, end_folder2, end_folder3, nspikes, fs)


EndOfProcessing (start_folder, 'Successfully accomplished');

clear all