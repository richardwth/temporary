function burstdet_timeclust(peakfolder, end_folder1, end_folder2, end_folder3, binWidth, thr_mean,nspikes,fs)
% [tt,chcnt,dtt] = BURSTDET_TIMECLUST(spks, bin_s, thr_mean)
% Given a set of spikes SPKS loaded by LOADSPIKE or LOADSPIKE_NOC, finds
% synchronized bursts (on 5 or more channels).
% This works by first finding bursts on individual channels using TIMECLUST,
% and then finding synchronized bursts by clustering the single-channel
% bursts, again using TIMECLUST.
% Both BIN_S and THR_MEAN are optional; default values are 0.1 s and 5x
% resp.
%
% This two step approach is due to Andrew Wong. Code by DW, 6/25/02.

% matlab/burstdet_timeclust.m: part of meabench, an MEA recording
% and analysis tool
% Copyright (C) 2000-2002  Daniel Wagenaar (wagenaar@caltech.edu)

bin_s = binWidth/1000;

% DEFINE LOCAL VARIABLES
first=3;
channels = getMEA60Channels();

% START PROCESSING
cd(peakfolder)                       % start_folder in the MAIN program
peakfolderdir=dir;                   % struct containing the peak-det folders
NumPeakFolder=length(peakfolderdir); % number of experimental phases


%% Initilaize figure
scrsz = get(0,'ScreenSize');
f2 = figure('Position',[1+100 scrsz(1)+100 scrsz(3)-200 scrsz(4)-200]);
ylim([0,60]);
hold on


for m= first:NumPeakFolder  % FOR cycle on the phase directories
    phasedir=peakfolderdir(m).name;
    newdir=strcat (phasedir(8:end));
    cd (phasedir)
    phasedir= pwd;
    phasefiles= dir;
    NumPhaseFiles= length(phasefiles);
    burst_detection_cell = cell(88,1);  % cell array containing the burst features for each channel
    burst_event_cell     = cell (88,1); % cell array containing the burst_event train for each channel
    outburst_spikes_cell = cell(88,1);  % cell array containing the random spikes features for each channel
    
    isActiveChannel = zeros(88,1); % array to store whether the channel has any peaks --> active
    
    
    for i= first:NumPhaseFiles % FOR cycle on the single directory files
        filename = phasefiles(i).name;    % current PKD file
        electrode= filename(end-5:end-4); % current electrode [char]
        el= str2num(electrode);           % current electrode [num]
        
        load (filename);                  % 'peak_train' and 'artifact' are loaded
        
        if nnz(peak_train)>3
            
            isActiveChannel(el)=1;
            
            timestamps = find(peak_train);
            timestamps = timestamps./fs;
            [t0,cnt,dt,starts,stops]=timeclust(timestamps,bin_s,thr_mean);
            
            totMat = [t0',cnt',dt',starts',stops'];
            totMat(isnan(totMat(:,1)),:) = [];
            totMat(isnan(totMat(:,3)),:) = [];
            
            init = round(fs*totMat(:,4));
            endBurst = round(fs*totMat(:,5));
            
            barray = [init,endBurst,totMat(:,2),(endBurst-init)./fs]; %init end nspikes duration
            if ~isempty(barray)

                if barray(1,1)<1
                    barray(1,1)=1;
                end
                if barray(end,2)>length(peak_train)
                    barray(end,2)=length(peak_train);
                end
                %%Take bursts that have spikes above the min Number of Spikes
                burst_detection=barray(find(barray(:,3)>=nspikes),:); % Real burst statistics
                
                burstSize = zeros(size(burst_detection,1),3);
               
                for x=1:size(burst_detection,1)  
                   
                    burstSize(x,1) = sum(peak_train(burst_detection(x,1):burst_detection(x,2))); % sum of all peak amplitudes in the burst
                    burstSize(x,2) = burstSize(x,1)/burst_detection(x,3); % average peak amplitude per spike in the burst
                    burstSize(x,3) = burstSize(x,1)/burst_detection(x,4); % average peak amplitude during the burst duration
                end
                
                
                [r,c]=size(burst_detection);
                acq_time=fix(length(peak_train)/fs); % Acquisition time  [sec]
                mbr=r/(acq_time/60);                 % Mean Bursting Rate [bpm]
                
                % THRESHOLD EVALUATION
                if ~isempty(mbr) && mbr>0 % Save only if the criterion is met
                    
                    % OUTSIDE BURST Parameters
                    %%%%%%%%%%%%%%%%%%%%%% !!!!!WARNING!!!!! %%%%%%%%%%%%%%%%%%%%%%
                    tempburst= [(burst_detection(:,1)-1), (burst_detection(:,2)+1)];
                    % There is no check here: the +1 and -1 could be
                    % dangerous when indexing the peak_train vector
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    out_burst=reshape(tempburst',[],1);
                    out_burst=[1;out_burst; length(peak_train)];
                    out_burst= reshape(out_burst, 2, [])';
                    [rlines, clines]=size(out_burst);
                    outburst_cell= cell(rlines,7);
                    
                    for k=1:rlines
                        outb_period=(out_burst(k,2)-out_burst(k,1))/fs; % duration [sec] of the non-burst period
                        outbspikes= find(peak_train(out_burst(k,1):out_burst(k,2)));
                        
                        n_outbspikes=length(outbspikes);
                        mfob=n_outbspikes/outb_period;       % Mean frequency in the non-burst period
                        isi_outbspikes= diff(outbspikes)/fs; % ISI [sec] - for the spikes outside the bursts
                        f_outbspikes =1./isi_outbspikes;     % frequency between two consecutive spikes outside the bursts
                        
                        outburst_cell{k,1}= out_burst(k,1);  % Init of the non-burst period
                        outburst_cell{k,2}= out_burst(k,2);  % End of the non-burst period
                        outburst_cell{k,3}= n_outbspikes;    % Number of spikes in the non-burst period
                        outburst_cell{k,4}= mfob;            % Mean Frequency in the non-burst period
                        outburst_cell{k,5}= outbspikes;      % Position of the spikes in the non-burst period
                        outburst_cell{k,6}= isi_outbspikes;  % ISI of spikes in the non-burst period
                        outburst_cell{k,7}= f_outbspikes;    % Frequency of the spikes in the non-burst period
                    end
                    ave_mfob= mean(cell2mat(outburst_cell(:,4))); % Avearge frequency outside the burst - v1: all elements
                    % ave_mfob= mean(nonzeros(cell2mat(outburst_cell(:,4)))); % Average frequency outside the burst - v2: only non zeros elements
                    
                    % INSIDE BURST Parameters
                    binit= burst_detection(:,1); % Burst init [samples]
                    burst_event =sparse(binit, ones(length(binit),1), peak_train(binit)); % Burst event
                    bp= [diff(binit)/fs; 0];     % Burst Period [sec] - start-to-start
                    ibi= [((burst_detection(2:end,1)- burst_detection(1:end-1,2))/fs); 0]; % Inter Burst Interval, IBI [sec] - end-to-start
                    lastrow=[acq_time, length(find(peak_train)), r, sum(burst_detection(:,3)), mbr, ave_mfob, 0, 0, 0];
                    
                    burst_detection=[burst_detection, ibi, bp, burstSize; lastrow];
                    % burst_detection=[init, end, nspikes, duration, ibi, bp;
                    %  acquisition time, total spikes, total bursts, total burst spikes, mbr, average mfob]
                    
                    burst_detection_cell{el,1}= burst_detection; % Update the cell array
                    burst_event_cell{el,1}= burst_event;         % Update the cell array
                    outburst_spikes_cell{el,1}= outburst_cell;   % Update the cell array
                    
                    
                    clear rlines clines out_burst tempburst
                    
                    %% draw bursts
                    if ~isempty(burst_detection)
                        for k=1:size(burst_detection,1)-1
                            x = [burst_detection(k,1),burst_detection(k,2)]/fs;
                            chanNo = find(channels == el);
                            y = [chanNo chanNo];
                            line(x,y,'lineWidth',2);
                        end
                    end
                    
%                     f4 = figure('Position',[1+100 scrsz(4)/2+100 scrsz(3)-200 200]);
%                     title(el);
%                     ylim([0,1]);
%                     hold on
%                     
%                     for k=1:length(timestamps)
%                         line([timestamps(k)/fs,timestamps(k)/fs],[0,0.5]);
%                     end
%                     
%                     xlim([0,max(timestamps/fs)]);
%                     for k=1:size(burst_detection,1)-1
%                         line([burst_detection(k,1)/fs,burst_detection(k,2)/fs],[0.6,0.6],'color','green','lineWidth',3);
%                     end
%                     
%                     close(f4);
                end
            end
            %
            %     t0s=[t0s t0];
            %     dts=[dts dt];
            %     chs=[chs repmat(c,1,length(t0))] ;
            
            
        end
        cd (phasedir);
        
    end
    
    % SAVE ALL FILES
    cd(end_folder1) % Burst array
    nome=strcat('burst_detection_', newdir);
    save(nome, 'burst_detection_cell','isActiveChannel');
    
    cd(end_folder2) % Burst event
    nome=strcat('burst_event_', newdir);
    save(nome, 'burst_event_cell');
    
    cd(end_folder3) % Outside Burst Spikes
    nome=strcat('outburst_spikes_', newdir);
    save(nome, 'outburst_spikes_cell');
    
    
    cd(peakfolder);
end

set(gca,'YTick',1:60);
set(gca,'YTickLabel',channels);
xlabel('Time(s)');
ylabel('Channels');
title('Burst detection: Time clustering method');

close(f2);


%[tt,chcnt,dtt] = timeclust(t0s,.25,[],thr_mean);
