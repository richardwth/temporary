function [nspikes, fs, cancelFlag]= uigetWaginfo()
% Prompt a user-window for input information regarding the current
% experiment for computing PSTH
% by Michela Chiappalone (18 Gennaio 2006, 16 Marzo 2006)
% modified by Noriaki (9 giugno 2006)

cancelFlag = 0;
nspikes= [];
fs     = [];

PopupPrompt = {'Min number of intra-burst spikes','Sampling frequency [spikes/sec]'};         
PopupTitle  =  'Burst Detection Settings';
PopupLines  =  1;
PopupDefault= {'3','20000'};
Ianswer     = inputdlg(PopupPrompt,PopupTitle,PopupLines,PopupDefault);

if isempty(Ianswer)
    cancelFlag = 1;
else
    % use str2double instead of str2num for efficiency - Richard 1-May-2019
    nspikes= str2double(Ianswer{1,1});
    fs     = str2double(Ianswer{2,1});
end

clear Ianswer PopupPrompt PopupTitle PopupLines PopupDefault
