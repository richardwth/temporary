function splitNBsWithSpikes()

fs = 10000;
voidParamTh = 0.8;
scrsz = get(0,'ScreenSize');

answer = inputdlg({'Burst Detection File Name','Network Burst Detection File Name'},'Net Patterns Parameters',1,{'BurstDetectionMAT_5-SAFR','*NetworkBurstDetectionFilesBO*'});
burstDetectionStr = strcat('*',answer{1},'*');
nbDetectionStr = strcat('*',answer{2},'*');

upperRootFolder = uigetdir(pwd,'Select the root folder');

cd(upperRootFolder);

folderList = dir('*M3 W3*');

%%get peak files
for x = 1:length(folderList)
    
    cd(upperRootFolder);
    rootFolder = folderList(x).name;
    cd(rootFolder);
    
    disp(rootFolder);
    
    list = dir('*');
    nbFolderName = list(3).name;
    cd(nbFolderName);
    
    list = dir('*PeakDetectionMAT*');
    nbFileName = list(1).name;
    cd(nbFileName);
    
    list = dir('*ptrain*');
    nbFolderName = list(1).name;
    cd(nbFolderName);
    list = dir('*ptrain*.mat');
    
    timestamps = [];
    for i=1:length(list)
        load(list(i).name);
        timestamps = [timestamps;find(peak_train)];
    end
    
    timestamps = sort(timestamps);
    
    cd ..
    cd ..
    
    %%Get network bursts
    list = dir(burstDetectionStr);
    nbFileName = list(1).name;
    cd(nbFileName);
    
    disp('Analysing network burst detection files');
    list = dir(nbDetectionStr);
    nbFolderName = list(1).name;
    cd(nbFolderName);
    list = dir('*NetworkBurstDetection*.mat');
    for i=1:length(list)
        if isempty(strfind(list(i).name,'parameters'))
            nbFileName = list(i).name;
            break;
        end
    end
    
    load(fullfile(pwd,nbFileName));
    
    NBStarts = [];
    NBEnds = [];
            
    for i=1:size(netBursts,1)
        startTime = netBursts(i,1);
        endTime = netBursts(i,2);
        spikesInNb = timestamps(timestamps>=startTime & timestamps<=endTime);
       
        spikesInNb = spikesInNb-startTime;
        
        binWidth = fs/200;
        
        bins = spikesInNb./binWidth;
        simBursts = histc(bins,0:(endTime-startTime)/binWidth);
        simBursts = simBursts(1:end-1);
        simBurstsRaw = simBursts;
        simBursts = smooth(simBursts,10,'lowess');
        f = figure();
        plot(simBursts);
        hold on
        
        [vals,pos] = findpeaks(simBursts,'minpeakdistance',ceil(length(simBursts)/50),'minpeakheight', max(simBursts)*0.25);
        
        if length(vals)>1
            
            sepInds = 0; % take 0 as the starting point to seperate bursts
            
            [sepIndsNew,flag] = splitToTwo([vals,pos],voidParamTh,simBursts);
            sepIndsNew = sort(sepIndsNew);
            sepInds = [sepInds;sepIndsNew];
%             j = 1;
%             while  j<=numOfSecondPeaks
%                 y1 = vals(j);
%                 found = 0;
%                 for m=j+1:length(vals)
%                     y2 = vals(m);
%                     [yMin,tempIdxMin] = min(simBursts(pos(j):pos(m)));
%                     % the void parameter is a measure of the degree of separation
%                     % between the two peaks through the minimum
%                     voidParameter = 1-(yMin/sqrt(y1.*y2));
%                     if voidParameter>=voidParamTh
%                         sepInds = [sepInds;tempIdxMin+pos(j)-1];
%                         found = 1;
%                         break;
%                     end
%                 end
%                 if found==1
%                     j=m;
%                 else
%                     j=j+1;
%                 end
%             end
            
            
            
            scatter(sepInds,zeros(length(sepInds),1),'markerfacecolor','red');
            
            sepInds = sepInds*binWidth;
            
            sepInds = startTime+sepInds;
            sepInds = [sepInds;endTime]; %add the last index as the ending point to separate bursts
           
            
            for j=1:length(sepInds)-1
                %firstBurst = NBFirstBurst(k)+find(burstStarts<sepInds(j+1) & burstStarts>=sepInds(j),1)-1;
                %lastBurst = NBFirstBurst(k)+find(burstStarts<sepInds(j+1) & burstStarts>=sepInds(j),1,'last')-1;
                NBStarts = [NBStarts;sepInds(j)];
                NBEnds = [NBEnds;sepInds(j+1)-1];
            end
        else
            NBStarts = [NBStarts;netBursts(i,1)];
            NBEnds = [NBEnds;netBursts(i,2)];
        end
        close(f);
    end
    
    netBursts = [NBStarts,NBEnds,zeros(length(NBStarts),1),NBEnds-NBStarts];
    cd ..
    
    mkdir(strcat(nbFolderName,'New'));
    cd(strcat(nbFolderName,'New'));
    save(nbFileName,'netBursts');
end


