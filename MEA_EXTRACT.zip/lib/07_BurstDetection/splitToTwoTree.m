function [splitPos,flag,voidParameter] = splitToTwoTree(valPos,voidParamTh,simBursts)

if size(valPos,1)<2
    splitPos=[];
    voidParameter=[];
    flag = 0;
    return
end

valPos = sortrows(valPos,-1);

y1 = valPos(1,1);
y2 = valPos(2,1);
index1 = min([valPos(1,2),valPos(2,2)]);
index2 = max([valPos(1,2),valPos(2,2)]);
[yMin,tempIdxMin] = min(simBursts(index1:index2));
% the void parameter is a measure of the degree of separation
% between the two peaks through the minimum
voidParameter = 1-(yMin/sqrt(y1.*y2));
if voidParameter>=voidParamTh
    flag = 1;
    splitPos = tempIdxMin+index1-1; 
    valPosL = valPos(valPos(:,2)<=splitPos,:);
    valPosR = valPos(valPos(:,2)>splitPos,:);
    [splitPosL,flagL,voidParamL] = splitToTwoTree(valPosL,voidParamTh,simBursts);
    if flagL==1
        splitPos = [splitPos;splitPosL];
        voidParameter = [voidParameter;voidParamL];
    end
    [splitPosR,flagR,voidParamR] = splitToTwoTree(valPosR,voidParamTh,simBursts);
    if flagR==1
        splitPos = [splitPos;splitPosR];
        voidParameter = [voidParameter;voidParamR];
    end
%     
%     f = figure();
%     plot(simBursts);
%     hold on
%     scatter(splitPos,zeros(length(splitPos),1),'markerfacecolor','red');
%      close(f);
     
else
    splitPos=[];
    flag = 0;
    voidParameter=[];
    return;
end

