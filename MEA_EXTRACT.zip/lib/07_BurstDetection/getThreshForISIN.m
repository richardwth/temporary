function isiN = getThreshForISIN(spikes,nspikes)

f=figure();
hold on

isis = spikes(nspikes:end)-spikes(1:end-nspikes+1);
bins = 10.^[log10(min(isis)):0.05:log10(max(isis))];
counts = histc(isis,bins);
counts = smooth(counts,10,'lowess');

plot(bins,counts);

set(gca,'xscale','log') ;
set(gca,'yscale','log') ;

counts = real(log10(counts));
counts(isinf(counts))=min(counts(~isinf(counts)));
if min(counts)<0
    counts = counts+abs(min(counts));
end
[val,pos]=findpeaks(counts,'minpeakdistance',round(length(counts)/5));

if length(val)>1
    voidParameter = 100000;
    minPos = 0;
    for j=1:length(val)-1
        for k=j+1:length(val)
            [minValTemp,minPosTemp] = min(counts(pos(j):pos(k)));
            voidParam1 = 1-minValTemp/(sqrt(val(j)*val(k)));
            voidParam2 = (max([val(j),val(k)])-minValTemp)/(min([val(j),val(k)])-minValTemp);
            if voidParam2<voidParameter && (voidParam2<2 || voidParam1>0.7)
                voidParameter = voidParam2;
                minPos = pos(j)+minPosTemp-1;
            end
        end
    end
    if minPos~=0
        isiN = bins(minPos);
    else
        isiN=NaN;
    end
else
    isiN = NaN;
end

close(f);