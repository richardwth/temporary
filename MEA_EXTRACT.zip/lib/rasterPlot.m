function rasterPlot(raw_data, t_start)
%% Draws Rasterplot on a 30sec window from the random start point specified in the upper wrapper. 
    sampleRate = 20000;
    sampleTime = 1/sampleRate;
    sampleCount = length(raw_data);

    
    start_ix = str2num(char(t_start)) * sampleRate; %floor(random_start*sampleCount);
    rand_count = 30*sampleRate;

    if (start_ix + rand_count) > sampleCount
        start_ix = sampleCount-rand_count;
    end
    
    
    data_interval = raw_data(start_ix:start_ix + rand_count);
    
    
    %dataImport(); %Loads the data to the plotting function

%     exampleData = roundn(random('unif', -1,1,sampleCount,1),-1); %create a example data set
    indices = find(data_interval) - 1;
    timeStamps = [indices.*sampleTime]';
    
    %timeVector = [0:sampleTime:sampleCount*sampleTime];

%     XY = [timeVector timeStamps; zeros(size(timeVector)) ones(size(timeStamps)) ];
% 
%     C = sortrows(XY',1)';

    %plot(C(1,:),C(2,:));
    
    xlim([0 rand_count*sampleTime]);

    for i = 1:length(timeStamps)
        line([timeStamps(i) timeStamps(i)],[0 1],'Color','k');
    end
   
end
