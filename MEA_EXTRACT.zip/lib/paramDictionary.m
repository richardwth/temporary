
c = containers.Map;

c('meanSCBDuration(ms)') = 'Mean duration of all single channel bursts in all bursting channels';
c('stdSCBDuration(ms)') = 'Standard deviation of durations of all single channel bursts in all bursting channels';
c('cvSCBDuration') = 'Coefficient of variation of durations of all single channel bursts in all bursting channels';
c('rangeSCBDuration(ms)') = 'Range of  durations of all single channel bursts in all bursting channels';
c('meanSCBSize') = 'Mean number of spikes in single channel bursts in all bursting channels';
c('stdSCBSize') = 'Standard deviation of the number of spikes in single channel bursts in all bursting channels';
c('cvSCBSize')  = 'Coefficient of variation of the number of spikes in single channel bursts in all bursting channels';
c('rangeSCBSize') = 'Range of the number of spikes in single channel bursts in all bursting channels';
c('avgChansInNB') = 'Average number of channels that participate in network bursts';
c('meanDuration(ms)') = 'Mean duration of network bursts';
c('stdDuration(ms)') = 'Standard deviation of the durations of network bursts';
c('cvDuration') = 'Coefficient of variation of durations of network bursts';
c('rangeDuration(ms)') = 'Range of durations of network bursts';
c('meanInbis(s)') = 'Mean inter network burst interval';
c('stdInbis(s)') = 'Standard deviation of inter network burst intervals';
c('cvInbis') = 'Coefficient of variation of inter network burst intervals';
c('rangeInbis(s)') = 'Range of inter network burst intervals';
c('meanJitter(ms)') = 'Mean jitter between single channel bursts participating in a network burst';
c('stdJitter(ms)') = 'Standard deviation of the jitter between single channel bursts participating in a network burst';
c('cvJitter') = 'Coefficient of variation of the jitter between single channel bursts participating in a network burst';
c('rangeJitter(ms)') = 'Range of the jitter between single channel bursts participating in a network burst';
c('NBRate') = 'Number of network bursts per second';
c('totNoOfSpikes') = 'Mean number of spikes included in a network burst in all channels';
c('totNBAmp(uV)') = 'Sum of amplitudes of all spikes included inside a network burst averaged across all network bursts. Isolated spikes that occur during the network burst but are not included in a single channel burst are not considered';
c('avgNBPeakAmp(uV)') = 'Mean amplitude of spikes included in a network burst. NBPeakAmp = TotNBAmp/Number of spikes in the NB';
c('avgNBTimeAmp(uVperS)') = 'Time-wise mean of the amplitudes of spikes included in a network burst. NBTimeAmp = TotNBAmp/NB Duration';
c('mfrAll') = 'Mean firing rate of a channel=  (Total number of spikes in the channel)?(Recording time)';
c('mfrIn') = 'Mean firing rate inside bursts';
c('mfrOut') = 'Mean firing rate outside bursts';
c('mfrRatio') = 'Ratio between MFRIn to MFROut (MFR Ratio = MFRIn/MFROut)';
c('avgSpikesInNB') = 'Mean number of spikes included in a network burst';
c('avgAmp(uV)') = 'Mean amplitude of spikes averaged across all spikes of all channels';
c('%spikesInNBs') = 'Percentage of spikes included in single channels bursts. Isolated spikes that occur during a network burst are not considered as included within a burst';
c('meanNBSI(s)') = 'Mean interval between successive network burst starts';
c('stdNBSI(s)') = 'Standard deviation of the intervals between successive network burst starts';
c('cvNBSI') = 'Coefficient of variation of the intervals between successive network burst starts';
c('rangeNBSI(s)') = 'Range of the intervals between successive network burst starts';

disp(keys(c)')