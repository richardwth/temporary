%% mea_extract_to_excel (params) : 

% This file is to be called from the UI components. With this we can use
% the back-end as an API. 

function mea_extract_to_excel(upperRootFolder, burstDetectionStr, nbDetectionStr,...
    steps, filter, cutoff, plp, rp, nstd, recordingTime,...
    frequency, threshold, sampleRate, rasters, r_st, r_en,...
    saveFileName, saveFilePath, nspikes, nb_th, nb_split, ...
    resample_frequency, use_single_precision, use_parallel)
%% prepare folder and log
    scriptPath = pwd;
    addpath(genpath(fullfile(scriptPath, 'lib')));
    log_file_name = fullfile(upperRootFolder, 'execution_log.xlsx');

%% Data Processing Begins...
    %Execute H5 data conversion.
    if steps(1)
        st = datetime;
        disp('Converting H5 files to .mat format');
        IntegratedGenericConvert(upperRootFolder, filter, cutoff, frequency,...
             resample_frequency, use_single_precision, use_parallel);
        et = datetime;
        elapsed = et - st;
        
        % Execution Log 
        log_struct = struct;
        log_struct.execution_time = elapsed;
        log_struct.filter = filter;
        log_struct.cutoff = cutoff;
        
        table_log = struct2table(log_struct);
        
        disp(table_log);
        writetable(table_log, log_file_name, 'Sheet', 1);
    end
    cd(scriptPath)
    %Execute Spikes, Burst and Network Burst Detection
    if steps(2)
        st = datetime;
        disp('Execute Precision Timing Spike Detection (PTSD)');
        PTSDCancelFlag = 0;
        IntegratedPTSDAutoMultiwell(upperRootFolder, plp, rp, ...
            nstd, frequency, PTSDCancelFlag, recordingTime,...
            nspikes, nb_th, frequency, nb_split, threshold, sampleRate, use_parallel)
        et = datetime;
        elapsed = et-st;
        
        %Execution Log
        log_struct = struct;
        log_struct.execution_time = elapsed;
        log_struct.plp = plp;
        log_struct.rp = rp;
        log_struct.nstd = nstd;
        log_struct.frequency = frequency;
        log_struct.recordingTime = recordingTime;
        log_struct.nspikes = nspikes;
        log_struct.nb_th = nb_th;
        log_struct.nb_split = nb_split;
        log_struct.act_threshold = threshold;
        table_log = struct2table(log_struct);
        
        disp(table_log);
        writetable(table_log, log_file_name, 'Sheet', 2);
    end
    cd(scriptPath)
    %Execute Output Geenration
    if steps(3)
        
        if rasters
            raster_start = r_st;
            raster_end = r_en;
        else
            raster_start = 0;
            raster_end = 0;
        end
        fileName = saveFileName;
        path = saveFilePath;
        st = datetime;

        dataParams = IntegratedSaveParamsFilteredMultiwell(upperRootFolder,...
            burstDetectionStr, nbDetectionStr, frequency, threshold, sampleRate,...
            fileName, path, rasters, raster_start, raster_end,use_parallel);
        et = datetime;
        elapsed = et-st;
        
        
        log_struct = struct;
        log_struct.execution_time = elapsed;
        log_struct.burstDetectionStr = burstDetectionStr;
        log_struct.frequency = frequency;
        log_struct.threshold = threshold;
        log_struct.fileName = fileName;
        log_struct.path = path;
        log_struct.rasters = rasters;
        log_struct.raster_start = raster_start;
        log_struct.raster_end = raster_end;
        table_log = struct2table(log_struct);
        
        disp(table_log);
        writetable(table_log, log_file_name, 'Sheet', 3);
        
    end
    cd(scriptPath)  
        
end