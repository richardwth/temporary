%drawAltRasterPlot function is adotped from that used in Ashwin's
%ResultsGenv_1.2.It generates the raster plots for the original values for
%each well considering all the channels and outputs the indices of the
%channnels after applying the threshold filter. 

function y = drawAltRasterPlot(peakDataDirectory,fpath,wellName,threshold,sampleRate)
%y is a cell array to support string channel labels 
y={};
%Hard coded channel indices 
% channels = read_channel_ids(peakDataDirectory);%[12:13,21:24,31:34,42:43];
directory = peakDataDirectory;
matnames = dir(peakDataDirectory);
chanIDs = [];

for ix = (3: length(matnames)); % read channel IDS from the file names after conversion
    [~,fname,~] = fileparts(matnames(ix).name);
    fparts = strsplit(fname, '_');
    chanIDs = [chanIDs, string(fparts(end))];
end

channels = chanIDs;
numchannels= numel(channels);
folder = what(directory);
matfiles  = folder.mat;

for i = 1 :numel(matfiles)
    peakTrain{i} = load(strcat(directory,'/',char(matfiles(i))),'peak_train');    
end

peakCount = zeros(1,numchannels); 
%Iterate through numchannels
for n = 1 : numchannels
   % peakCount(n) = numel(find(full(peakTrain{n}.peak_train)));
   peakCount(n) = numel(find(peakTrain{n}.peak_train)); % find support sparse vector
end

%calculate the firing rate per channel

firingRate = zeros(1,numchannels);
recordingTime = zeros(1,numchannels);
iter = 1;
for n = 1 : numchannels
    sampleCount = numel(peakTrain{n}.peak_train);
    sampleRate = 20000; %%If sample rate was changed, amend it here
    %sampleRate = getSampleRate;
    sampleTime = 1/sampleRate;
    recordingTime(n) = sampleCount*sampleTime;
    firingRate(n) = peakCount(n)/recordingTime(n);
    if firingRate(n) > threshold
        y{iter} = channels(n);
        iter=iter+1;
    end
end


end
% %tabulate the above the data
% %fileMatrix = ["Channel", "Spike Count","Time", "Firing Rate"];
% fileMatrix = {'Channel', 'Spike Count','Time', 'Firing Rate'};
% table = zeros(12,3);
% 
% for i = 1:12
%     table(i,1) = i;
%     table(i,2) = peakCount(i);
%     table(i,3) = recordingTime(i);
%     table(i,4) = firingRate(i);
% end
% 
% % filename = 'W:\results test';
% 
% %Save the above data in an excel sheet
% 
% fileName = strcat(fpath,'/',wellName);
% xlswrite(fileName,fileMatrix,'A1:D1');
% xlswrite(fileName,table,'A2:D13');
% 
