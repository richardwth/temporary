function dataParams = IntegratedSaveParamsFilteredMultiwell(upperRootFolder, ...
    burstDetectionStr, nbDetectionStr, frequency, threshold, sampleRate, save_fileName,...
    save_path, plot_raster, raster_start, raster_end, use_parallel)
%saveParamsMultiwell extracts the statistical parameters from the burst
%detection files created by Precision Time Spike Detection algorithm
%   use the dialog boxes to specify the regular expressions for the Burst
%   Detection File Name, Network Burst Detection File Name and frequency.
%   authored by Dulini Mendis - Annotated by Damith Senanayake


% threshold = str2double(inputdlg('Enter Threshold Level','Threshold Level',1,{'0.25'}));
% Initialize data %'maxIbeiLog','startPeak','IBeiAreaUnder10',
dataParams = {'meanSCBDuration(ms)','stdSCBDuration(ms)','cvSCBDuration','rangeSCBDuration(ms)','meanSCBSize','stdSCBSize','cvSCBSize','rangeSCBSize'...
    ,'avgChansInNB','meanDuration(ms)','stdDuration(ms)','cvDuration','rangeDuration(ms)',...
    'meanInbis(s)','stdInbis(s)','cvInbis','rangeInbis(s)','meanJitter(ms)','stdJitter(ms)','cvJitter','rangeJitter(ms)',...
    'NBRate','totNoOfSpikes','totNBAmp(uV)','avgNBPeakAmp(uV)','avgNBTimeAmp(uVperS)',...
    'mfrAll','mfrIn','mfrOut','mfrRatio','noOfSpikingChans','%chansInNBs','avgSpikesInNB','avgAmp(uV)','%spikesInNBs','meanNBSI(s)','stdNBSI(s)','cvNBSI','rangeNBSI(s)','Kappa'...
    'name','well'};

% parfor requires all parameters to pass in, whether they are used or not. 
% Thus, in the case plot_raster is false, wellType, startTime, endTime, 
% screen_size, saveFolder should be created anyway.
wellType = 2;
startTime = raster_start;
endTime = raster_end; 
screen_size = get(0,'ScreenSize');
% if wellType==1
%     all_channels = getMEA60Channels();
% else
%     all_channels = getMultiwell12Channels(); % Use all channels because raster plots require all channels
% end 
saveFolder = upperRootFolder;


%netParams = cell(1,length(channels)+1);

% Get the upper root folder

% The upperRootFolder should be set to the Folder that contains multiple
% experiments. If there is only one experiment, then the parent folder
% where the experiment data is stored must be selected.
cd(upperRootFolder);

folderList = dir('*');
% sampleRate = str2double(inputdlg('Enter the default sampling rate','sampling rate',1,{'20000'}));

% Iterate for all folders in the upper r0ot folder
%Edited by Damayanthi : Look only for folders within the root folder.
isDir = [folderList(:).isdir];

folderList= {folderList(isDir).name}';
groups=containers.Map;

dataParamsAllFolders = cell(length(folderList)-3+1, 1);
for fiter = 3:length(folderList)
        
    
    cd(upperRootFolder);
    
    % Go into a folder for 1 sample
    lowerRootFolder = folderList{fiter};
    fprintf('Analyzing...%s\n',lowerRootFolder);
    
    % the sample folder as the root folder
    cd(lowerRootFolder);
    rootFolderPath = pwd;
    name = lowerRootFolder;
    wellList = dir('*Well*');
    group_no = regexp(name, 'G\d', 'match');

    
    
    load('lengths.mat');
    dataParamsSingleFolder=cell(length(wellList), length(dataParams));
    if use_parallel
        lengthWellRecords = zeros(1, length(wellList));
        for j=1:length(wellList)
            well_name = wellList(j).name;
            lengthWellRecords(j) = lengths_map(well_name);
        end
        parfor j=1:length(wellList)     
           well_name = wellList(j).name;
           lengthWellRecord = lengthWellRecords(j);
           % Raster Plot Generation (If applicable)
           if plot_raster
                GenerateRasterPlot(well_name, burstDetectionStr, nbDetectionStr,... 
                    frequency, wellType, startTime, endTime, screen_size, ...
                    saveFolder, lowerRootFolder)
           end
           % Parameter Saving Steps
           dataSet = SaveParameters(rootFolderPath, well_name, lengthWellRecord, ...
               burstDetectionStr, nbDetectionStr, frequency, threshold, sampleRate, ...
               lowerRootFolder);
           dataParamsSingleFolder(j, :)=dataSet;
        end
    else
        for j=1:length(wellList)
            well_name = wellList(j).name;
            lengthWellRecord = lengths_map(well_name);
            % Raster Plot Generation (If applicable)
            if plot_raster
                GenerateRasterPlot(well_name, burstDetectionStr, nbDetectionStr,... 
                    frequency, wellType, startTime, endTime, screen_size, ...
                    saveFolder, lowerRootFolder)
            end
            % Parameter Saving Steps
            dataSet = SaveParameters(rootFolderPath, well_name, lengthWellRecord, ...
                burstDetectionStr, nbDetectionStr, frequency, threshold, sampleRate, ...
                lowerRootFolder);
            dataParamsSingleFolder(j, :)=dataSet;
        end
    end
    dataParamsAllFolders{fiter-2} = dataParamsSingleFolder;
end

% concatenate all data into dataParams
for fiter = 3:length(folderList)
    dataParams = vertcat(dataParams,dataParamsAllFolders{fiter-2});
end
assignin('base', 'dataParams', dataParams)

 %get output file name
[~,fileName,~] = fileparts(save_fileName);


% save as mat file
save(fullfile(save_path,strcat(fileName,'.mat')),'dataParams');
% save as excel file
xlswrite(fullfile(save_path,strcat(fileName,'.xls')), dataParams, 'Sheet1', 'A1');

%Edited by Damayanthi - As the metadata is being written seperately, and
%the steps are executed seperately, the input params used in PTSD would
%only be considered at PTSD step, and metadata related to write output is
%written to a seperate csv.


%Write meta data

meta_data(1,:) = {'Threshold Level',threshold};
meta_data(2,:) = {'Sampling Rate',sampleRate};
meta_data(3,:)= {'Burst Detection File String', burstDetectionStr};
meta_data(4,:)= {'Sampling Frequency',frequency};
meta_data(5,:)= {'To or not to plot raster)',plot_raster};
meta_data(6,:)= {'Raster Plot Start',raster_start};
meta_data(7,:)= {'Raster Plot End',raster_end};
meta_data(8,:)={'NB Detection String',nbDetectionStr};
meta_data_table = cell2table(meta_data);
writetable(meta_data_table,'write_output_metadata.csv','WriteVariableNames',false);
    
end

%% Raster Plot Generation (If applicable)
function GenerateRasterPlot(raster_root_folder, burstDetectionStr, nbDetectionStr, fs,...
    wellType, startTime, endTime, screen_size, saveFolder, lowerRootFolder)

cd(raster_root_folder);
disp(raster_root_folder);
raster_root_path = pwd;

disp('Analysing spike files');
list = dir('*PeakDetectionMAT*');
cd(list(1).name);
list = dir('*ptrain*');
try
    cd(list(1).name);
end
list = dir('*ptrain*');

spikes = [];
recordingTime = 0;

for i=1:length(list)
    load(list(i).name);
    recordingTime = length(peak_train)/fs; %in seconds

    timestamps = find(peak_train);
    [~,fileName,~] = fileparts(list(i).name);
    inds = strfind(fileName,'_');
    elNum = fileName(inds(end)+1:end);
    electrodes = getAllChannels(pwd);
    elNum = find(electrodes == elNum);

%                 elNum = find(all_channels==elNum);
    if startTime>0
        timestamps = timestamps(timestamps>startTime*fs);
    end
    if endTime<recordingTime
        timestamps = timestamps(timestamps<endTime*fs);
    end
    if ~isempty(timestamps)
        try
            spikes = [spikes;[elNum.*ones(length(timestamps),1),timestamps]];
        catch
            disp('');
        end
    end
end


%%Draw the spikes
if wellType ==1
    f = figure('Position',[1+10 screen_size(1)+100 screen_size(3)-150 screen_size(4)-200]);
else
    f = figure('Position',[1+10 screen_size(1)+100 screen_size(3)-150 screen_size(4)/3]);
end


hold on
for i=1:size(spikes,1)
    line([spikes(i,2),spikes(i,2)]./fs,[spikes(i,1),spikes(i,1)+0.4],'color','black');
end
%         scatter(burstCores(:,1)/fs,zeros(length(burstCores(:,1)),1),'markerfacecolor','red');

cd(raster_root_path);

disp('Analysing burst detection files');
list = dir(burstDetectionStr);
cd(list(1).name);

list = dir('*BurstDetectionFiles*');
cd(list(1).name);
list = dir('*burst_detection*');
load(list(1).name);

for i=1:length(burst_detection_cell)
    if ~isempty(burst_detection_cell(i))
        bursts = burst_detection_cell{i};

        channel = i;%x;%find(all_channels==i);
        if startTime>0 && ~isempty(bursts)
            bursts = bursts(bursts(:,1)>startTime*fs,:);
        end
        if endTime<recordingTime && ~isempty(bursts)
            bursts = bursts(bursts(:,2)<endTime*fs,:);
        end
        for a=1:size(bursts,1)
            line([bursts(a,1),bursts(a,2)]./fs,[channel+0.5,channel+0.5]);
        end
    end
end

cd ..

 disp('Analysing NB files');
list = dir(nbDetectionStr);
cd(list(1).name);
list = dir('*NetworkBurstDetection*.mat');
for i=1:length(list)
    if isempty(strfind(list(i).name,'parameters'))
        fileName = list(i).name;
        break;
    end
end

load(fullfile(pwd,fileName));

nbMarkerHeight = 0.4;

if ~isempty(netBursts)
if startTime>0
    netBursts = netBursts(netBursts(:,1)>startTime*fs,:);
end
if endTime<recordingTime
    netBursts = netBursts(netBursts(:,2)<endTime*fs,:);
end

for i=1:size(netBursts,1)
    percentileX = [netBursts(i,1), netBursts(i,2)]/fs;
    threshPercY = [nbMarkerHeight nbMarkerHeight];
    line(percentileX,threshPercY,'Color','red','lineWidth',2);
    line([netBursts(i,1) netBursts(i,1)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
    line([netBursts(i,2) netBursts(i,2)]/fs,[0 nbMarkerHeight],'Color','red','lineWidth',3);
end
end


ylim([0 length(electrodes)]);
xlim([startTime,endTime]);


title(strcat(lowerRootFolder, ' - Raster Plot - ',raster_root_folder),'Interpreter', 'none');

cd(saveFolder);
mkdir(lowerRootFolder);
cd(lowerRootFolder);

drug_code =  strcat(lowerRootFolder, '_', raster_root_folder);
fileName = fullfile(saveFolder, strcat(drug_code,'.png'));

% if wellType ==1
% 	%saveas(f,strcat(rootFolder,'.jpg'));
% 	saveas(f, fileName, 'png')
% else
% 	saveas(f, fileName, 'png')
% end
saveas(f, fileName, 'png');

%saveas(f,strcat(rootFolder,'.jpg'));
close(f);


end

%% Parameter Saving Steps
function [dataSet] = SaveParameters(rootFolderPath, well_name, lengthWellRecord, ...
    burstDetectionStr, nbDetectionStr, fs, threshold, sampleRate, ...
    lowerRootFolder)

% initialize final output parameters in excel report as
% Not-a-Number values
meanSCBDuration = NaN;
stdSCBDuration = NaN;
cvSCBDuration = NaN;
rangeSCBDuration = NaN;
meanSCBSize = NaN;
stdSCBSize = NaN;
cvSCBSize = NaN;
rangeSCBSize = NaN;
avgChansInNB = NaN;
meanDuration = NaN;
stdDuration = NaN;
cvDuration = NaN;
rangeDuration = NaN;
meanInbis = NaN;
stdInbis = NaN;
cvInbis = NaN;
rangeInbis = NaN;
meanJitter = NaN;
stdJitter = NaN;
cvJitter = NaN;
rangeJitter = NaN;
NBRate = NaN;
totNoOfSpikes = NaN;
totNetBurstAmp = NaN;
avgNetBurstPeakAmp = NaN;
avgNetBurstTimeAmp = NaN;
mfrAll = NaN;
mfrIn = NaN;
mfrOut = NaN;
mfrRatio = NaN;
spikesInBursts = NaN;
noOfSpikingChans = NaN;
percOfChansInNBs = NaN;
nbSpikesAvg = NaN;
avgAmp = NaN;
spikesInBursts =NaN;
meanNBStartInts = NaN;
stdNBStartInts = NaN;
cvNBStartInts = NaN;
rangeNBStartInts = NaN;

cd(rootFolderPath);
cd(well_name);
disp(well_name);
wellPath = pwd;
% Get length of recording time
% list = dir('*Mat_files*');
% cd(list(1).name);
% list = dir('*.mat');
% load(list(1).name);
recordingTime = lengthWellRecord/fs; %in seconds
%    cd ..

list = dir('*PeakDetectionMAT*');
cd(list(1).name);
peakFolder = pwd;
cd ..

% Get data from burst detection files
disp('Analysing burst detection files');
list = dir(burstDetectionStr);
burstFolderName = fullfile(pwd,list(1).name);
cd(burstFolderName);

%try

list = dir('*BurstDetectionFiles*');
folderName = list(1).name;

cd(folderName);
list = dir('*burst_detection*.mat');
%This line loads the burst_detection_cell matfile. This initates
%the variable of the same name.
load(list(1).name);

%Find burst parameters
burstMat = [];
burstChannels = 0;
ibi = [];
isbi = [];

%Edited to use only the channels with a given threshold applied -DH.
%channels = getMultiwell12Channels();
channels = getfilteredChannels(peakFolder,wellPath,well_name,threshold,sampleRate);
all_channels = getAllChannels(peakFolder);
% The below block identifies how many channels have bursts  
for i=1:length(burst_detection_cell)
%            
    if ~isempty(burst_detection_cell{i}) %&& act_channel
        bursts = burst_detection_cell{i};
        scb = bursts(1:end-1,1:4);
        ibi = [ibi;scb(2:end,1)-scb(1:end-1,2)];
        isbi = [isbi;diff(scb(:,1))];
        burstMat = [burstMat;bursts(1:end-1,1:4)];
        burstChannels = burstChannels+1;
    end
end

% Single-channel parameter calculation block
if burstChannels > 1
    %sort the burst Matrix rows
    burstMat = sortrows(burstMat,1);
    %calculate the mean, standard deviation 
    meanSCBSize = mean(burstMat(:,3));
    stdSCBSize =  std(burstMat(:,3));
    cvSCBSize = stdSCBSize/meanSCBSize;
    %calculate the range of the burst
    rangeSCBSize = max(burstMat(:,3))-min(burstMat(:,3));

    %calculate parameters for time 
    burstMat(:,4) = 1000*burstMat(:,4);% in milliseconds
    meanSCBDuration = mean(burstMat(:,4));
    stdSCBDuration = std(burstMat(:,4));
    cvSCBDuration = stdSCBDuration/meanSCBDuration;
    rangeSCBDuration = max(burstMat(:,4))-min(burstMat(:,4)) ;
end

%end

cd(burstFolderName);  

%Get network burst metrics
disp('Analysing network burst detection files');

cd(burstFolderName);

% try
list = dir(nbDetectionStr);
folderName = list(1).name;
cd(folderName);
list = dir('*NetworkBurstDetection*.mat');
for i=1:length(list)
    x = strfind(list(i).name,'parameters');
    if isempty(x)
        fileName = list(i).name;
        break;
    end
end

path = pwd;

% Load the 'netBursts' and 'netBurstPatterns' matrices from file. 
load(fullfile(path,fileName));

if ~isempty(netBursts)

    if size(netBursts,1)>2
        % calculate the network burst parameters for output report
        netBursts(:,4) = 1000*netBursts(:,4)./fs;
        avgChansInNB = mean(netBursts(:,5));
        meanDuration = mean(netBursts(:,4));
        stdDuration = std(netBursts(:,4));
        cvDuration = stdDuration/meanDuration;
        rangeDuration = max(netBursts(:,4))-min(netBursts(:,4));

        NBRate = size(netBursts,1)/recordingTime;
        totNoOfSpikes = mean(netBursts(:,9));
        totNetBurstAmp = mean(netBursts(:,6));
        avgNetBurstPeakAmp = mean(netBursts(:,7));
        avgNetBurstTimeAmp = mean(netBursts(:,8)); %which unit is time in? - Dulini


        inbis = netBursts(2:end,1)-netBursts(1:end-1,2);
        inbis = inbis./fs;
        meanInbis = mean(inbis);
        stdInbis = std(inbis);
        cvInbis = stdInbis/meanInbis;
        rangeInbis  = max(inbis)-min(inbis);

        nbStartInts = diff(netBursts(:,1));
        nbStartInts = nbStartInts./fs;
        meanNBStartInts = mean(nbStartInts);
        stdNBStartInts = std(nbStartInts);
        cvNBStartInts = std(nbStartInts)/mean(nbStartInts);
        rangeNBStartInts = range(nbStartInts);


        jitter = zeros(size(netBursts,1),1);

        for i=1:size(netBurstsPattern,1)
            pattern = netBurstsPattern{i};
            [~,inds,~]= unique(pattern(:,1),'stable');
            jitter(i) = max(pattern(inds,2))-min(pattern(inds,2));
        end

        jitter = 1000*jitter./fs; %ms
        meanJitter = mean(jitter);
        stdJitter = std(jitter);
        cvJitter = stdJitter/meanJitter;
        rangeJitter = max(jitter)-min(jitter);

        %[mfrAll,mfrIn,mfrOut,mfrRatio,noOfSpikingChans,noOfChansInNBs,chanMat,nbSpikesAvg,avgAmp,spikesInBursts] = findNonNBMFR(path,fileName,getMultiwell12Channels());

        [mfrAll,mfrIn,mfrOut,mfrRatio,noOfSpikingChans,noOfChansInNBs,chanMat,nbSpikesAvg,avgAmp,spikesInBursts] = findNonNBMFR(path,fileName,channels);
        percOfChansInNBs = 100*noOfChansInNBs/noOfSpikingChans;
    else
        currentPath = pwd;
        %[mfrAll,noOfSpikingChans,avgAmp] = simpleSpikeParams(wellPath,getMultiwell12Channels());
        [mfrAll,noOfSpikingChans,avgAmp] = simpleSpikeParams(wellPath,channels);

        cd(currentPath);
    end
else
    currentPath = pwd;
    [mfrAll,noOfSpikingChans,avgAmp] = simpleSpikeParams(wellPath,channels);
    cd(currentPath);
end
%  end

mfrAll = mfrAll*fs;
mfrIn = mfrIn*fs;
mfrOut = mfrOut*fs;

% end
kappa = calcKappa(peakFolder,fs,10, channels);


%prepare output for writing out
dataSetTemp = [meanSCBDuration,stdSCBDuration,cvSCBDuration,rangeSCBDuration,meanSCBSize,stdSCBSize,cvSCBSize,rangeSCBSize,...
    avgChansInNB,meanDuration,stdDuration,cvDuration,rangeDuration,meanInbis,stdInbis,cvInbis,rangeInbis,meanJitter,stdJitter,cvJitter,rangeJitter,...
    NBRate,totNoOfSpikes,totNetBurstAmp,avgNetBurstPeakAmp,avgNetBurstTimeAmp,...
    mfrAll,mfrIn,mfrOut,mfrRatio,noOfSpikingChans,percOfChansInNBs,nbSpikesAvg,avgAmp,spikesInBursts,meanNBStartInts,stdNBStartInts,cvNBStartInts,rangeNBStartInts,kappa...
    ];
% replace NaN values with 0 for output.
% These lines build up the data-set as the script progresses. once
% all the iterations are finished, the dataset can be written out
dataSetTemp(isnan(dataSetTemp)) = 0;
% well_code = strsplit(well_name, '_');
% well_name = well_code(2);
% well_code = well_code(2);
% well_col = well_code{1};
% well_col = well_col(1);

[~, name, ~] = fileparts(lowerRootFolder);
% date = strsplit(name, '_');
% date = date(end);

% dataSet = horzcat(num2cell(dataSetTemp),{name, well_name{1}});
dataSet = horzcat(num2cell(dataSetTemp),{name, well_name});

cd ..

end