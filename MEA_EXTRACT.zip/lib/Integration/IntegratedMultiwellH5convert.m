%% IntegratedMultiwellH5convert
% The function multiwellH5convert extracts data from all files in the form
% of .h5 in a given rootFolder read from the GUI.
% Parameters for a desired filter are also read from the user via GUI.
% For each _mwd.h5 file, it extracts the each of the channel data in each well, applies the selected filter,
% converts the output into uV and writes the converted data in to .mat files, 
% following the naming convention,
% ExperimentIdentifier/WellID/Mat_files/shortenedExperimentIdentifier_wellIndex_channelLabel.
%%


function IntegratedMultiwellH5convert(rootFolder, answer)

%Read the parameters of the desired filter from the user.
% answer = inputdlg({'filter Type (None-0, Low-1, High-2)','Cut off freqeuncy (Hz)','Sampling frequency (Hz)'},'Filter Parameters',1,{'2','300','20000'});
filterType = str2double(answer{1});
cutoffFrequency = str2double(answer{2});
sf = str2double(answer{3});
%Read the folder containing the h5 files as user input
% rootFolder = uigetdir(pwd,'Select root folder');

cd(rootFolder);

%Read the files with mwd.h5 extension.
list = dir('*mwd.h5'); %only have mwd files

tic;
% For each _mwd.h5 file, a folder is created with the filename 
% considering it as an identifier for the experiment(excluding _mwd)


for i=1:length(list)
    cd(rootFolder);
    
    [~,h5FileName,ext] = fileparts(list(i).name);
    inds = strfind(h5FileName,'_mwd');
    fileName = h5FileName(1:inds-1);
    inds = strfind(fileName,'_');
    if ~isempty(inds);
        shortName = fileName(1:inds(1)-1);
    else
        shortName = fileName;
    end
    
    mkdir(fileName);
    cd(fileName);
    saveFolder = pwd;
    
    cd(rootFolder);
    
    h5Data = McsHDF5.McsData(list(i).name);
    % No of total channels (288 by default),
    % Channel labels (corresponding to positions of the channels in a well ),
    % and the well numbers are extracted fromt the data.
    % Well numbers are indexed from zero in the input).

    noOfChans=length(h5Data.Recording{1}.AnalogStream{1}.Info.ChannelID);
    chanLabels = h5Data.Recording{1}.AnalogStream{1}.Info.Label; %position of the channels in a well
    chanWells = h5Data.Recording{1}.AnalogStream{1}.Info.GroupID; %well number
    
    blockSize = 48;
    num=1;
    blockStarts = [];
    
    while num<=288
        blockStarts = [blockStarts,num];
        num = num+blockSize;
    end
    
    %The channel data is read in blocks of 48. The voltage values corresponding
    %to each channel in each well is extracted from these data in blocks of 48
    
    %For voltages extracted from each channel, the selected (from the GUI) filter is applied
    %and converted to uV.
    
    %Next, a folder is created corresponding to each well and converted data is
    %saved in a matfile the form 'shortName_WellID_channelLabel.mat'
    for j=1:noOfChans
        %Prompt a progress bar till the end of conversion.
        if j==1
            % bar indicating proceeding conversion
            wb = waitbar(j/noOfChans, ['converting stream ' num2str(j) ' of '   num2str(noOfChans)]);
        else
            waitbar(j/noOfChans, wb, ['converting stream ' num2str(j) ' of '   num2str(noOfChans)]);
        end
        
        cd(rootFolder);
        if ismember(j,blockStarts)
            cfg.channel = [j j+blockSize-1];
            channel = h5Data.Recording{1}.AnalogStream{1}.readPartialChannelData(cfg);
            blockData = channel.ChannelData;
        end
        
        blockIndex = mod(j,blockSize);
        if blockIndex ==0
            blockIndex = blockSize;
        end
        
        %Apply the desired filter.
        filtData = filtDataUser(blockData(blockIndex,:), filterType, cutoffFrequency, sf);
        
        exponent = channel.Info.Exponent(blockIndex);
        data = filtData.*(10^double(exponent)/(10^(-6))); %convert to uV because single well code is for uV
        
        cd(saveFolder);
        
        warning off MATLAB:MKDIR:DirectoryExists
        mkdir(strcat('Well_',getWellLabel(chanWells(j)+1)));
        cd(strcat('Well_',getWellLabel(chanWells(j)+1)));
        
        mkdir('Mat_files');
        cd('Mat_files');
        warning on MATLAB:MKDIR:DirectoryExists
        
        %Format the output file name
        filename_mat = fullfile(pwd,  strcat(shortName,'_',num2str(chanWells(j)+1),'_',chanLabels(j),'.mat'));
        save(filename_mat{1},'data');
        
    end
    %Close the progress bar UI
    try
        close(wb);
    end
end
%Display the time elapsed.
disp(['Time elapsed: ' toc]);
end

%Filter function filtDataUser is called by the function,
%multiwellH5convert(). This function applies the selected filterType
%(None-0, Low-1, High-2) with the given cutoffFrequency and samplingFrequency
%on data2Filter.

function filteredData = filtDataUser(data2Filter, filterType, cutoffFrequency,samplingFrequency)

% initialise variable
filteredData = data2Filter;

% filter band type and filter flag
filterBandType = {'no_filter'; 'high'; 'low'};

% in case filtering must be applied, apply butterworth filter
if (filterType > 1)
    Wn_norm = cutoffFrequency/(0.5*samplingFrequency);
    
    % design transfer function
    [b, a] = butter(2, Wn_norm, strtrim(filterBandType{filterType}));
    
    % apply filter
    filteredData = (filter(b, a, data2Filter));
    
    % clear variables
    clear b a WN_norm;
end
end