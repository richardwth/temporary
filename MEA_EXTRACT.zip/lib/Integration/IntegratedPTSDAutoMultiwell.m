function IntegratedPTSDAutoMultiwell(upperRootFolder, plp, rp, ...
    nstd, fs, PTSDCancelFlag, recordingTime, nspikes,...
    nb_th, nb_fs, nb_split, threshold, sampleRate, use_parallel)
%IntegratedPTSDAutoMultiwell perform Precision Timing Spike Detection
%algorithm(PTSD)on Multiple Experiments, each having multiple wells
%   PTSDAutoMultiwell prompts you to select the folder where multiple
%   experiments are stored. At the first prompt, select the parent folder
%   where all experiment outputs are stored
%   
%   authored by Dulini Mendis - Annotated by Damith Senanayake 
%
%   Note : IntegratedMultiwellH5convert must be run on the data prior to running this

errors = [];
errorFolder = [];

% The upperRootFolder should be set to the Folder that contains multiple
% experiments. If there is only one experiment, then the parent folder
% where the experiment data is stored must be selected.

cd(upperRootFolder);

folderList = dir('*');

if PTSDCancelFlag==1
    return
end

rootPath = pwd;

%This loop iterates through the output folders in the upper root folder. To
%avoid run time errors and failures, ensure that there are no 'files' other
%than 'folders' in the uper-root folder. 

 %Edited by Damayanthi : Look only for folders within the root folder.
 isDir = [folderList(:).isdir];
 
 folderList= {folderList(isDir).name}';
 
for samplex = 3:length(folderList)
    %try
    cd(rootPath);
    %rootFolder = folderList(samplex).name;
    rootFolder = folderList{samplex};
    
    %if ~isempty(strfind(rootFolder,'1_1_'))
   
    cd(rootFolder);
    rootFolder = pwd;
    
    fprintf('Processing folder %s\n',pwd);
    
    
    wellList = dir('*Well*');
    
    % for each of the 'Well' folders, this loop parallelly iterates through
    % the files.
    % whether remove Mat file; perhaps set this to false when debugging.
    removeMatFile = true;  
    if use_parallel
        parfor sy=1:length(wellList)
            %start parallel loop
            cd(rootFolder);
            wellName = wellList(sy).name;
            cd(wellName); 
            handleOneWell(wellName, plp, rp, fs,...
                nstd, recordingTime, nspikes, nb_th, nb_fs, nb_split, ...
                threshold, sampleRate, removeMatFile)
        end
    else
        for sy=1:length(wellList)
            %start parallel loop
            cd(rootFolder);
            wellName = wellList(sy).name;
            cd(wellName); 
            handleOneWell(wellName, plp, rp, fs,...
                 nstd, recordingTime, nspikes, nb_th, nb_fs, nb_split,...
                threshold, sampleRate, removeMatFile)
        end
    end
    %write metadata into a csv
    
    cd(rootFolder);
    meta_data(1,:) = {'NBParameters_Threshold Level',nb_th};
    meta_data(2,:) = {'NBParameters_Sampling Frequency',nb_fs};
    meta_data(3,:)={'NBParameters_Split', nb_split};
    meta_data(4,:)= {'Minimum Number of Intra-burst Spikes',nspikes};
    meta_data(5,:)={'Coefficient for defining the PD threshold',nstd};
    meta_data(6,:)={'Peak Lifetime Period in number of samples',plp};
    meta_data(7,:)={'Refractory Period in number of samples',rp};
    meta_data(8,:)={'Recording Time',recordingTime};
%     meta_data(12,:)={'Sampling Rate',sampleRate};
    meta_data(9,:)={'Threshold Level',threshold};
    
    
    meta_data_table = cell2table(meta_data);
    writetable(meta_data_table,'PTSD_metadata.csv','WriteVariableNames',false);
    
    
    
    
end

%obsolete error handling loop. 
for i=1:length(errors)
    fprintf('Error while processing %s\n',errorFolder(i));
    disp(errors(i));
end

end

% --------------------------------------------------------------------- %
function handleOneWell(wellName, plp, rp, fs,...
    nstd, recordingTime, nspikes, nb_th, nb_fs, nb_split, threshold, sampleRate, ...
        removeMatFile)
%HANDLEONEWELL This function performs Precision Timing Spike Detection on 
%a single well.

wellPath = pwd;
fprintf('Processing %s\n',wellName);

%-----------------GET SPIKES PTSD
list = dir('*Mat_files*');
mat_folder = fullfile(pwd,list(1).name);

cd (mat_folder);
cd ..
exp_folder=pwd;   % Folder of the well
pkd_folder = strcat('PeakDetectionMAT_PLP', num2str(plp*1000/fs),'ms_RP', num2str(rp*1000/fs),'ms');
warning off MATLAB:MKDIR:DirectoryExists
mkdir (pkd_folder) % Directory for peak detection MAT files is created
cd (pkd_folder)
pkd_folder= pwd;   % Save the absolute path for subfoldername2
cd(exp_folder);

thresh_vector = [];

% call multiwellPTSDMexAutoThVec using the parameters and the
% peak detection foder  along with the mat folder. This calculates
% the Peak and Burst detection outputs
disp("Executing peak detection script");
multiwellPTSDMexAutoThVec(plp, rp, fs, ...
    thresh_vector, nstd, mat_folder, pkd_folder, recordingTime);
disp("End Executing peak detection script")
cd ..


%-----------------------GET BURSTS

list = dir('*PeakDetectionMAT*');
start_folder = fullfile(pwd,list(1).name);


%Folder creation to store the output
burstfoldername = strcat ('BurstDetectionMAT_', num2str(nspikes), '-BAFR'); % Burst files here
mkdir(burstfoldername);
cd(burstfoldername);
burstFolder = pwd;

cd(burstFolder);

mkdir('BurstDetectionFiles');
cd('BurstDetectionFiles');
end_folder1=pwd;
cd ..
mkdir('BurstEventFiles');
cd('BurstEventFiles');
end_folder2=pwd;
cd ..
mkdir('OutBSpikesFiles');
cd('OutBSpikesFiles');
end_folder3=pwd;
cd ..



cd (start_folder);

% Computation done at the Well* folder 

channels = getfilteredChannels(pkd_folder,wellPath,wellName,threshold, sampleRate);
%call burstDetectionBAFRMultiwell for the well folder (pwd), folder with burst detection files (end_folder1), 
%folder with burst event files (end_folder2), folder with output burst and spike files (end_folder3) 
burstDetectionBAFRMultiwell(pwd, end_folder1, end_folder2, end_folder3, nspikes, fs,channels);

cd(burstFolder);


%----------------GET NET BURSTS
list = dir('*BurstDetectionFiles*');
BDResFolder = fullfile(pwd,list(1).name);

NBFolderPath = pwd;

%creating folders
folderName = strcat('NetworkBurstDetectionFilesBO');
[success,message] = mkdir(NBFolderPath,folderName);
NBDResFolder = [NBFolderPath,filesep,folderName];

% Conduct Network Burst Detction using the detected bursts in the previous script execution 
[netBursts, netBurstsPattern] = nbDetectBOMultiwell(NBDResFolder,BDResFolder,...
    nb_fs, nb_th, nb_split, channels, pkd_folder);
%end parallel loop

%remove intermediate mat files including subfiles
cd ..

cd ..
if removeMatFile
    rmdir Mat_files s
end

end