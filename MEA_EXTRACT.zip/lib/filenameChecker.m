%author : Ashwin de Silva
%File Name Checker Module
%Read the file names in the directory

function tf = filenameChecker(directory)
    %% Read the file names in the directory
    folderContent = dir(directory); 
    filenames = {};
    for i = 3:numel(folderContent)
        filenames{i} = folderContent(i).name;
    end
    filenames = filenames(3:end);
    %% Check the viability of each filename
    invalid_filenames = {};
    id = {};id_error = 0;
    G1_errors = {};
    date_errors = {};
    for i = 1:numel(filenames)
        filename = filenames{i};
        filename = filename(1:end-7);%take out the '_mwd.h5' part
        %check for the invalid characters
        %disp(filename);
        if (~isvarname(filename))
            invalid_filenames{end+1} = filename; 
        end
        blocks = split(filename,'_');
        id{end+1} = blocks{3};
        %check for the G1
        if (~strcmp(blocks{4},'G1'))
            G1_errors{end+1} = filename;
        end
        %check for the date
        date = blocks{end};
        dd = str2num(date(1:2));
        mm = str2num(date(3:4));
        yy = str2num(date(5:6));
        if ~(((1 <= dd)&&(dd <= 31))&&((1 <= mm)&&(mm <= 12))&&((0 <= yy)&&(yy <= 99)))
            date_errors{end+1} = filename;
        end
    end
    %% Display errors if there are any
    %check for the id repitions
    if (numel(id) ~= numel(unique(id)))
        id_error = 1;
    end
    if ~(numel(invalid_filenames) == 0 && numel(G1_errors) == 0 && numel(date_errors) == 0 && id_error == 0)
        tf = 1;
        msg = {'The following filename error(s) have been detected.',' '};
        if numel(invalid_filenames) ~= 0
            msg{end+1} = 'The following files contain invalid file names : ';
            for i = 1 : numel(invalid_filenames)
                msg{end+1} = char(invalid_filenames(i));
            end    
        end
        msg{end+1} = ' ';
        
        if numel(G1_errors) ~= 0
            msg{end+1} = 'The following files contain G1 errors : ';
            for i = 1 : numel(G1_errors)
                msg{end+1} = char(G1_errors(i));
            end
        end
        msg{end+1} = ' ';
        if numel(date_errors) ~= 0
            msg{end+1} = 'The following files contain date errors : ';
            for i = 1 : numel(date_errors)
                msg{end+1} = char(date_errors(i));
            end
        end
        msg{end+1} = ' ';
         if id_error == 1
             msg{end+1} = 'There can be two or more files with the same block 3 ID.';
         end
        msg{end+1} = ' ';
        msg{end+1} = 'Please rectify the errors and press Enter';
        h = msgbox(msg, 'Error','error');
    else
        tf = 0;
        
    end
    
end

        