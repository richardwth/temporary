%Function getfilteredChannels() is written to retrieve the filtered
%channels
function channels = getfilteredChannels(peakDataDirectory,fpath,wellName,threshold,defaulsampleRate)


%Draw the Rasterplot for all the channels
channels =drawAltRasterPlot(peakDataDirectory,fpath,wellName,threshold,defaulsampleRate);


end