%adding comment
function avgKappa = calcKappa(path,fs,binWidth, channels)
%Finds the Kappa values between channel pairs
%OUTPUTS:
%average kappa value

%% Go into the spike detection folder
cd(path);
all_channels = getAllChannels(path);
list = dir('*ptrain*.mat');
noOfChannels = length(channels);

fileName = list(1).name;
load(fileName);


%% Get the time binning parameters
binWidth = binWidth*fs/1000;
samples = length(peak_train);
noOfBins = floor(samples/binWidth);

%% Make a matrix where the rows are time bins and columns are channels. If a channel is spiking in a time bin, it's marked as 1
spikeMatrix = zeros(noOfBins,noOfChannels);
removeInds = [];

%% Do for each peak train file
for i=1:noOfChannels
    fileName = list(i).name;
    load(fileName);    
    nameParts = strsplit(fileName, '_');
    extparts = strsplit(char(nameParts(end)), '.');
    chanNum = extparts{1};
    ix = -1;
    for k = 1:length(channels);
        if strcmp(chanNum, channels{k});
            ix = k;
        end
    end
    if ~(ix > -1)%ismember(chanNum, channels)
        continue;
    end
    %% Find the bins where spikes occur and mark them as 1 for that channel
    startTimes = find(peak_train);
    if length(startTimes)/(length(peak_train)/(fs*60)) < 50
        removeInds = [removeInds;i];
    end
    startTimeBins = unique(floor((startTimes./binWidth)+1));
    spikeMatrix(startTimeBins,i) = 1; %if the same channel fires multiple times within the same bin it is still counted as one    
end

spikeMatrix(:,removeInds) = [];

noOfChannels = size(spikeMatrix,2);

h = waitbar(0,'Please wait while the calculation completes...');

allCPMat = zeros(noOfChannels,noOfChannels);

for i=1:noOfChannels
    for j=i+1:noOfChannels
        if i~=j
            Pexp = ((noOfBins-nnz(spikeMatrix(:,i)))*(noOfBins-nnz(spikeMatrix(:,j)))+nnz(spikeMatrix(:,i))*nnz(spikeMatrix(:,j)))/(noOfBins^2);
            Pobs = nnz(spikeMatrix(:,i)== spikeMatrix(:,j))/noOfBins;
            if Pexp < 1
                kappa = (Pobs - Pexp)/(1-Pexp);
            else
                kappa = 1;
            end
            allCPMat(i,j)= kappa;   
            allCPMat(j,i)= kappa;  
        end
    end
end    

close(h);




%% Get the average as the sum of the upper triangle of the matrix divided by the number of elements in the upper triangle
avgKappa = sum(sum(triu(allCPMat)))/(noOfChannels*(noOfChannels+1)/2);

cd ..
