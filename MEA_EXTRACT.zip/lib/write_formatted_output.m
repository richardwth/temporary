%The script output-formatter contains the functions related to formatting
%the output such that it is convenient to plot the parameters in graphpad.
%.mat to be appended to file name

%dataParams is a mat (x X 42 cell matrix) holding the calculated parameters values  (42)
function y = write_formatted_output(dataParams,output_file_all,grouped_per_plate_file_name,pheno_type_based_op_filename,drug_based_op_filename)

%Extract the sample names
var_names = dataParams(1,:);

%retrive the indices of names in the cell array
ind = find(ismember(var_names,'name'));
data = dataParams(2:end,:);
data_to_write= {'meanSCBDuration(ms)','stdSCBDuration(ms)','cvSCBDuration','rangeSCBDuration(ms)','meanSCBSize','stdSCBSize','cvSCBSize','rangeSCBSize'...
    ,'avgChansInNB','meanDuration(ms)','stdDuration(ms)','cvDuration','rangeDuration(ms)',...
    'meanInbis(s)','stdInbis(s)','cvInbis','rangeInbis(s)','meanJitter(ms)','stdJitter(ms)','cvJitter','rangeJitter(ms)',...
    'NBRate','totNoOfSpikes','totNBAmp(uV)','avgNBPeakAmp(uV)','avgNBTimeAmp(uVperS)','mfrAll','mfrIn','mfrOut','mfrRatio','noOfSpikingChans','%chansInNBs','avgSpikesInNB','avgAmp(uV)','%spikesInNBs','meanNBSI(s)','stdNBSI(s)','cvNBSI','rangeNBSI(s)','Kappa'};

tab= cell2table(data);
sample_names = unique(tab{:,41});
data_to_write_map = containers.Map;
%populate the data_to_write_map map. The map is in the form of
%parameter_name : values corresponding to each sample as a table.
for iter = 1:(ind-1)
    
    temp_indices = find(ismember(tab{:,41}, sample_names{1}));
    temp= table(tab{temp_indices,ind+1},tab{temp_indices,iter});
    sample_name = sample_names{1};
    sample_name = replace(sample_name, '-', '_');
    temp.Properties.VariableNames = {'Well_ID',sample_name};
    
    for tab_iter = 2: length(sample_names)
        temp_indices = find(ismember(tab{:,41}, sample_names{tab_iter}));
        temp_table =  table(tab{temp_indices,iter});
        temp_table.Properties.VariableNames = {sample_names{tab_iter}};
        temp = [temp temp_table];
    end
    data_to_write_map(var_names{iter})=  temp;
end

keys = data_to_write_map.keys;
%Convert the data in table to cellarray and write to excel (one parameter per sheet)

for iter = 1: length(keys)
    key = keys{iter};
    temp_sheet=[data_to_write_map(key).Properties.VariableNames;table2cell(data_to_write_map(key))];
    xlswrite(output_file_all,temp_sheet,key);
end

%Write output as grouped data

grouped_per_plate_data= containers.Map;
plate_ids= cell(length(sample_names),1);
%Retrieve plate ids

for iter= 1: size(sample_names)
    
    str_t = strsplit(sample_names{iter},'_');
    plate_ids{iter}= str_t{3};
    
end

%Group by and retrieve data based on plate ID

for i = 1: length(plate_ids)
    
    plate_data= containers.Map;
    sample_names_indices = find(~cellfun(@isempty,strfind(sample_names, plate_ids{i})));
    
    for iter = 1:(ind-1)
        
        temp_indices = find(ismember(tab{:,41}, sample_names{sample_names_indices(1)}));
        temp= table(tab{temp_indices,iter});
        temp.Properties.VariableNames = {sample_names{sample_names_indices(1)}};
        
        for tab_iter = 2: length(sample_names_indices)
            temp_indices = find(ismember(tab{:,41}, sample_names{sample_names_indices(tab_iter)}));
            temp_table =  table(tab{temp_indices,iter});
            temp_table.Properties.VariableNames = {sample_names{sample_names_indices(tab_iter)}};
            temp = [temp temp_table];
        end
        
        plate_data(var_names{iter})=  temp;
    end
    grouped_per_plate_data(plate_ids{i}) = plate_data;
    
end

%Write data grouped by plate IDs to Excel
keys = grouped_per_plate_data.keys;
%Convert the data in table to cellarray and write to excel (one parameter per sheet)



for iter = 1: length(keys)
    wr_ind=1;
    key = keys{iter};
    data=grouped_per_plate_data(key);
    
    % xlswrite takes time, so it's better to reduce the number of times it
    % is called.
    % Instead of 
%     for i = 1: ind-1
%         xlswrite(grouped_per_plate_file_name,cellstr(var_names{i}),key,strcat('A',num2str(wr_ind)))
%         
%         temp_data=[data(var_names{i}).Properties.VariableNames;table2cell(data(var_names{i}))];
%         
%         xlswrite(grouped_per_plate_file_name,temp_data,key,strcat('A',num2str(wr_ind+1)));
%         
%         wr_ind= wr_ind + length(temp_data) +1;
%     end
    % we could do
    var_length = length(table2cell(data(var_names{1}))) + 2;
    temp_data = cell(var_length * (ind-1), 1);
    for i = 1: ind-1
        temp_data(((i-1)*var_length+1):(i*var_length))=[cellstr(var_names{i}); ...
            data(var_names{i}).Properties.VariableNames; table2cell(data(var_names{i}))];
    end
    xlswrite(grouped_per_plate_file_name, temp_data, key, strcat('A',num2str(wr_ind)));
end

%Write the output formatted based on cell lines grouping: phenotype based
%and drug study based.

write_well_wise_formatted_output(dataParams,pheno_type_based_op_filename,drug_based_op_filename);




end