function channels = getAllChannels(peakFolder);

    matnames = dir(peakFolder);
    chanIDs = [];

    for ix = (3: length(matnames)); % read channel IDS from the file names after conversion
        [~,fname,~] = fileparts(matnames(ix).name);
        fparts = strsplit(fname, '_');
        chanIDs = [chanIDs, string(fparts(end))];
    end
    channels = chanIDs;
    
end