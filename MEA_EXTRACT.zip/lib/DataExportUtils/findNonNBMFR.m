function [mfrAll,mfrIn,mfrOut,mfrRatio,noOfSpikingChans,noOfChansInNBs,chanMat,nbSpikesAvg,avgAmp,spikesInBursts] = findNonNBMFR(path, fileName, channels)

%%load the netBUrsts file
cd(path);
load(fileName);



bursts = [];

for i=1:length(netBurstsPattern)
    pattern = netBurstsPattern{i};
    bursts = [bursts;pattern];
end

els = unique(bursts(:,1));
noOfChansInNBs = length(els);


cd ..
cd ..

list = dir('*PeakDetectionMAT*');
peakFolder = list(1).name;
electrodes = getAllChannels(peakFolder);
cd(peakFolder);
list = dir('*ptrain*');

chanCell = cell(length(channels),1);
for i=1:length(els)
%     elNum = find(channels==els(i));
    ix = -1;
    for k = 1:length(channels);
        if strcmp(electrodes(els(i)), channels{k});
            ix = k;
        end
    end
    if ~(ix == -1)%isempty(elNum) % ignore the detected bursts if they are below threshold
        elNum = ix;
        chanCell{elNum} = bursts(bursts(:,1)==els(i),2:3);
    end
end

try
cd(list(1).name);
end

list = dir('*ptrain*.mat');

chanMat = zeros(length(channels),6);
chanMat(:) = NaN;

noOfSpikingChans = 0;

nbSpikes = zeros(size(netBursts,1),1);
avgAmp = 0;

for i=1:length(list)
    
     
    load(list(i).name);
    
    nameParts = strsplit(list(i).name, '_');
    extparts = strsplit(char(nameParts(end)), '.');
    
    chanNum = str2num(char(extparts(1)));
    
    act_channel = 0;
    for k = 1:length(channels)
    act_channel = act_channel + strcmp(channels{k}, electrodes{i});
    end
    
    if ~act_channel%~ismember(chanNum, channels)
        continue;
    end
    
   [~,onlyName,~] = fileparts(list(i).name);
   split_parts = strsplit(onlyName, '_');
   el = split_parts(end);
%    el = str2double(onlyName(end-1:end));
   
   %%% Wrap with Function 
    ix = -1;
    for k = 1:length(channels);
        if strcmp(el, channels{k});
            ix = k;
        end
    end
    %%%%
   
   elNum = ix;%find(channels==el);
   if ~isempty(elNum)
      chanBursts = chanCell{elNum};
   end
   
   timestamps = find(peak_train);
   
   if length(timestamps)<10 %remove channels with very low firing rate
       timestamps = [];
       peak_train = [];
   end
   
   isis = diff(timestamps);
   avgAmpChan = nanmean(abs(peak_train(timestamps)));

   
   if ~isempty(timestamps) && nnz(timestamps)>10
       noOfSpikingChans = noOfSpikingChans+1;
       avgAmp = avgAmp+avgAmpChan;
   end
   
   allPeaks = length(timestamps);
   
    
    for j=1:size(netBursts,1)  
            netSpikes = find(timestamps>=netBursts(j,1) & timestamps<=netBursts(j,2));           
            nbSpikes(j) = nbSpikes(j)+length(netSpikes);
            timestamps(timestamps>=netBursts(j,1) & timestamps<=netBursts(j,2)) = [];          %remove the timestamps inside the bursts
    end
    

    
%      f = figure;
%      hold on
%      for k=1:size(timestamps,1)
%         line([timestamps(k),timestamps(k)]./20000,[1,1+0.4],'color','black');
%      end
%      for k=1:size(chanBursts,1)
%          line([chanBursts(k,1),chanBursts(k,2)]./20000,[1.5,1.5],'color','red','LineWidth',2);
%      end
%      ylim([-5,5]);
%      close(f);
     
    if ~isempty(netBursts) && ~isempty(timestamps)
        durs = netBursts(:,2)-netBursts(:,1); % in ms
    
        mfrOut = length(timestamps)/(length(peak_train)-sum(durs));
        mfrIn = (allPeaks-length(timestamps))/sum(durs);
        ratio = mfrIn/mfrOut;
        spikesInBursts = 100*(allPeaks-length(timestamps))/allPeaks;
    elseif ~isempty(timestamps)
        mfrOut = length(timestamps)/length(peak_train);
        mfrIn = 0;
        ratio = mfrIn/mfrOut;
        spikesInBursts = 0;
    else
         mfrIn=NaN;
         mfrOut=NaN;
         ratio = NaN;
         spikesInBursts = NaN;
    end
    
    mfrAll = allPeaks/length(peak_train);
%     if mfrAll < 0.01 %CHANGE THIS TO ADJUST THE ACTIVITY LEVEL
%         mfrAll = NaN;
%     end
    minISI = min(isis);
    if isempty(minISI)
        minISI=NaN;
    end
    if ~isempty(elNum)
        chanMat(elNum,:) = [mfrAll,mfrIn,mfrOut,ratio,minISI(1),spikesInBursts];
    end
end


chanMat(chanMat(:,1)>nanmedian(chanMat(:,1))*100,:) = NaN;
%nbSpikesTimeAvg = nanmean(nbSpikes./(chanBursts(j,2)-chanBursts(j,1))); %avg no of spikes per NB
nbSpikesAvg = nanmean(nbSpikes);
avgAmp = avgAmp/noOfSpikingChans;
chanMat(isinf(chanMat(:))) = NaN;
mfrAll = nanmean(chanMat(:,1));
mfrIn = nanmean(chanMat(:,2));
mfrOut = nanmean(chanMat(:,3));
mfrRatio = nanmean(chanMat(:,4));
spikesInBursts = nanmean(chanMat(:,6));
