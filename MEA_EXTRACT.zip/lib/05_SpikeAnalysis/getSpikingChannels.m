function spikingChans = getSpikingChannels(fs,peakFolder)
%peakFolder - full path of external peak folder. not ptrain folder
%OUT - gives a matrix having:
%col1 - active channel numbers
%col2 - mean firing rates


cd(peakFolder);

list=dir('*ptrain*');
cd(list(1).name);

list = dir('*ptrain*.mat');

spikingChans = [];

for i=1:length(list)
    load(list(i).name);
    chanNo = getChanNo(list(i).name);
    timestamps = find(peak_train);
    mfr = length(timestamps)/(length(peak_train)/fs);
    meanAmp = nanmean(full(peak_train(timestamps)));
    if mfr>0.01 && meanAmp>10 %mean amplitude > 10 mV - to remove internal grounding channel
        spikingChans = [spikingChans;[chanNo,mfr]];
    end 
    
end

