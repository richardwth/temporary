function [mfrAll,noOfSpikingChans,avgHeight] = simpleSpikeParams(path,channels)

%%load the netBUrsts file
cd(path);



list = dir('*PeakDetectionMAT*');
peakFolder = list(1).name;
cd(peakFolder);
list = dir('*ptrain*');

try
cd(list(1).name);
end

list = dir('*ptrain*.mat');

mfrs = zeros(length(channels),1);
mfrs(:) = NaN;

noOfSpikingChans = 0;

avgHeight = 0; % This was abgAmp before
avgAmp = 0;

for i=1:length(list)
    
    nameParts = strsplit(list(i).name, '_');
    extparts = strsplit(char(nameParts(end)), '.');
    chanNum = str2num(char(extparts(1)));

    if isempty(channels) || isempty(find([channels{:}] == num2str(chanNum)))
        continue;
    end
    
    load(list(i).name);
   [~,onlyName,~] = fileparts(list(i).name);
   
   el = str2double(onlyName(end-1:end));
   elNum = find([channels{:}]==num2str(el));
   
      
   timestamps = find(peak_train);
   isis = diff(timestamps);
   avgHeightChan = nanmean(abs(peak_train(timestamps)));
   %avgAmpChan = nanmean(abs(amp_train(timestamps)));
   
   if ~isempty(timestamps) 
       noOfSpikingChans = noOfSpikingChans+1;
       avgHeight = avgHeight+avgHeightChan;
       %avgAmp = avgAmp+avgAmpChan;
   end
    
   mfrs(elNum) = length(timestamps)/length(peak_train);
    
end

%nbSpikesTimeAvg = nanmean(nbSpikes./(chanBursts(j,2)-chanBursts(j,1))); %avg no of spikes per NB

avgHeight = avgHeight/noOfSpikingChans;
mfrs(isinf(mfrs(:))) = NaN;
mfrAll = nanmean(mfrs(:,1));

