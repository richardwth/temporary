function activityMapsSpikes_main

peakFolder = uigetdir(pwd,'Select the folder containing the Peak Detection files');
if(isempty(peakFolder))
    errordlg('Select a folder!','!!Error!!')
    return
end

pause(1);

%% Get the activity map parameters
%get params from user
PopupPrompt  = {'Sampling frequency','Number of divisions per map axis'};
PopupTitle   = 'Activity Maps';
PopupLines   = 1;
PopupDefault = {'10000','50'};
%----------------------------------- PARAMETER CONVERSION
answer = inputdlg(PopupPrompt,PopupTitle,PopupLines,PopupDefault,'on');

if isempty(answer) % halt condition
    return
else
    fs = str2double(answer{1});
noOfSections = str2double(answer{2});

end

[f,activityMap] = activityMapSpikes(peakFolder,fs,noOfSections);  


path = pwd;
string = 'ActivityMapSpikes';
[outputFolder, overwriteFlag] = createResultFolder(path, string);
if(isempty(outputFolder))
    errordlg('Error creating output folder!','!!Error!!')
    return
end

cd(outputFolder);
path = pwd;
numExp = find_expnum(peakFolder, '_PeakDetectionMAT');

%%save figure
title(strcat(numExp,' ActivityMapSpikes'));
saveas(f, fullfile(path,strcat(numExp,'_activityMapSpikes.jpg')));

%%save files
save(fullfile(path,strcat(numExp,'_poincareMapSpikes.mat')),'activityMap');
xlswrite(fullfile(path,strcat(numExp,'_poincareMapSpikes.xls')),activityMap, 'Sheet1', 'A1');


msgbox('Activity Map of spikes has been saved','End Of Session','warn');
cd ..
