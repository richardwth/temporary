function getActivityMaps

first = 1;

upperRootFolder = uigetdir(pwd,'Select the root folder');
cd(upperRootFolder);

pause(1);
saveFolder = uigetdir(pwd,'Select the folder to save the files in');

folderList = dir('*wag1_1_*');

%% Get the activity map parameters
%get params from user
PopupPrompt  = {'Sampling frequency','Number of divisions per map axis'};
PopupTitle   = 'Activity Maps';
PopupLines   = 1;
PopupDefault = {'10000','50'};
%----------------------------------- PARAMETER CONVERSION
answer = inputdlg(PopupPrompt,PopupTitle,PopupLines,PopupDefault,'on');

if isempty(answer) % halt condition
    return
else
    fs = str2double(answer{1});
noOfSections = str2double(answer{2});

end

for x = first:length(folderList)
    cd(upperRootFolder);
    
    rootFolder = folderList(x).name;
    cd(rootFolder);
    
    disp(sprintf('Processing folder %s',rootFolder));
    
    list = dir('*');
    folderName = list(3).name;
    cd(folderName);    
 
    list = dir('*PeakDetectionMAT*');
    peakFolder = fullfile(pwd,list(1).name);
    [f,activityMap] = activityMapSpikes(peakFolder,fs,noOfSections);  
   
    cd ..
    cd ..
    
    %save figure
    title(rootFolder);
    cd(saveFolder);
%%save figure
title(strcat(rootFolder,' ActivityMapSpikes'));
saveas(f, fullfile(pwd,strcat(rootFolder,'_activityMapSpikes.jpg')));
close(f);

end


