function [f,spikeCount] = activityMapSpikes(path,fs,noOfSections)

%% Go into the spike detection folder
cd(path);

list = dir('*');
cd(list(3).name);

list = dir('*ptrain*.mat');
noOfChannels = length(list);

f = figure();

spikeCount = zeros(8);

for k = 1:noOfChannels
fileName = list(k).name;
load(fileName);
[pathStr,onlyFileName,ext] = fileparts(fileName);
elNum = str2double(onlyFileName(end-1:end));

%%Get the row and column of the electrode
[r,c]=getMEAPosition(elNum);

if ~isempty(peak_train) || length(peak_train)>0
spikeCount(r,c) = nnz(peak_train);
end

end

imagesc(spikeCount);

clear 'peak_train';

z = log10(spikeCount);
z(isinf(z))=0;
z(isnan(z))=0;
xlin = linspace(1,8,noOfSections);
[X,Y] = meshgrid(xlin);
x=repmat([1:8]',1,8);
y=repmat(1:8,8,1);
x = x'; 
y = y';
Z = z;
Z = interp2(x,y,z,X,Y);
minVal = min(min(Z(Z~=0)));
Z(isinf(Z))=0;
Z(isnan(Z))=0;
Z(Z==0)=minVal;
imagesc(X(:),Y(:),Z);
% surf(X, Y, Z);
% set(gca,'Zscale','log','Clim',[min(Z(:)) max(Z(:))]);
% view(2);
set(gca,'YTick',[1:1:8]);
%set(gca,'YTickLabel',[8:-1:1]);
cb = colorbar;
set(cb,'YTick',[1,2,3,4]);
set(cb,'YTickLabel',[10,100,1000,10000]);
   
cd ..
cd ..
