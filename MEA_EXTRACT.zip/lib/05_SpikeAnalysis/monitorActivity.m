function monitorActivity()

peakFolder = uigetdir(pwd,'Select PeakDetection folder');
cd(peakFolder);


list = dir('*ptrain*.mat');

afrs = zeros(60,1);
firingChans = 0;
amps = zeros(60,1);
for i=1:length(list)
    load(list(i).name);
    disp(list(i).name);
    timestamps = find(peak_train);
    if ~isempty(timestamps)
        firingChans = firingChans+1;
        afrs(i) = length(timestamps)/(length(peak_train)/25000);
        amps(i) = mean(abs(peak_train(timestamps)));
    end
end

disp(mean(afrs));
disp(firingChans);
disp(mean(amps));

chans = getMEA60Channels();

f = figure();
plot(afrs,'*');
xlabel('Channel No');
ylabel('Firing rate (spikes/s)');
title('Firing Rates');
% set(gca,'XTick',1:60);
% set(gca,'XTickLabel',chans);
grid on

f2 = figure();
plot(amps,'*');
ylabel('Amplitude (uV)');
xlabel('Channel No');
title('Average Amplitude of Spikes');
% set(gca,'XTick',1:60);
% set(gca,'XTickLabel',chans);
grid on



