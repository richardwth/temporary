function chanMat = findISIMax(rootFolder)

%%load the netBUrsts file
cd(rootFolder);
fs=10000;

list = dir('*');
folderName = list(3).name;
cd(folderName);

channels = getMEA60Channels();

list = dir('*PeakDetectionMAT*');
peakFolder = list(1).name;
cd(peakFolder);
list = dir('*ptrain*');
cd(list(1).name);

list = dir('*ptrain*.mat');

chanMat = zeros(60,2);


for i=1:length(list)
    load(list(i).name);
    [~,onlyName,~] = fileparts(list(i).name);
    
    el = str2double(onlyName(end-1:end));
    elNum = find(channels==el);
    
    
    timestamps = find(peak_train);
    isis = diff(timestamps);
    
    burstISI = NaN;
    if ~isempty(timestamps) && nnz(timestamps)>10
        
        bins = logspace(log10(min(isis)),log10(max(isis)),100);
        counts = histc(isis,bins);
        counts = smooth(counts,10,'loess');
%         f=figure();
%         plot(counts);
%         set(gca,'XTick',1:10:length(bins));
%         set(gca,'XTickLabel',bins(1:10:end)./10);
%         hold on
        [val,pos] = findpeaks(counts,'minpeakdistance',10);
        
        thresh = find(bins<100*fs/1000);
        
        if ~isempty(thresh)
            thresh = thresh(end);
            [maxVal,maxPos] = max(val(pos<=thresh));
            
            if ~isempty(maxVal)
               % scatter(pos(maxPos),maxVal);
                
                burstISI = bins(pos(maxPos))/10; %in ms
            end                 
            
        end
   %      close(f);     
    end
    chanMat(elNum,:) = [el,burstISI];
end

