function a=setid(d,id)
% setid - not used, retained for compatibility
%set a.id

a=d;
a.id=id;
