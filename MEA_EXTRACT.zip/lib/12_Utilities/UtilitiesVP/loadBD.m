% loadBD.m
function [BDTrns, burstEl,activeChannels] = loadBD(folder, fName)
% startFolder = pwd;
% cd(folder)
filename = fullfile(folder, fName);
load(filename);
burstEl = find(~cellfun('isempty', burst_detection_cell));
activeChannels = length(find(isActiveChannel==1));
BDTrns = [];
BSTrns = []; %Burst size trains
for k = 1:length(burstEl)
    BDcurElec = burst_detection_cell{burstEl(k)};
    NumBcurElec = size(BDcurElec,1);
    
    BDTrns = [BDTrns; burstEl(k)*ones(NumBcurElec,1) BDcurElec(:,[1,2,7,8,9])];
    BDTrns = BDTrns(1:end-1,:);
end
% cd(startFolder)