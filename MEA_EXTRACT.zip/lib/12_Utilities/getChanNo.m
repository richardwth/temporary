function chanNo = getChanNo(fileName)
%gets channel no as a number given a full file name with _xx.ext format

[~,fileNameOnly,~] = fileparts(fileName);
inds = strfind(fileNameOnly,'_');
chanNo= fileNameOnly(inds(end)+1:end);
chanNo = str2double(chanNo);