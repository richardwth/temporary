function channels = getMultiwell12Channels()

channels = [12:13,21:24,31:34,42:43];
