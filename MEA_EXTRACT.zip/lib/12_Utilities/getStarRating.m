function [nStars,nStarStr] = getStarRating(p)

if p < 0.0001
    nStars = 4;
    nStarStr = '****';
elseif p < 0.001
    nStars = 3;
    nStarStr = '***';
elseif p < 0.01
    nStars = 2;
    nStarStr = '**';
elseif p < 0.05
    nStars = 1;
    nStarStr = '*';
else
    nStars = 0;
    nStarStr = '';
end