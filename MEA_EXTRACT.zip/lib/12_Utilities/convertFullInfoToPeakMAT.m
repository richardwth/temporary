function convertFullInfoToPeakMAT()
%the .spikes files per day have to be in a 1-1-day.spike format

fs = 10000;
channels = getMEA60Channels();

rootFolder = uigetdir(pwd,'Select the root folder');
pause(1);
saveFolder = uigetdir(pwd,'Select the folder to save the files in');


cd(rootFolder);

list = dir('*.spike');

for k=1:length(list)
    cd(rootFolder);
    
    y = loadspike(list(k).name);
    
    
    [pathStr,fileName,ext] = fileparts(list(k).name);
    cd(saveFolder);
    fileName = strcat('wag',fileName);
    fileName = strrep(fileName, '-', '_');
    stringInd = strfind(fileName,'_');
    shortFileName = fileName(1:stringInd(1)-1);
    secFileName = fileName(stringInd(1)+1:stringInd(2)-1);
    mkdir(fileName);
    cd(fileName);
    mkdir(shortFileName);
    cd(shortFileName);
    peakFolder = strcat(shortFileName,'_PeakDetectionMAT');
    mkdir(peakFolder);
    cd(peakFolder);
    subFolder = strcat('ptrain_',shortFileName,'_',secFileName);
    mkdir(subFolder);
    
    cd(subFolder);
    
    minTime =  min(round(y.time*fs));
    for i=1:60
        ind = find(y.channel==convertChannelNoToNormal(channels(i)));
        amps = y.height(ind);
        amps = abs(amps);
        ind = round(y.time(ind)*fs);
        delInds = find(ind==0);
        ind(delInds)=[];
        amps(delInds) = [];
        ind = ind-minTime+1;
        if ~isempty(ind)
            peak_train = sparse(ind,ones(length(ind),1),amps);
            
            saveFileName = strcat(subFolder,'_',num2str(channels(i)));
            save(saveFileName,'peak_train');
        end
    end
end



