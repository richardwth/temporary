function [ans1,ans2] = bhatDist(x1,x2,noOfBins)
% for linear distributions

%if normal
ans1 = 0.25*log(0.25*(var(x1)/var(x2)+var(x2)/var(x1)+2))+0.25*(((mean(x1)-mean(x2))^2)/(var(x1)+var(x2)));

%general
minBin = min([x1;x2]);
maxBin = max([x1;x2]);
bins1 = linspace(min(x1),max(x1),noOfBins);
bins2 = linspace(min(x2),max(x2),noOfBins);
counts1 = histc(x1,bins1);
counts2 = histc(x2,bins2);

counts1 = smooth(counts1,noOfBins/10,'lowess');
counts2 = smooth(counts2,noOfBins/10,'lowess');

counts1 = counts1./sum(counts1);
counts2 = counts2./sum(counts2);

f=figure();
plot(counts1);
hold on
plot(counts2,'r');
close(f);

ans2 = sum(real(sqrt(counts1.*counts2)));