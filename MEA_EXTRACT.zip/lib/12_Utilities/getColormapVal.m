function color = getColormapVal(index,noOfSamples)

cm = colormap;
val = floor(index*size(cm,1)/noOfSamples);
if val<=0
    val =1;
end

color = cm(val,:);