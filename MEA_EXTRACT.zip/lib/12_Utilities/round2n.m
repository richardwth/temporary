function out = round2n(number,decimals)

out = round(number*(10^decimals))/(10^decimals);