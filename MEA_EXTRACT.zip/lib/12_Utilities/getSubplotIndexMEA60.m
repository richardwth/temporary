function ind = getSubplotIndexMEA60(chanNo)

[x,y] = getMEAPosition(chanNo);
ind = 8*(x-1)+y;