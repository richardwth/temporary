upperRootFolder = uigetdir(pwd,'Select upper root folder');
cd(upperRootFolder);

list = dir('*');

wellLabel = cell(24,1);
for i=1:6
    wellLabel{i} = strcat('A',num2str(i));
end
for i=7:12
    wellLabel{i} = strcat('B',num2str(i-6));
end
for i=13:18
    wellLabel{i} = strcat('C',num2str(i-12));
end
for i=19:24
    wellLabel{i} = strcat('D',num2str(i-18));
end

for i=3:length(list)
    cd(upperRootFolder);
    cd(list(i).name);
    
    wellList = dir('*Well*');
    for j=1:length(wellList)
        wellName = wellList(j).name;
        inds = strfind(wellName,'_');
        wellNo = wellName(inds(1)+1:end);
        wellNo = str2double(wellNo);
        newName = strcat('Well_',wellLabel{wellNo});
        movefile(wellList(j).name,newName);
    end
end