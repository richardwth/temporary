function deleteDirAuto()


upperRootFolder = uigetdir(pwd,'Select the root folder');
cd(upperRootFolder);

folderList = dir('*');

rootPath = pwd;

for samplex = 3:length(folderList)
  
    cd(rootPath);
    rootFolder = folderList(samplex).name;
    cd(rootFolder);
    
    disp(sprintf('Processing folder %s',rootFolder));
    
    list = dir('*');
    folderName = list(3).name;
    cd(folderName);
    
    list = dir('*');
    for i=3:length(list)       
        if ~isempty(strfind(list(i).name,'BurstDetectionMAT'))
             disp(list(i).name);
            rmdir(list(i).name,'s');
        end
    end
    
end

