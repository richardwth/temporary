function CH = clusEvalCH(data,idx,mu,withinGroupSums)
%data: rows are observations/samples, columns are features
%idx: Column vector containing the cluster number of each sample
%mu: rows are centroids, columns are coordinates of each centroid
%withinGroupSums: sum of distances between each samples in a cluster and its cluster centroid

N = size(data,1); %no of observations
p = size(data,2); %no of features
k=length(unique(idx)); %no of clusters

if nargin<3
    mu = zeros(k,p);
    withinGroupSums = zeros(k,1);
    for i=1:k
        inds = find(idx==i);
        mu(i,:) = nanmean(data(inds,:));
        totalSum = 0; 
        for j=1:length(inds)
            totalSum = totalSum + sum((data(inds(j),:)-mu(i,:)).^2);
        end
        withinGroupSums(i)=totalSum;
    end
end

mu0 = nanmean(data);
SSB=0;
for i=1:k
    n = length(find(idx==i));
    SSB=SSB+n*sum((mu(i,:)-mu0).^2);
end

SSW = sum(withinGroupSums);

if k==1
    CH = 0;
else
    CH = SSB*(N-k)/(SSW*(k-1));
end