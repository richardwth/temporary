function waChannel = convertChannelNoToNormal(channelNo)

channels = getMEA60Channels();
waChannels = [20,18,15,60,11,9,23,21,19,16,13,10,8,6,25,24,22,17,12,7,5,4,28,29,27,26,3,2,0,1,31,30,32,33,56,57,59,58,34,35,37,42,47,52,54,55,36,38,40,43,46,49,51,53,39,41,44,45,48,50];
ind = find(channels==channelNo);
waChannel = waChannels(ind);