function [meaChannels,meaPositions]=mea60Positions

channels = [12:17,21:28,31:38,41:48,51:58,61:68,71:78,82:87];

meaChannels = zeros(8,8);
meaPositions = zeros(8,8);

for i=1:6
    meaChannels(i+1,1) = channels(i);
    meaPositions(i+1,1) = i;
end
for j=2:7
    for i=1:8
        meaChannels(i,j) = channels(6+(j-2)*8+i);
        meaPositions(i,j) = 6+(j-2)*8+i;
    end
end
for i=1:6
    meaChannels(i+1,8) = channels(54+i);
    meaPositions(i+1,8) = 54+i;
end

