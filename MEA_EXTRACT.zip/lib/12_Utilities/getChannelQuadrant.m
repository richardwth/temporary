function quad = getChannelQuadrant(channel)


[x,y] = getMEAPosition(channel);

%x--row
%y--column
if x<=4 && y<=4
    quad = 1;
elseif x<=4 && y>4
    quad = 2;
elseif x>4 && y<=4
    quad = 3;
elseif x>4 && y>4
    quad = 4;
end