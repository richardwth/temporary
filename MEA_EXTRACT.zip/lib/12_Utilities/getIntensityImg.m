function f = getIntensityImg(channelNo,channelVals)

imgMat = zeros(8,8);

for i=1:length(channelNo)    
[x,y]=getMEAPosition(channelNo(i));
imgMat(x,y)=channelVals(i);
end

f = figure();
imagesc(imgMat);

colorbar