function channels = getMEA60Channels

channels = [12:17,21:28,31:38,41:48,51:58,61:68,71:78,82:87];
