function convertSpikeFiles()

fs = 10000;
channels = [12:17,21:28,31:38,41:48,51:58,61:68,71:78,82:87];

startFolder = uigetdir(pwd,'Select the folder with the input files');
pause(1);
saveFolder = uigetdir(pwd,'Select the folder to save the files in');

cd(startFolder);
list = dir('*.mat');

for x=1:length(list)
    cd(startFolder);
    load(list(x).name);
    disp(list(x).name);
    [pathStr,fileName,ext] = fileparts(list(x).name);
    cd(saveFolder);
    fileName = strcat('wag',fileName);
    fileName = strrep(fileName, '-', '_');
    stringInd = strfind(fileName,'_');
    shortFileName = fileName(1:stringInd(1)-1);
    secFileName = fileName(stringInd(1)+1:stringInd(2)-1);
    mkdir(fileName);
    cd(fileName);
    mkdir(shortFileName);
    cd(shortFileName);
    peakFolder = strcat(shortFileName,'_PeakDetectionMAT');
    mkdir(peakFolder);
    cd(peakFolder);
    subFolder = strcat('ptrain_',shortFileName,'_',secFileName);
    mkdir(subFolder);
    cd(subFolder);
    
     minTime =  min(round(spk.tms*fs));
    for i=1:60      
       
        ind = find(spk.chs==convertChannelNoToNormal(channels(i)));
        ind = round(spk.tms(ind)*fs);
        ind(ind==0)=[];
        ind = ind-minTime+1;
        ind(ind>10^8)=[];
        if ~isempty(ind)
            peak_train = sparse(ind,ones(length(ind),1),ones(length(ind),1));
            
            saveFileName = strcat(subFolder,'_',num2str(channels(i)));
            save(saveFileName,'peak_train');
        end
    end
end
