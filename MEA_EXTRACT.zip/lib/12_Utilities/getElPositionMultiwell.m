function [x,y] = getElPositionMultiwell(channel)
%Gives the row and column positions of a given channel. Rows are counted
%from top to bottom and columns are counted from left to right
%Input channel number as in 12, 13, ...87

channelArray =getMultiwell12Channels();

%% error handling
if isempty(find(channel==channelArray, 1))
    error('Invalid channel input');
end

mea = [0 21 31 0;
      12 22 32 42;
      13 23 33 43;
       0 24 34 0];

[x,y] = find(mea==channel);