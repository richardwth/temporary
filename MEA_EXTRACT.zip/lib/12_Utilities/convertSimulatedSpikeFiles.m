function convertSimulatedSpikeFiles()

fs = 10000;
channels = getMEA60Channels();


%% Initialize variables.
delimiter = ' ';
if nargin<=2
    startRow = 1;
    endRow = inf;
end

startFolder = uigetdir(pwd,'Select the folder with the input files');
pause(1);
saveFolder = uigetdir(pwd,'Select the folder to save the files in');

cd(startFolder);
list = dir('*.txt');

for x=1:length(list)
    cd(startFolder);    
    disp(list(x).name);
    
     
    formatSpec = '%f%f%[^\n\r]';
    
    %% Open the text file.
    fileID = fopen(list(x).name,'r');
    
    %% Read columns of data according to format string.
    dataArray = textscan(fileID, formatSpec, endRow(1)-startRow(1)+1, 'Delimiter', delimiter, 'MultipleDelimsAsOne', true, 'EmptyValue' ,NaN,'HeaderLines', startRow(1)-1, 'ReturnOnError', false);
    for block=2:length(startRow)
        frewind(fileID);
        dataArrayBlock = textscan(fileID, formatSpec, endRow(block)-startRow(block)+1, 'Delimiter', delimiter, 'MultipleDelimsAsOne', true, 'EmptyValue' ,NaN,'HeaderLines', startRow(block)-1, 'ReturnOnError', false);
        for col=1:length(dataArray)
            dataArray{col} = [dataArray{col};dataArrayBlock{col}];
        end
    end
    
    channelNos = dataArray{:, 1};
    timestamps = round(dataArray{:, 2}.*fs);
    channelNos(timestamps==0) = [];
    timestamps(timestamps==0) = [];
    
    %% Close the text file.
    fclose(fileID);       
    
    [pathStr,fileName,ext] = fileparts(list(x).name);
    
     %%Create folders
    
    cd(saveFolder);
    fileName = strrep(fileName, '-', '_');
    stringInd = strfind(fileName,'_');
    shortFileName = fileName(1:stringInd(1)-1);
    secFileName = fileName(stringInd(1)+1:stringInd(2)-1);
    mkdir(fileName);
    cd(fileName);
    mkdir(shortFileName);
    cd(shortFileName);
    peakFolder = strcat(shortFileName,'_PeakDetectionMAT');
    mkdir(peakFolder);
    cd(peakFolder);
    subFolder = strcat('ptrain_',shortFileName,'_',secFileName);
    mkdir(subFolder);
    cd(subFolder); 
    
    for i=1:60
        ind = find(channelNos==i);
        ind = timestamps(ind);
        ind = sort(ind);
        if ~isempty(ind)
            peak_train = sparse(ind,ones(length(ind),1),ones(length(ind),1));
            
            saveFileName = strcat(subFolder,'_',num2str(channels(i)));
            save(saveFileName,'peak_train');
        end
    end
end

