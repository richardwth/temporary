function plotMeanStd(xVals,meanVec,stdVec,colorStd,lineSpecMean)

a = meanVec-stdVec;
fill([xVals,fliplr(xVals)],[meanVec+stdVec,fliplr(a)],colorStd,'EdgeColor',colorStd);
hold on
plot(xVals,meanVec,lineSpecMean);