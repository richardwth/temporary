function clr;
% Clear workspace, close all windows, clears command window

%---------------------------------------------------------------|
% 	Sergei Koptenko, Medipattern Corp., Toronto    |
%	phone (416)744-0009 fax (416)744--6899         |
%	skoptenko@medipattern.com                             |
%---------------May/06/2002-------------------------------|

 evalin('base','clear all; clc;');

