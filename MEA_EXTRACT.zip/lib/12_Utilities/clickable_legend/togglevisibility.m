function togglevisibility(hObject, obj,textObj)

if get(hObject, 'UserData') % It is on, turn it off
    set(hObject, 'Color', (get(hObject, 'Color') + 1)/1.5, 'UserData', false);
    set(obj,'HitTest','off','Visible','off','handlevisibility','off');
    if ~isempty(textObj)
    set(textObj,'HitTest','off','Visible','off','handlevisibility','off');
    end
else
    set(hObject, 'Color', get(hObject, 'Color')*1.5 - 1, 'UserData', true);
    set(obj, 'HitTest','on','visible','on','handlevisibility','on');
    if ~isempty(textObj)
    set(textObj, 'HitTest','on','visible','on','handlevisibility','on');
    end
end
