
function highlightObject(lTextObj, lMarkerObj, plotObj, plotOptions)
lw = get(plotObj,'LineWidth');
if ~iscell(lw), lw = {lw}; end;
ms = get(plotObj,'MarkerSize');
if ~iscell(ms), ms = {ms}; end;

if ~get(plotObj(1), 'UserData') % It is not selected, highlight it
    %set(hObject, 'FontWeight', 'bold');
    set(lTextObj, 'EdgeColor', 'k');
    set(plotObj, {'LineWidth', 'MarkerSize'}, [cellfun(@(x)x+2, lw, 'Uniformoutput', false) cellfun(@(x)x+2, ms, 'uniformoutput', false)]);
    set(plotObj, 'UserData', true);
else
    %set(hObject, 'FontWeight', 'normal');
    set(lTextObj, 'EdgeColor', 'none');
    set(plotObj, {'LineWidth', 'MarkerSize'}, [cellfun(@(x)x-2, lw, 'Uniformoutput', false) cellfun(@(x)x-2, ms, 'uniformoutput', false)]);
    set(plotObj, 'UserData', false);
end
if ~isempty(plotOptions)
    set(lMarkerObj, plotOptions{:});
end