%draw means and statistical significance for single well data
%load data params
[fileName,path] = uigetfile('*.xls','Select parameter file');

saveFolder = uigetdir(pwd,'Select folder to save files in');

cd(path);
[~, ~, dataParams] = xlsread(fileName,'Sheet1');
dataParams(cellfun(@(x) ~isempty(x) && isnumeric(x) && isnan(x),dataParams)) = {''};

titles = dataParams(1,1:end-1);
data = dataParams(2:end,1:end-1);
data = cell2mat(data);
names = dataParams(2:end,end);

samples = cell(0);
times = cell(0);
for i=1:length(names)
    name = names{i};
    inds = strfind(name,' ');
    sample = name(1:inds(1)-1);
    inds = strfind(name,'T');
    time = name(inds(1)+1:end);
    samples = [samples,sample];
    times = [times,time];
end

uniqueSamples = unique(samples);
timePts = unique(times);

pMat = zeros(length(timePts)-1,size(data,2));
hMat = zeros(length(timePts)-1,size(data,2));
means = zeros(length(timePts),size(data,2));
SEMs = zeros(length(timePts),size(data,2));

baselineInds = find(ismember(times,timePts{1}));

%for each time point except for baseline
for i=2:length(timePts)
    inds = find(ismember(times,timePts{i}));
    for j=1:size(data,2)
        values = data(inds,j);
        values = values(values~=0);
        baselineVals = data(baselineInds,j);
        baselineVals = baselineVals(baselineVals~=0);
        
        %for each time point except for the baseline, test for significant
        %differneces in each parameter between that and baseline
        [pLeft,hLeft] = ranksum(values,baselineVals,'tail','left');
        [pRight,hRight] = ranksum(values,baselineVals,'tail','right');
        pMat(i-1,j) = min(pLeft,pRight);
        hMat(i-1,j) = max(hLeft,hRight);
        
        means(1,j) = mean(baselineVals);
        SEMs(1,j) = std(baselineVals)/real(sqrt(length(baselineVals)));
        means(i,j) = mean(values);
        SEMs(i,j) = std(values)/real(sqrt(length(values)));
        
    end
end

cd(saveFolder);
save('stats.mat','pMat','hMat');
xlswrite('stats.xls', pMat, 'Sheet1', 'A1');
xlswrite('stats.xls', hMat, 'Sheet2', 'A1');


for j=1:size(data,2)
f = figure('Position', [100, 100, 820, 420]);
h = barwitherr(SEMs(:,j), means(:,j));
set(gca,'XTickLabel',{'Base','2nM-0','2nM-5','2nM-10','2nM-15','10nM-0','10nM-5','10nM-10','10nM-15'});
ylabel(dataParams{1,j});
hold on
for i=1:size(hMat,1)
    [~,nStarStr] = getStarRating(pMat(i,j));
    height = means(i+1,j)+SEMs(i+1,j)+max(SEMs(:,j))/5;
    text(i+1,height,nStarStr);
end
%saveas(f,strcat(dataParams{1,j},'.jpg'));
fileName = strcat(dataParams{1,j},'.jpg');
 set(gcf,'PaperUnits','inches','PaperPosition',[0 0 4.75 2.5]);
 print('-djpeg',fileName,'-r100');
close(f);
end
