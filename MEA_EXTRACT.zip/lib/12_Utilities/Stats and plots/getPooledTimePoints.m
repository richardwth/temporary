function [pooledData,pooledChanges,times] = getPooledTimePoints(dataParams)
%returns the pooled data for each time point as separate matrices with rows
%being samples and columns being parameters



times = cell2mat(dataParams(2:end,end));
try
    times = str2num(times);
end
noOfTimePts = length(unique(times));

%samples = unique(dataParams(2:end,end-1));

pooledData = cell(noOfTimePts,1);
pooledChanges = cell(noOfTimePts,1);


for i=1:noOfTimePts  
        timeInds = find(times==i);
        timeVals = cell2mat(dataParams(1+timeInds,1:end-2));
        pooledData{i} = timeVals;
end

for i=2:noOfTimePts  
        baselineInds = find(times==1);
        timeInds = find(times==i);
        baselines = cell2mat(dataParams(1+baselineInds,1:end-2));
        afterwards = cell2mat(dataParams(1+timeInds,1:end-2));
        
        baselineSamples = dataParams(1+baselineInds,end-1);
        afterwardsSamples = dataParams(1+timeInds,end-1);
        
        for j=1:length(baselineSamples)
            try
            baselineSamples{j} = num2str(baselineSamples{j});
            end
        end
        
        for j=1:length(afterwardsSamples)
            try
            afterwardsSamples{j} = num2str(afterwardsSamples{j});
            end
        end
        
        %remove baslines where later timepoints are missing (as 2h and 24hr
        %time points might be missing)      
        inds = find(~ismember(baselineSamples,afterwardsSamples));
        baselines(inds,:) = [];
        
        percChange = 100*(afterwards-baselines)./baselines;
        pooledChanges{i-1} = percChange;  
        
end
