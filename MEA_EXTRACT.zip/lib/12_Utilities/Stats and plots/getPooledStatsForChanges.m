function [means,SEMs] = getPooledStatsForChanges(dataParams)
%returns means and SEMs as separate matrices with rows being percentage
%changes corresponding to difference time points and columns being
%parameters

times = cell2mat(dataParams(2:end,end));
try
times = str2num(times);
end
noOfTimePts = length(unique(times));

samples = dataParams(2:end,end-1);

means = [];
SEMs = [];

for i=2:noOfTimePts 
    disp(i);
        baselineInds = find(times==1);
        timeInds = find(times==i);
        baselines = cell2mat(dataParams(1+baselineInds,1:end-2));
        afterwards = cell2mat(dataParams(1+timeInds,1:end-2));
        
        baselineSamples = dataParams(1+baselineInds,end-1);
        afterwardsSamples = dataParams(1+timeInds,end-1);
        
        %remove baslines where later timepoints are missing (as 2h and 24hr
        %time points might be missing)      
        inds = find(~ismember(cell2mat(baselineSamples),cell2mat(afterwardsSamples)));
        baselines(inds,:) = [];

        
        percChange = 100*(afterwards-baselines)./baselines;
     
        means = [means;nanmean(percChange)];
        nonNanSizeSQRT = zeros(1,size(dataParams,2)-2);
        for j=1:length(nonNanSizeSQRT)
            nonNanSizeSQRT(j) = sqrt(length(~isnan(percChange(:,j))));
        end
        SEMs = [SEMs;nanstd(percChange)./nonNanSizeSQRT]; 
end

means(isinf(means)) = NaN;
SEMS(isinf(SEMs)) = NaN; %ind cuased by inactivity at one time point/ have to remove or else bar charts have very high ylimits