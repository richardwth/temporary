%drawing conolidine params for allParam.mat with T1, T2... folders
folder = uigetdir('Select folder'); %give the root folder where all the concentrations are stored
cd(folder);
folder = pwd;

%Get DMSO params
list = dir('*DMSO*');
cd(list(1).name);
list = dir('*Pooled*');
load(list(1).name);

[DMSOMeans,DMSOSEMs] = getPooledStatsForChanges(dataParams);
[DPooledData,DPooledChanges] = getPooledTimePoints(dataParams);

%Get 10uM params
cd(folder);
list = dir('*Conolidine 10uM*');
cd(list(1).name);
list = dir('*Pooled*');
load(list(1).name);

[C10Means,C10SEMs] = getPooledStatsForChanges(dataParams);
C10Means = C10Means(4:end,1:35);
C10SEMs = C10SEMs(4:end,1:35);
[C10PooledData,C10PooledChanges] = getPooledTimePoints(dataParams);

%Get 30uM params
cd(folder);
list = dir('*Conolidine 30uM*');
cd(list(1).name);
list = dir('*Pooled*');
load(list(1).name);

[C30Means,C30SEMs] = getPooledStatsForChanges(dataParams);
[C30PooledData,C30PooledChanges] = getPooledTimePoints(dataParams);

%Convert to time arrays
T1Means = [DMSOMeans(1,:);C10Means(1,:);C30Means(1,:)];
T2Means = [DMSOMeans(2,:);C10Means(2,:);C30Means(2,:)];
T3Means = [DMSOMeans(3,:);C10Means(3,:);C30Means(3,:)];
%T4Means = [DMSOMeans(4,:);C10Means(4,:);C30Means(4,:)];

T1SEMs= [DMSOSEMs(1,:);C10SEMs(1,:);C30SEMs(1,:)];
T2SEMs = [DMSOSEMs(2,:);C10SEMs(2,:);C30SEMs(2,:)];
T3SEMs = [DMSOSEMs(3,:);C10SEMs(3,:);C30SEMs(3,:)];
%T4SEMs = [DMSOSEMs(4,:);C10SEMs(4,:);C30SEMs(4,:)];

titles = dataParams(1,1:end-2);

% for i=1:titles
%     f = figure();
%     hold on
%     
%     errorbar(1:3,T1avg(:,i),T1std(:,i),'-o','color',[0,76/255,153/255]); %15min
%     errorbar(1:3,T2avg(:,i),T2std(:,i),'-o','color',[0,128/255,255/255]); %2hr
%     errorbar(1:3,T3avg(:,i),T3std(:,i),'-o','color',[153/255,205/255,255/255]); %24hr
%     
%      h = legend('15min','2h','24h');
%      set(h,'location','NorthEastOutside');
%      
%       patchline([0.5,3.5],[0,0], [], 'EdgeColor', [0,0,0],'LineWidth', 1, 'EdgeAlpha', 0.75 );
%      
%      patchline(1:3,T1avg(:,i), [], 'EdgeColor', [0,76/255,153/255],'LineWidth', 2, 'EdgeAlpha', 0.5 );
%     patchline(1:3,T2avg(:,i), [], 'EdgeColor', [0,128/255,255/255],'LineWidth', 2, 'EdgeAlpha', 0.5 );
%     patchline(1:3,T3avg(:,i), [], 'EdgeColor', [153/255,205/255,255/255],'LineWidth', 2, 'EdgeAlpha', 0.5 );
%     
%     
%     
%   %  grid on
%      
%     title(titles(i));
%     ylabel(titles(i));
%     set(gca,'XTick',1:4);
%     set(gca,'XTickLabel',{'Control','10uM','30uM'});
%     xlabel('Concentration (uM)');
%     fileName = strcat(titles{i},'_ConProfile.jpg');
%     %saveas(f,fileName);
%     
%     set(f,'PaperUnits','inches','PaperPosition',[0 0 4 2]);
% print('-djpeg', fileName, '-r100');
% 
%    %ylim([min(a(:,i)-b(:,i))-2,max(a(:,i)-b(:,i))+2]);
%     close(f);
% end

folder = uigetdir('Select folder to save the files in');
cd(folder);

for i=1:length(titles)
    f = figure();
    hold on
   
  
    errorbar(1:3,DMSOMeans(:,i),DMSOSEMs(:,i),'-o','color','blue'); %DMSO
    errorbar(1:3,C10Means(:,i),C10SEMs(:,i),'-o','color',[242/255,201/255,201/255]); %10uM 
    errorbar(1:3,C30Means(:,i),C30SEMs(:,i),'-o','color',[214/255,43/255,43/255]);%30uM
    
     h = legend('Control','10uM','30uM');
     set(h,'location','NorthEastOutside');
     
    patchline([0.5,3.5],[0,0],[], 'EdgeColor', [0,0,0],'LineWidth', 1, 'EdgeAlpha', 0.75 );
    patchline(1:3,DMSOMeans(:,i),[], 'EdgeColor', 'blue','LineWidth', 2, 'EdgeAlpha', 0.5 );
    patchline(1:3,C10Means(:,i),[], 'EdgeColor', [242/255,201/255,201/255],'LineWidth', 2, 'EdgeAlpha', 0.5 );
    patchline(1:3,C30Means(:,i),[], 'EdgeColor', [214/255,43/255,43/255],'LineWidth', 2, 'EdgeAlpha', 0.5 );
     
   % grid on
    
    title(titles(i));
    ylabel(titles(i));
    set(gca,'XTick',1:3);
    set(gca,'XTickLabel',{'15min','2h','24h'});
    xlabel('Time');
    saveas(f,strcat(titles{i},'_TimeProfile.jpg'));
   %ylim([min(a(:,i)-b(:,i))-2,max(a(:,i)-b(:,i))+2]);
   
   fileName = strcat(titles{i},'_TimeProfile.jpg');
   set(f,'PaperUnits','inches','PaperPosition',[0 0 4 4]);
   print('-djpeg', fileName, '-r100');
    close(f);
end

D = DPooledChanges{1};
C10  = C10PooledChanges{4};
C30  = C30PooledChanges{1};

for i=1:length(titles)
    f = figure();

    barwitherr(T1SEMs(:,i),T1Means(:,i)); %15min
    hold on
    plot(4,0,'.');
    grid on    
   
    [~,pC10] = ttest2(D(:,i),C10(:,i));
    [~,pC30] = ttest2(D(:,i),C30(:,i));

     h = legend(strcat('C10 p=',num2str(pC10)),strcat('C30 p=',num2str(pC30)));
     set(h,'location','NorthEastOutside');
  
    title(titles(i));
    ylabel(titles(i));
    set(gca,'XTick',1:4);
    set(gca,'XTickLabel',{'Control','10uM','30uM','50uM'});
    xlim([0.5,4.5]);
    xlabel('Concentration (uM)');
    fileName = strcat(titles{i},'_barChart15.jpg');
    %saveas(f,fileName);
    
    set(f,'PaperUnits','inches','PaperPosition',[0 0 5 2]);
print('-djpeg', fileName, '-r100');

   %ylim([min(a(:,i)-b(:,i))-2,max(a(:,i)-b(:,i))+2]);
    close(f);
    
    
end