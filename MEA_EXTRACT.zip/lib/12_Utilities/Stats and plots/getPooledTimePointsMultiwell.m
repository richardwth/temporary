function [pooledData,pooledChanges,pooledAbsCell,pooledChangesCell,pooledDataMeans,pooledDataSEMs,pooledChangesMeans,pooledChangesSEMs,timePts] = getPooledTimePointsMultiwell(dataParams)
%returns the pooled data for each time point as separate matrices with rows
%being samples and columns being parameters
%MAKE SURE BASELINE IS THE FIRST TIME POINT. SO DON"T LABEL ANYTHING ELSE
%WITH A NAME THAT STARTS WITH SOMETHING BEFORE 'B'


 %remove samples where the well is not bursting for all time points      
 wells = dataParams(2:end,end);
 uniqueWells = unique(wells);
 noOfWells = length(uniqueWells);
 
 for i=1:noOfWells
     wells = dataParams(2:end,end);
     wellInds = find(ismember(wells,uniqueWells{i}));
     wellData =  cell2mat(dataParams(1+wellInds,1:end-2));
    
    inactiveInds = find(wellData(:,1)==0 & wellData(:,5)==0); %only checking 2 columns for zeros. MAKE SURE COLUMN 1 and 5 ARE NOT MFRALL AND AVGAMP
    if length(inactiveInds) == size(wellData,1)
        dataParams(wellInds(inactiveInds)+1,:) = [];
    end
 end

 %Get new no of wells
 wells = dataParams(2:end,end);
 uniqueWells = unique(wells);
 noOfWells = length(uniqueWells);
 
times = dataParams(2:end,end-1);
timePts = unique(times);
noOfTimePts = length(unique(times));

pooledData = cell(noOfTimePts,1);
pooledChanges = cell(noOfTimePts,1);
pooledDataMeans = zeros(noOfTimePts,size(dataParams,2)-2);
pooledChangesMeans = zeros(noOfTimePts-1,size(dataParams,2)-2);
pooledDataSEMs = zeros(noOfTimePts,size(dataParams,2)-2);
pooledChangesSEMs = zeros(noOfTimePts-1,size(dataParams,2)-2);

pooledAbsCell = [];
pooledChangesCell = [];

for i=1:noOfTimePts  
        timeInds = find(ismember(times,timePts{i}));
        timeVals = cell2mat(dataParams(1+timeInds,1:end-2));
        pooledData{i} = timeVals;
        pooledAbsCell = [pooledAbsCell;dataParams(1+timeInds,:)];

        timeVals(isinf(timeVals)) = NaN;
        pooledDataMeans(i,:) = nanmean(timeVals);
        pooledDataSEMs(i,:) = nanstd(timeVals)./real(sqrt(size(timeVals,1)));
end

for i=2:noOfTimePts  
        baselineInds = find(ismember(times,timePts{1}));
        timeInds = find(ismember(times,timePts{i}));
        baselines = cell2mat(dataParams(1+baselineInds,1:end-2));
        afterwards = cell2mat(dataParams(1+timeInds,1:end-2));
        
      
        percChange = 100*(afterwards-baselines)./baselines;
        pooledChanges{i-1} = percChange;   
        pooledChangesCell = [pooledChangesCell;[num2cell(percChange),dataParams(1+timeInds,end-1:end)]];
        
        percChange(isinf(percChange)) = NaN;
        
        pooledChangesMeans(i-1,:) = nanmean(percChange);
        pooledChangesSEMs(i-1,:) = nanstd(percChange)./real(sqrt(size(percChange,1)));
end
