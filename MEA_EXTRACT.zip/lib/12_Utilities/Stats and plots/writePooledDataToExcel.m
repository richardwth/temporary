%Save percentage changes for each time point for all drugs
%for use with graphPad

folder = uigetdir('Select folder'); %give the root folder where all the concentrations are stored
cd(folder);
folder = pwd;

%Get DMSO params
list = dir('*DMSO 30uM*');
cd(list(1).name);
list = dir('*Pooled*.xls');

[~, ~, dataParams] = xlsread(list(1).name,'Sheet1');

%dataParams(cellfun(@(x) ~isempty(x) && isnumeric(x) && isnan(x),dataParams)) = {''};

[D30PooledData,D30PooledChanges,D30Times] = getPooledTimePoints(dataParams);

%Get Baclofen 1uM params
cd(folder);
list = dir('DMSO 10uM*');
cd(list(1).name);
list = dir('*Pooled*.xls');

[~, ~, dataParams] = xlsread(list(1).name,'Sheet1');

[D10PooledData,D10PooledChanges,D10Times] = getPooledTimePoints(dataParams);


%Get Baclofen 1uM params
cd(folder);
list = dir('*Baclofen 1uM*');
cd(list(1).name);
list = dir('*Pooled*.xls');

[~, ~, dataParams] = xlsread(list(1).name,'Sheet1');

[BPooledData,BPooledChanges,BTimes] = getPooledTimePoints(dataParams);


%Get Conolidine 10uM params
cd(folder);
list = dir('*Conolidine 10uM*');
cd(list(1).name);
list = dir('*Pooled*.xls');

[~, ~, dataParams] = xlsread(list(1).name,'Sheet1');

dataParams = adjustParams(dataParams);[C10PooledData,C10PooledChanges,C10Times] = getPooledTimePoints(dataParams);

%Get Conolidine 30uM params
cd(folder);
list = dir('*Conolidine 30uM*');
cd(list(1).name);
list = dir('*Pooled*.xls');

[~, ~, dataParams] = xlsread(list(1).name,'Sheet1');

[C30PooledData,C30PooledChanges,C30Times] = getPooledTimePoints(dataParams);

%Get CGP7930 1uM params
cd(folder);
list = dir('*CGP 1uM*');
cd(list(1).name);
list = dir('*Pooled*.xls');

[~, ~, dataParams] = xlsread(list(1).name,'Sheet1');

[CGPPooledData,CGPPooledChanges,CGPTimes] = getPooledTimePoints(dataParams);

%Concatenate all drugs at one time point into 1 matrix
%some drugs have different time points so watch out for which timepoints
%you concatenate. And T3 in one drug is not the same as T3 in another!!! SO
%you have to select times manually

CGPPooledData = {CGPPooledData{1};CGPPooledData{5};CGPPooledData{6};CGPPooledData{7}};
CGPPooledChanges = {CGPPooledChanges{4};CGPPooledChanges{5};CGPPooledChanges{6}};

allPooledData = cell(4,1);
allPooledMeans = cell(4,1);
allPooledSEMs = cell(4,1);

for i=1:4
    titles = dataParams(1,1:end-1);
    
    D30data = num2cell(D30PooledData{i});
    D30data = [D30data,repmat({'D'},size(D30data,1),1)];
    
    D10data = num2cell(D10PooledData{i});
    D10data = [D10data,repmat({'D'},size(D10data,1),1)];
    
    Bdata = num2cell(BPooledData{i});
    Bdata = [Bdata,repmat({'B'},size(Bdata,1),1)];
    
    C10data = num2cell(C10PooledData{i});
    C10data = [C10data,repmat({'C10'},size(C10data,1),1)];
    
    C30data = num2cell(C30PooledData{i});
    C30data = [C30data,repmat({'C30'},size(C30data,1),1)];
    
    CGPdata = num2cell(CGPPooledData{i});
    CGPdata = [CGPdata,repmat({'CGP'},size(CGPdata,1),1)];
    
    allPooledData{i} = [titles;D30data;D10data;Bdata;C10data;C30data;CGPdata];
    
    allPooledMeans{i} = [nanmean(cell2mat(D30data(1:end,1:end-1)));nanmean(cell2mat(D10data(1:end,1:end-1)));nanmean(cell2mat(Bdata(1:end,1:end-1)));...
        nanmean(cell2mat(C10data(1:end,1:end-1)));nanmean(cell2mat(C30data(1:end,1:end-1)));nanmean(cell2mat(CGPdata(1:end,1:end-1)))];
    allPooledSEMs{i} = [nanstd(cell2mat(D30data(1:end,1:end-1)));nanstd(cell2mat(D10data(1:end,1:end-1)));nanstd(cell2mat(Bdata(1:end,1:end-1)));...
        nanstd(cell2mat(C10data(1:end,1:end-1)));nanstd(cell2mat(C30data(1:end,1:end-1)));nanstd(cell2mat(CGPdata(1:end,1:end-1)))];
    
     drugs = {'D30','D10','B','C10','C30','CGP'};
    allPooledMeans{i} = [titles;[num2cell(allPooledMeans{i}),drugs']];
    allPooledSEMs{i} = [titles;[num2cell(allPooledSEMs{i}),drugs']];
end

allPooledChanges = cell(3,1);
allPooledChangesMeans = cell(3,1);
allPooledChangesSEMs = cell(3,1);


for i=1:3
    titles = dataParams(1,1:end-1);
    
    D30data = num2cell(D30PooledChanges{i});
    D10data = num2cell(D10PooledChanges{i});
    Bdata   = num2cell(BPooledChanges{i});
    C10data = num2cell(C10PooledChanges{i});
    C30data = num2cell(C30PooledChanges{i});
    CGPdata = num2cell(CGPPooledChanges{i});
    
    % find parameters that are significantly different between 2 drug
    % categories
    
    
    if i==1
        
        params = [titles',num2cell(zeros(length(titles),1))];
        for j=1:length(titles)-1
            
            disp(titles{j});
            [p,h]=ranksum(cell2mat(C30data(:,j)),cell2mat(D30data(:,j)));
            if h==1
                params{j,2} = params{j,2}+1;
            end
            [p,h]=ranksum(cell2mat(C30data(:,j)),cell2mat(CGPdata(:,j)));
            if h==1
                params{j,2} = params{j,2}+1;
            end
            [p,h]=ranksum(cell2mat(C30data(:,j)),cell2mat(Bdata(:,j)));
            if h==1
                params{j,2} = params{j,2}+1;
            end
            [p,h]=ranksum(cell2mat(D30data(:,j)),cell2mat(CGPdata(:,j)));
            if h==1
                params{j,2} = params{j,2}+1;
            end
            [p,h]=ranksum(cell2mat(D30data(:,j)),cell2mat(Bdata(:,j)));
            if h==1
                params{j,2} = params{j,2}+1;
            end
            [p,h]=ranksum(cell2mat(CGPdata(:,j)),cell2mat(Bdata(:,j)));
            if h==1
                params{j,2} = params{j,2}+1;
            end
        end
        
        
    end
    
    D30data = [D30data,repmat({'D30'},size(D30data,1),1)];
    D10data = [D10data,repmat({'D10'},size(D10data,1),1)];
    Bdata   = [Bdata,repmat({'B'},size(Bdata,1),1)];
    C10data = [C10data,repmat({'C10'},size(C10data,1),1)];
    C30data = [C30data,repmat({'C30'},size(C30data,1),1)];
    CGPdata = [CGPdata,repmat({'CGP'},size(CGPdata,1),1)];
    
    allPooledChanges{i} = [titles;D30data;D10data;Bdata;C10data;C30data;CGPdata];
    
    allPooledChangesMeans{i} = [nanmean(cell2mat(D30data(1:end,1:end-1)));nanmean(cell2mat(D10data(1:end,1:end-1)));nanmean(cell2mat(Bdata(1:end,1:end-1)));...
        nanmean(cell2mat(C10data(1:end,1:end-1)));nanmean(cell2mat(C30data(1:end,1:end-1)));nanmean(cell2mat(CGPdata(1:end,1:end-1)))];
    allPooledChangesSEMs{i} = [nanstd(cell2mat(D30data(1:end,1:end-1)));nanstd(cell2mat(D10data(1:end,1:end-1)));nanstd(cell2mat(Bdata(1:end,1:end-1)));...
        nanstd(cell2mat(C10data(1:end,1:end-1)));nanstd(cell2mat(C30data(1:end,1:end-1)));nanstd(cell2mat(CGPdata(1:end,1:end-1)))];
    drugs = {'D30','D10','B','C10','C30','CGP'};
    allPooledChangesMeans{i} = [titles;[num2cell(allPooledChangesMeans{i}),drugs']];
    allPooledChangesSEMs{i} = [titles;[num2cell(allPooledChangesSEMs{i}),drugs']];
end


saveFolder = uigetdir(pwd,'Select the folder to save files in');
cd(saveFolder);

name = 'allPooledData.xls';

save('allPooledData.mat','allPooledData','allPooledChanges');
xlswrite(name, allPooledData{1}, 'T1Data', 'A1');
xlswrite(name, allPooledData{2}, 'T2Data', 'A1');
xlswrite(name, allPooledData{3}, 'T3Data', 'A1');
xlswrite(name, allPooledData{4}, 'T4Data', 'A1');
xlswrite(name, allPooledChanges{1}, 'T1Changes', 'A1');
xlswrite(name, allPooledChanges{2}, 'T2Changes', 'A1');
xlswrite(name, allPooledChanges{3}, 'T3Changes', 'A1');
xlswrite(name, allPooledMeans{1}, 'T1Means', 'A1');
xlswrite(name, allPooledMeans{2}, 'T2Means', 'A1');
xlswrite(name, allPooledMeans{3}, 'T3Means', 'A1');
xlswrite(name, allPooledMeans{4}, 'T4Means', 'A1');
xlswrite(name, allPooledChangesMeans{1}, 'T1ChangesMeans', 'A1');
xlswrite(name, allPooledChangesMeans{2}, 'T2ChangesMeans', 'A1');
xlswrite(name, allPooledChangesMeans{3}, 'T3ChangesMeans', 'A1');
xlswrite(name, params, 'ChangesInParams', 'A1');