%make pooled data files
%wells that have zeros for all timepoints are deleted
%absolute values as well as percentage changes are saved

folder = uigetdir('Select folder with all the individual parameter files'); %give the root folder where all the concentrations are stored
cd(folder);
folder = pwd;

fileList = dir('*param*.xls'); %%DO NOT NAME ANY OTHER POOLED STUFF params IN THIS FOLDER

%Pool data
titles = [];
  
    absVals = [];
    changesVals  =  [];
    absMeans = [];
    absSEMs = [];
    changesMeans = [];
    changesSEMs = [];

for j=1:length(fileList)
  
    dataParams = [];    
    

    disp(fileList(j).name);
    [~, ~, dataParams] = xlsread(fileList(j).name,'Sheet1');
dataParams(cellfun(@(x) ~isempty(x) && isnumeric(x) && isnan(x),dataParams)) = {''};

if j==1
    titles = dataParams(1,:);
    absVals = [titles,'Drug'];
    changesVals = [titles,'Drug'];
    absMeans = [titles(1:end-1),'Drug'];
    absSEMs = [titles(1:end-1),'Drug'];
    changesMeans = [titles(1:end-1),'Drug'];
    changesSEMs = [titles(1:end-1),'Drug'];
end
    
    if ~isempty(dataParams)
        
        [pooledData,pooledChanges,pooledAbsCell,pooledChangesCell,pooledDataMeans,pooledDataSEMs,pooledChangesMeans,pooledChangesSEMs,times] = getPooledTimePointsMultiwell(dataParams);

    end
    
    absVals = [absVals;[pooledAbsCell,repmat({fileList(j).name},size(pooledAbsCell,1),1)]];
    changesVals = [changesVals;[pooledChangesCell,repmat({fileList(j).name},size(pooledChangesCell,1),1)]];
    
   absMeans = [absMeans;[num2cell(pooledDataMeans),times,repmat({fileList(j).name},size(pooledDataMeans,1),1)]];
   absSEMs = [absSEMs;[num2cell(pooledDataSEMs),times,repmat({fileList(j).name},size(pooledDataSEMs,1),1)]];
    changesMeans = [changesMeans;[num2cell(pooledChangesMeans),times(2:end),repmat({fileList(j).name},size(pooledChangesMeans,1),1)]];
    changesSEMs = [changesSEMs;[num2cell(pooledChangesSEMs),times(2:end),repmat({fileList(j).name},size(pooledChangesSEMs,1),1)]];
end

 saveName = strcat('all_Pooled.mat');
    save(saveName,'absVals','changesVals','absMeans','absSEMs','changesMeans','changesSEMs');
    saveExcelName = strcat('all_Pooled.xls');
    xlswrite(saveExcelName, absVals, 'Sheet1', 'A1');
    xlswrite(saveExcelName,changesVals, 'Sheet2', 'A1');
   xlswrite(saveExcelName, absMeans, 'absMeans', 'A1');
    xlswrite(saveExcelName,absSEMs, 'absSEMs', 'A1');
    xlswrite(saveExcelName, changesMeans, 'changesMeans', 'A1');
    xlswrite(saveExcelName,changesSEMs, 'changesSEMs', 'A1');