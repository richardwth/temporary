function [sampleWiseData,sampleNames] = getSampleWiseData(dataParams)
%returns the time wise data for each samples as one cell in a cell array



times = cell2mat(dataParams(2:end,end));
times = str2num(times);
noOfTimePts = length(unique(times));

sampleNames = unique(dataParams(2:end,end-1));

sampleWiseData = cell(length(sampleNames),1);

for i=1:length(sampleNames) 
        sampleVals = cell2mat(dataParams(1+(i-1)*noOfTimePts+1:1+i*noOfTimePts,1:end-2));
        sampleWiseData{i} = sampleVals;
end
