%make pooled data files 
%wells that have zeros for all timepoints are deleted
%absolute values as well as percentage changes are saved

folder = uigetdir('Select folder with all the individual parameter files'); %give the root folder where all the concentrations are stored
cd(folder);
folder = pwd;

fileList = dir('*param*.mat'); %%DO NOT NAME ANY OTHER POOLED STUFF params IN THIS FOLDER

%Pool data
titles = [];

for j=1:length(fileList)
    
    temp = [];
    dataParams = [];
   
        
        load(fileList(j).name);
        disp(fileList(j).name);
        inds = [1:size(dataParams,2)-2,size(dataParams,2)-1:size(dataParams,2)];
        temp = [temp;dataParams(2:end,inds)];
        titles = dataParams(1,inds);
   
    
    dataParams = [titles;temp];
    saveName = strcat('allParams_Pooled_',names{k},'.mat');
    save(saveName,'dataParams');
    saveExcelName = strcat('allParams_Pooled_',names{k},'.xls');
    xlswrite(saveExcelName, dataParams, 'Sheet1', 'A1');
    
    cd ..
end

