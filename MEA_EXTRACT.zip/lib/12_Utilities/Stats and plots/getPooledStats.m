function [means,SEMs] = getPooledStats(dataParams)
%returns means and SEMs as separate matrices with rows being percentage
%changes corresponding to difference time points and columns being
%parameters



times = cell2mat(dataParams(2:end,end));
times = str2num(times);
noOfTimePts = length(unique(times));


means = [];
SEMs = [];

for i=1:noOfTimePts  
        timeInds = find(times==i);
        timeVals = cell2mat(dataParams(1+timeInds,1:end-2));
 
     
        means = [means;nanmean(timeVals)];
        nonNanSizeSQRT = zeros(1,size(dataParams,2)-2);
        for j=1:length(nonNanSizeSQRT)
            nonNanSizeSQRT(j) = sqrt(length(~isnan(timeVals(:,j))));
        end
        SEMs = [SEMs;nanstd(timeVals)./nonNanSizeSQRT]; 
end

means(isinf(means)) = NaN;
SEMS(isinf(SEMs)) = NaN; %ind cuased by inactivity at one time point/ have to remove or else bar charts have very high ylimits
