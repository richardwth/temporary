%Saving data for Radar plot
folder = uigetdir('Select folder'); %give the root folder where all the concentrations are stored
cd(folder);
folder = pwd;

%Get DMSO params
list = dir('*DMSO*');
cd(list(1).name);
list = dir('*Pooled*');
load(list(1).name);

[DMSOMeans,DMSOSEMs] = getPooledStatsForChanges(dataParams);
[DPooledData,DPooledChanges] = getPooledTimePoints(dataParams);

%Get Baclofen 1uM params
cd(folder);
list = dir('*CGP 1uM*');
cd(list(1).name);
list = dir('*Pooled*');
load(list(1).name);

[CGPMeans,CGPSEMs] = getPooledStatsForChanges(dataParams);
[CGPPooledData,CGPPooledChanges] = getPooledTimePoints(dataParams);

%Get Baclofen 1uM params
cd(folder);
list = dir('*Baclofen 1uM*');
cd(list(1).name);
list = dir('*Pooled*');
load(list(1).name);

[BaclofenMeans,BaclofenSEMs] = getPooledStatsForChanges(dataParams);
[BPooledData,BPooledChanges] = getPooledTimePoints(dataParams);


%Get Conolidine 10uM params
cd(folder);
list = dir('*Conolidine 10uM*');
cd(list(1).name);
list = dir('*Pooled*');
load(list(1).name);

[C10Means,C10SEMs] = getPooledStatsForChanges(dataParams);
C10Means = C10Means(4:end,1:35);
C10SEMs = C10SEMs(4:end,1:35);
[C10PooledData,C10PooledChanges] = getPooledTimePoints(dataParams);

%Get Conolidine 30uM params
cd(folder);
list = dir('*Conolidine 30uM*');
cd(list(1).name);
list = dir('*Pooled*');
load(list(1).name);

[C30Means,C30SEMs] = getPooledStatsForChanges(dataParams);
[C30PooledData,C30PooledChanges] = getPooledTimePoints(dataParams);

%Convert to time arrays
T1Means = [DMSOMeans(1,:);C10Means(1,:);C30Means(1,:);BaclofenMeans(1,1:35);CGPMeans(4,1:35)];
T2Means = [DMSOMeans(2,:);C10Means(2,:);C30Means(2,:);BaclofenMeans(2,1:35);CGPMeans(5,1:35)];
T3Means = [DMSOMeans(3,:);C10Means(3,:);C30Means(3,:);BaclofenMeans(3,1:35);CGPMeans(6,1:35)];
%T4Means = [DMSOMeans(4,:);C10Means(4,:);C30Means(4,:),BaclofenMeans(4,1:35)];

T1SEMs= [DMSOSEMs(1,:);C10SEMs(1,:);C30SEMs(1,:);BaclofenSEMs(1,1:35);CGPSEMs(4,1:35)];
T2SEMs = [DMSOSEMs(2,:);C10SEMs(2,:);C30SEMs(2,:);BaclofenSEMs(2,1:35);CGPSEMs(5,1:35)];
T3SEMs = [DMSOSEMs(3,:);C10SEMs(3,:);C30SEMs(3,:);BaclofenSEMs(3,1:35);CGPSEMs(6,1:35)];
%T4SEMs = [DMSOSEMs(4,:);C10SEMs(4,:);C30SEMs(4,:),BaclofenSEMs(4,1:35)];

titles = dataParams(1,1:end-2);

% for i=1:titles
%     f = figure();
%     hold on
%     
%     errorbar(1:3,T1avg(:,i),T1std(:,i),'-o','color',[0,76/255,153/255]); %15min
%     errorbar(1:3,T2avg(:,i),T2std(:,i),'-o','color',[0,128/255,255/255]); %2hr
%     errorbar(1:3,T3avg(:,i),T3std(:,i),'-o','color',[153/255,205/255,255/255]); %24hr
%     
%      h = legend('15min','2h','24h');
%      set(h,'location','NorthEastOutside');
%      
%       patchline([0.5,3.5],[0,0], [], 'EdgeColor', [0,0,0],'LineWidth', 1, 'EdgeAlpha', 0.75 );
%      
%      patchline(1:3,T1avg(:,i), [], 'EdgeColor', [0,76/255,153/255],'LineWidth', 2, 'EdgeAlpha', 0.5 );
%     patchline(1:3,T2avg(:,i), [], 'EdgeColor', [0,128/255,255/255],'LineWidth', 2, 'EdgeAlpha', 0.5 );
%     patchline(1:3,T3avg(:,i), [], 'EdgeColor', [153/255,205/255,255/255],'LineWidth', 2, 'EdgeAlpha', 0.5 );
%     
%     
%     
%   %  grid on
%      
%     title(titles(i));
%     ylabel(titles(i));
%     set(gca,'XTick',1:4);
%     set(gca,'XTickLabel',{'Control','10uM','30uM'});
%     xlabel('Concentration (uM)');
%     fileName = strcat(titles{i},'_ConProfile.jpg');
%     %saveas(f,fileName);
%     
%     set(f,'PaperUnits','inches','PaperPosition',[0 0 4 2]);
% print('-djpeg', fileName, '-r100');
% 
%    %ylim([min(a(:,i)-b(:,i))-2,max(a(:,i)-b(:,i))+2]);
%     close(f);
% end

folder = uigetdir('Select folder to save the files in');
cd(folder);

D = DPooledChanges{1};
C10 = C10PooledChanges{1};
C30 = C30PooledChanges{1};
CGP = CGPPooledChanges{4};
B = BPooledChanges{1};

save('DMSO_Conol_Bac_CGP.mat','T1Means','T2Means','T3Means','T1SEMs','T2SEMs','T3SEMs','DMSOMeans','C10Means','C30Means','BaclofenMeans','CGPMeans','DMSOSEMs','C10SEMs','C30SEMs','BaclofenSEMs','CGPSEMs');
name = 'DMSO_Conol_Bac_CGP2.xls';
xlswrite(name, T1Means, 'T1Means', 'A1');
xlswrite(name, T2Means, 'T2Means', 'A1');
xlswrite(name, T3Means, 'T3Means', 'A1');
xlswrite(name, D, 'D', 'A1');
xlswrite(name, C10, 'C10', 'A1');
xlswrite(name, C30, 'C30', 'A1');
xlswrite(name, B, 'B', 'A1');
xlswrite(name, CGP, 'CGP', 'A1');


