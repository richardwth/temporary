function pdist = testPermClassify(x,y)

%X and Y are matrices with different number of observations but the same
%number of features describiing each observation

    iterations = 2;
    errors = testStat(x,y,iterations);    
    dist = ones(size(errors))-errors;
    pdist = nanmean(dist);

end

function errors = testStat(a,b,iterations)
   
    data = [a;b];
    noOfClasses = 2;
   % data = (data - repmat(min(data),size(data,1),1))./(repmat(max(data),size(data,1),1)-repmat(min(data),size(data,1),1));
     
    classes = [ones(size(a,1),1);2*ones(size(b,1),1)];
    m = length(classes);
    testRatio = 0.4;
    
    classMat = zeros(m,noOfClasses);
        
        for k=1:noOfClasses
            classMat(classes==k,k)=1;
        end
        
        errors = zeros(iterations,1);
        
        for i=1:iterations
    testInds = randsample(m,floor(m*testRatio));
    testSet = data(testInds,:);
    testSetClasses = classMat(testInds,:);
    trainingSet = data;
    trainingSetClasses = classMat;
    trainingSet(testInds,:) = [];
    trainingSetClasses(testInds,:) = []; 

        net = patternnet(round((size(data,2)+noOfClasses)/2));
        net.trainParam.showWindow = false;
        net.trainParam.showCommandLine = false; 
    
    
        net.divideParam.trainRatio = 1;
        net.divideParam.valRatio = 0;
        net.divideParam.testRatio = 0;
        
        [net,~] = train(net,trainingSet',trainingSetClasses');
        
        testY = net(testSet');
        
        [c,~] = confusion(testSetClasses',testY);
        errors(i) = c;
        

%         net = feedforwardnet(20);
%         net = train(net,trainingSet',trainingSetClasses');
%         y = net(testSet');
%         y = vec2ind(y);
%         yMat = zeros(length(y),noOfClasses);
%         
%         for k=1:noOfClasses
%             yMat(y==k,k)=1;
%         end
%         [c2,~] = confusion(testSetClasses',yMat');    
        end

end