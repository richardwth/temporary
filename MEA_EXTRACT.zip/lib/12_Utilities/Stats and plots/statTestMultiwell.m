%%Find statistically differnt parameters for multiwell

%load data params
[fileName,path] = uigetfile('*.xls','Select parameter file');

saveFolder = uigetdir(pwd,'Select folder to save files in');

cd(path);
[~, ~, dataParams] = xlsread(fileName,'Sheet1');
dataParams(cellfun(@(x) ~isempty(x) && isnumeric(x) && isnan(x),dataParams)) = {''};

data = cell2mat(dataParams(2:end,1:end-2));


names = dataParams(2:end,end-1);
timePts = unique(names);

pMat = zeros(length(timePts)-1,size(data,2));
hMat = zeros(length(timePts)-1,size(data,2));
testType =  cell(length(timePts)-1,size(data,2));
means = zeros(length(timePts),size(data,2));
SEMs = zeros(length(timePts),size(data,2));

baselineInds = find(ismember(names,timePts{1}));

%for each time point except for baseline
for i=2:length(timePts)
    inds = find(ismember(names,timePts{i}));
    for j=1:size(data,2)
        values = data(inds,j);
        baselineVals = data(baselineInds,j);
        
        nzValues = values(values~=0 & baselineVals~=0);
        
        baselineVals = baselineVals(values~=0 & baselineVals~=0);
        values = nzValues;
        
        %for each time point except for the baseline, test for significant
        %differneces in each parameter between that and baseline
        %         try
        
        if ~kstest(values) && ~kstest(baselineVals)
            [hLeft,pLeft] = ttest(values,baselineVals,'tail','left');
            [hRight,pRight] = ttest(values,baselineVals,'tail','right');
            testType{i-1,j} = 't-test';
        else
            [pLeft,hLeft] = signrank(values,baselineVals,'tail','left');
            [pRight,hRight] = signrank(values,baselineVals,'tail','right');
            testType{i-1,j} = 'Sign-rank';
        end
        %         catch
        %             [pLeft,hLeft] = ranksum(values,baselineVals,'tail','left');
        %             [pRight,hRight] = ranksum(values,baselineVals,'tail','right');
        %         end
        pMat(i-1,j) = min(pLeft,pRight);
        hMat(i-1,j) = max(hLeft,hRight);
        
        means(1,j) = mean(baselineVals);
        SEMs(1,j) = std(baselineVals)/real(sqrt(length(baselineVals)));
        means(i,j) = mean(values);
        SEMs(i,j) = std(values)/real(sqrt(length(values)));
        
        f = figure('Position', [100, 100, 420, 420]);
        hold on
        for k=1:length(baselineVals)
            plot([1,2],[baselineVals(k),values(k)],'.-k','markersize',20,'linewidth',1.5);
        end
        
        ylabel(dataParams{1,j});
        set(gca,'XTick',[1,2]);
        set(gca,'XTickLabel',{'Baseline',timePts{i}},'FontSize', 10);
        xlim([0,3]);
        ylims = get(gca,'ylim');
        [~,nStarStr] = getStarRating(pMat(i-1,j));
        height = max(values)+(ylims(2)-max(values))/2;
        m = text(1.5,height,nStarStr,'fontsize',20);
        
        
        
        cd(saveFolder);
        %saveas(f,strcat(dataParams{1,j},'.jpg'));
        fileName = strcat(dataParams{1,j},'_',timePts{i},'.jpg');
        set(gcf,'PaperUnits','inches','PaperPosition',[0 0 4.5 4.5]);
        print('-djpeg',fileName,'-r100');
        close(f);
    end
end
% 
% cd(saveFolder);
% save('statsHET.mat','pMat','hMat');
% xlswrite('stats.xls', pMat, 'Sheet1', 'A1');
% xlswrite('stats.xls', hMat, 'Sheet2', 'A1');
% xlswrite('stats.xls', testType, 'Sheet3', 'A1');
% 
% 
% for i=1:length(timePts)
%     timePtName = timePts{i};
%     inds = strfind(timePtName,'_');
%     try
%         timePtName = timePtName(inds(2)+1:end);
%     end
%     timePts{i} = strrep(timePtName,'_','');
% end
% 
% for j=1:size(data,2)
%     f = figure('Position', [100, 100, 820, 420]);
%     h = barwitherr(SEMs(1:end,j), means(1:end,j));
%     set(gca,'XTickLabel',timePts);
%     ylabel(dataParams{1,j});
%     set(gca,'XTickLabel',{'Base','0m','5m','10m','15m','20m'},'FontSize', 10);
%     hold on
%     for i=1:size(hMat,1)
%         [~,nStarStr] = getStarRating(pMat(i,j));
%         height = means(i+1,j)+SEMs(i+1,j)+max(SEMs(:,j))/5;
%         text(i+1,height,nStarStr);
%     end
%     %saveas(f,strcat(dataParams{1,j},'.jpg'));
%     fileName = strcat(dataParams{1,j},'.jpg');
%     set(gcf,'PaperUnits','inches','PaperPosition',[0 0 4.5 2.5]);
%     print('-djpeg',fileName,'-r100');
%     close(f);
% end

