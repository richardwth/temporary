

[fileName,path] = uigetfile('*.xls','Select parameter file');
cd(path);

[~, ~, data] = xlsread(fileName,'sheet1');
data(cellfun(@(x) ~isempty(x) && isnumeric(x) && isnan(x),data)) = {''};

mkdir('ParamTrends');
cd('ParamTrends');

titles = data(1,:);
classes = data(2:end,end-1);
data = cell2mat(data(2:end,1:end-2));

try
    classes = cell2mat(classes);
end
uniqueClasses = unique(classes);


for i=1:size(data,2)
    f = figure;
    hold on
    timeValsMeans = zeros(1,length(uniqueClasses));
    timeValsSEMs = zeros(1,length(uniqueClasses));
    pVals = ones(1,length(uniqueClasses));
    for j=1:length(uniqueClasses)
     
     inds = find(ismember(classes,uniqueClasses(j)));
     
     values = data(inds,i);
     timeValsMeans(j) = nanmean(data(inds,i));  
     timeValsSEMs(j) = nanstd(data(inds,i))/real(sqrt(length(inds)));  
     
     if j>1
          baselineInds = find(ismember(classes,uniqueClasses(j-1)));
          baselineVals = data(baselineInds,i);
     if ~jbtest(values) && ~jbtest(baselineVals)
                [hLeft,pLeft] = ttest2(values,baselineVals,'tail','left');
                [hRight,pRight] = ttest2(values,baselineVals,'tail','right');
                testType{j-1,i} = 'ttest';
            else
                [pLeft,hLeft] = ranksum(values,baselineVals,'tail','left');
                [pRight,hRight] = ranksum(values,baselineVals,'tail','right');
                testType{j-1,i} = 'Ranksum';
     end
             pVals(j) = min(pLeft,pRight);
     end
    end
  
            
    errorbar(timeValsMeans,timeValsSEMs);
    set(gca,'XTick',1:length(uniqueClasses));
    
    temp = uniqueClasses;
%     for j=1:length(uniqueClasses)
%         temp{j} = strrep(uniqueClasses{j},'_','-');
%     end
    set(gca,'XTickLabel',temp);
    try
%     rotateXLabels(gca,45);
    end
    ylabel(titles{i});
    
      for j=2:length(pVals)
    [~,nStarStr] = getStarRating(pVals(j));
    height = getHeightForStars(gca,nStarStr,timeValsMeans,timeValsSEMs);
      text(j,height,nStarStr,'FontSize', 20);
      end
      
     fileName = strcat(titles{i},'.jpg');
    set(gcf,'PaperUnits','inches','PaperPosition',[0 0 6 2.5]);
    print('-djpeg',fileName,'-r100');
       saveas(f,strcat(dataParams{1,i},'.fig'));
    close(f);
end