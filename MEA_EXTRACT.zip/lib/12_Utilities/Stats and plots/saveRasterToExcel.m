% for plotting raster plots in graphPad
% only for MEA60. Time and fs is hardcoded

function saveRasterToExcel

chans = getMEA60Channels();
fs = 20000;
time = 180;

letters = ('A':'Z');
letterArray = cell(26*3,1);
for j=1:length(letters)
    letterArray{j} = letters(j);
end
for j=1:length(letters)
    letterArray{j+26} = strcat('A',letters(j));
end
for j=1:length(letters)
    letterArray{j+26*2} = strcat('B',letters(j));
end

upperRootFolder = uigetdir(pwd,'Select root folder');
cd(upperRootFolder);

rootFolderList = dir('*');

saveFolder = uigetdir(pwd,'Select folder to save files in');

for k=3:length(rootFolderList)
    cd(upperRootFolder);
    rootFolder = rootFolderList(k).name;
     cd(rootFolder);
%      list = dir('*');
%      cd(list(3).name);
%     
%     
    list = dir('*PeakDetectionMAT*');
    
    cd(list(1).name);
    
    list = dir('*ptrain*');
    
    cd(list(1).name);
    
    folderList = dir('*ptrain*.mat');
    peakFolder = pwd;
    

    
    for i=1:length(folderList)
        cd(peakFolder);
        fileName = folderList(i).name;
        load(fileName);
        
        [~,fileName,~] = fileparts(fileName);
        el = str2double(fileName(end-1:end));
        chan = find(chans==el);
        
        timestamps = find(peak_train);
        timestamps(timestamps>fs*time) = [];
        timestamps = unique(round(timestamps./1000));
        raster = zeros(1+fs*time/1000,1);
        timestamps(timestamps==0) = [];
        
        if ~isempty(timestamps)
            disp(i);
            raster(timestamps) = chan;
            
            cd(saveFolder);
            
            column = strcat(letterArray{chan},'1');
            
            name = strcat(rootFolder,'.xls');
            xlswrite(name,raster, 'Sheet1', column);
        end
    end
    
end

