% pcaDistrib
% data - rows: samples
% columns - features
% first row - feature names
% last row - class label

[fileName,path] = uigetfile('*.xls','Select parameter file');
cd(path);

saveFolder = uigetdir(pwd,'Select foler to save files in');

[~, ~, data] = xlsread(fileName,'sheet2');
data(cellfun(@(x) ~isempty(x) && isnumeric(x) && isnan(x),data)) = {''};

%data([52,70,799,826,844,862,880]+1,:) = [];


drugs = data(2:end,end-1);
inds = find(ismember(drugs,{'Memantine','Pregabalin'}));
dataTemp = data;
 dataTemp(1+inds,:) = [];
 drugs = data(2:end,end-1);
 
titles = data(1,:);
classes = data(2:end,end-1);
classesTemp = dataTemp(2:end,end-1);
data = cell2mat(data(2:end,1:end-4));
dataTemp = cell2mat(dataTemp(2:end,1:end-4));

try
    classes = cell2mat(classes);
    classesTemp = cell2mat(classesTemp);
end
uniqueClasses = unique(classes);


%normalize data
%data = (data - repmat(min(data),size(data,1),1))./(repmat(max(data),size(data,1),1)-repmat(min(data),size(data,1),1));
data = zscore(data);
dataTemp = zscore(dataTemp);



[coeff,score,latent,tsquared,explained,mu] = pca(data);

%  inds = [2,7,15,21,23,25,26,27,34];
%  data = data(:,inds);
 D = pdist(score);
 %score = mdscale(D,2);

% % Feature selection
% %----------------------------------------------------------------------------
% c = cvpartition(classesTemp,'kfold',10);
% opts = statset('display','iter');
% fun = @(XT,yT,Xt,yt)...
%       (sum(~strcmp(yt,classify(Xt,XT,yT,'diagquadratic'))));
% 
% [fs,history] = sequentialfs(fun,dataTemp,classesTemp,'cv',c,'options',opts);
% 
%  %K Means
%  %--------------------------------------------------------------------
%  X = data(:,:); 
% kN = 2;
% [idx,C] = kmeans(X,kN,'Display','final','Replicates',5);
% 
% f = figure;
% plot(X(idx==1,1),X(idx==1,2),'r.','MarkerSize',12)
% hold on
% plot(X(idx==2,1),X(idx==2,2),'b.','MarkerSize',12)
% plot(C(:,1),C(:,2),'kx',...
%      'MarkerSize',15,'LineWidth',3)
% legend('Cluster 1','Cluster 2','Centroids','Location','NW')
% title 'Cluster Assignments and Centroids'
% 
% clus1Drugs = drugs(idx==1);
% clus2Drugs = drugs(idx==2);
% clus1 = classes(idx==1);
% clus2 = classes(idx==2);
% accuracy = zeros(length(uniqueClasses),kN);
% for j=1:kN
%     for i= 1:length(uniqueClasses)
%         accuracy(i,j) = length(find(idx==j & classes==i))/length(find(classes==i));
%     end
% end
% 
% 
% 
% close(f);
%-----------------------------------------------------------------------
% score([37,51,201],:) = [];
% classes([37,51,201],:) = [];

score = data;

x = 1;
y = 2;
z = 3;


meansScore = zeros(length(uniqueClasses),size(score,2));
means = zeros(length(uniqueClasses),size(data,2));

% for x=1:size(score,2)
%     f = figure();
% hold on
% colors = [];
% 
% for i=1:length(uniqueClasses)
%     
%     inds = find(ismember(classes,uniqueClasses(i)));
%    
%     
%     colormap jet;        
%     cm = colormap;
%     val = floor(i*size(cm,1)/length(uniqueClasses));
%     if val<=0
%         val =1;
%     end
% 
%    plot(i*ones(length(inds),1),score(inds,x),'*','color',cm(val,:)); %take x,y values to save to some other place if required.
% 
%     colors = [colors;cm(val,:)];
% 
%     meansScore(i,:) = nanmean(score(inds,:));
%     means(i,:) = nanmean(data(inds,:));
% end
%  %   legend({'Anticonvulsants','Analgesics','Both'},'location','bestoutside');
% %legend(uniqueClasses,'location','bestoutside');
% 
% set(gca,'XTick',[1:length(uniqueClasses)]);
% set(gca,'XTickLabel',uniqueClasses);
% try
% rotateXLabels(gca(),90);
% end
% grid on
% line([0,length(uniqueClasses)+1],[0,0],'color','black','linewidth',2);
% title(titles(x));
% 
% cd(saveFolder);
% fileName = strcat(titles{x},'.jpg');
%  saveas(f,fileName);
%     saveas(f,strcat(titles{x},'.fig'));
% close(f);
% end


for x = 1:size(score,2)
    f = figure();
     boxplot(score(:,x),drugs);
     
      try
rotateXLabels(gca(),90);
end
grid on
line([0,length(uniqueClasses)+1],[0,0],'color','black','linewidth',1);
title(titles(x));


     cd(saveFolder);
fileName = strcat('Box_',titles{x},'.jpg');
 saveas(f,fileName);
    saveas(f,strcat('Box_',titles{x},'.fig'));
     close(f);
end

for i=1:length(uniqueClasses)
    
    inds = find(ismember(classes,uniqueClasses(i)));
    GMModel = fitgmdist(score(inds,[1,2]),1);
    
error_ellipse('mu',mean([score(inds,1),score(inds,2)]),'C',cov(score(inds,1),score(inds,2)),'conf',0.95,'style','-k');
end

Y = linkage(pdist(meansScore));
dendrogram(Y,size(meansScore,1));
ind = str2num(get(gca,'XTickLabel'));
set(gca,'XTickLabel',uniqueClasses(ind));


meanScoreDist = squareform(pdist(meansScore));
meanDist = squareform(pdist(means));
meanScoreDist = [[{''},uniqueClasses'];[uniqueClasses,num2cell(meanScoreDist)]];