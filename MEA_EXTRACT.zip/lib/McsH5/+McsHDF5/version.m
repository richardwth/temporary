function version()

    fprintf(['This is version 0.3.0 of the McsHDF5 Matlab toolbox. (23/04/2015)\n'...
        'Newer versions will be available at \n\n'...
        '\thttp://www.multichannelsystems.com/software/multi-channel-datamanager \n']);

end