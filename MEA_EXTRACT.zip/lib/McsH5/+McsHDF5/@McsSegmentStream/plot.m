function plot(segStream, cfg, varargin)
% This is just a placeholder function please see
%
%   help McsHDF5.McsAverageSegment.plot
%
% for plotting of the contents of a segment stream with averages and
%
%   help McsHDF5.McsCutoutSegment.plot
%
% for plotting of the contents of a segment stream with spike cutouts.

end