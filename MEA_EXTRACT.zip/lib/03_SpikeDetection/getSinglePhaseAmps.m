function getSinglePhaseAmps()

%% Get the upper root folder
upperRootFolder = uigetdir(pwd,'Select the root folder');
cd(upperRootFolder);

folderList = dir('*');


%% Iterate for all folders in the upper r0ot folder
for x = 3:length(folderList)
    
    cd(upperRootFolder);
    
    %% Go into a folder for 1 sample
    rootFolder = folderList(x).name;
    disp(sprintf('Analyzing...%s',rootFolder));
    
    % try
    cd(rootFolder);
    rootFolderPath = pwd;
    
    wellList = dir('*Well*');
    
    for j=1:length(wellList);
        
        cd(rootFolderPath);
        
        cd(wellList(j).name);
        peakFolder = dir('*PeakDetectionMAT*');
        peakFolder = fullfile(pwd,peakFolder(1).name);
        
        matFolder = dir('*MatFiles*');
        matFolder = fullfile(pwd,matFolder(1).name);
        
        cd(peakFolder);
        peakFiles = dir('*ptrain*');
        
        for k=1:length(peakFiles)
            cd(peakFolder);
            load(peakFiles(k).name);
            [~,peakFileName,ext] = fileparts(peakFiles(k).name);
            el = peakFileName(end-1:end);
            
            cd(matFolder);
            matFile = dir(el);
            load(matFile(1).name);
            amps = zeros(size(data));
            amps(find(peak_train)) = data(find(peak_train));
            amp_train = sparse(amps);
            cd(peakFolder);
            save(peakFiles(k).name,'peak_train','amp_train');
        end
        
        
    end
end