function [noOfSpikingChans,mfrMat,heightMat,ampMat,depAmpMat,hypAmpMat,spikeDurMat,depDurMat,hypDurMat] = simpleSpikeParamsNew(path,channels)

%%load the netBUrsts file
cd(path);



list = dir('*PeakDetectionMAT*');
peakFolder = list(1).name;
cd(peakFolder);
list = dir('*ptrain*');

try
    cd(list(1).name);
end

list = dir('*ptrain*.mat');

mfrs = zeros(length(channels),1);
mfrs(:) = NaN;

noOfSpikingChans = 0;

avgHeight = zeros(length(channels),1); % This was avgAmp before
stdHeight = zeros(length(channels),1);
cvHeight =  zeros(length(channels),1);
rangeHeight = zeros(length(channels),1);
skewHeight = zeros(length(channels),1);
kurtHeight = zeros(length(channels),1);
avgHeight(:) = NaN;
stdHeight(:) = NaN;
cvHeight(:) = NaN;
rangeHeight(:) = NaN;
skewHeight(:) = NaN;
kurtHeight(:) = NaN;

avgAmp = zeros(length(channels),1);
stdAmp = zeros(length(channels),1);
cvAmp =  zeros(length(channels),1);
rangeAmp = zeros(length(channels),1);
skewAmp = zeros(length(channels),1);
kurtAmp = zeros(length(channels),1);
avgAmp(:) = NaN;
stdAmp(:) = NaN;
cvAmp(:) = NaN;
rangeAmp(:) = NaN;
skewAmp(:) = NaN;
kurtAmp(:) = NaN;

avgDepAmp = zeros(length(channels),1);
stdDepAmp = zeros(length(channels),1);
cvDepAmp =  zeros(length(channels),1);
rangeDepAmp = zeros(length(channels),1);
skewDepAmp = zeros(length(channels),1);
kurtDepAmp = zeros(length(channels),1);
avgDepAmp(:) = NaN;
stdDepAmp(:) = NaN;
cvDepAmp(:) = NaN;
rangeDepAmp(:) = NaN;
skewDepAmp(:) = NaN;
kurtDepAmp(:) = NaN;

avgHypAmp = zeros(length(channels),1);
stdHypAmp = zeros(length(channels),1);
cvHypAmp =  zeros(length(channels),1);
rangeHypAmp = zeros(length(channels),1);
skewHypAmp = zeros(length(channels),1);
kurtHypAmp = zeros(length(channels),1);
avgHypAmp(:) = NaN;
stdHypAmp(:) = NaN;
cvHypAmp(:) = NaN;
rangeHypAmp(:) = NaN;
skewHypAmp(:) = NaN;
kurtHypAmp(:) = NaN;

avgSpikeDur = zeros(length(channels),1);
stdSpikeDur = zeros(length(channels),1);
cvSpikeDur =  zeros(length(channels),1);
rangeSpikeDur = zeros(length(channels),1);
skewSpikeDur = zeros(length(channels),1);
kurtSpikeDur = zeros(length(channels),1);
avgSpikeDur(:) = NaN;
stdSpikeDur(:) = NaN;
cvSpikeDur(:) = NaN;
rangeSpikeDur(:) = NaN;
skewSpikeDur(:) = NaN;
kurtSpikeDur(:) = NaN;

avgDepDur = zeros(length(channels),1);
stdDepDur = zeros(length(channels),1);
cvDepDur =  zeros(length(channels),1);
rangeDepDur = zeros(length(channels),1);
skewDepDur = zeros(length(channels),1);
kurtDepDur = zeros(length(channels),1);
avgDepDur(:) = NaN;
stdDepDur(:) = NaN;
cvDepDur(:) = NaN;
rangeDepDur(:) = NaN;
skewDepDur(:) = NaN;
kurtDepDur(:) = NaN;

avgHypDur = zeros(length(channels),1);
stdHypDur = zeros(length(channels),1);
cvHypDur =  zeros(length(channels),1);
rangeHypDur = zeros(length(channels),1);
skewHypDur = zeros(length(channels),1);
kurtHypDur = zeros(length(channels),1);
avgHypDur(:) = NaN;
stdHypDur(:) = NaN;
cvHypDur(:) = NaN;
rangeHypDur(:) = NaN;
skewHypDur(:) = NaN;
kurtHypDur(:) = NaN;

for i=1:length(list)
    load(list(i).name);
    [~,onlyName,~] = fileparts(list(i).name);
    
    el = str2double(onlyName(end-1:end));
    elNum = channels==el;
    
    
    timestamps = find(peak_train);
    isis = diff(timestamps);
    
    if ~isempty(timestamps)
        noOfSpikingChans = noOfSpikingChans+1;
        
        avgHeight(i) = nanmean(abs(peak_train(timestamps)));
        stdHeight(i) = nanstd(abs(peak_train(timestamps)));
        cvHeight(i) =  stdHeight(i)/avgHeight(i);
        rangeHeight(i) = range(abs(peak_train(timestamps)));
        skewHeight(i) = skewness(abs(peak_train(timestamps)));
        kurtHeight(i) = kurtosis(abs(peak_train(timestamps)));
        
        avgAmp(i) =nanmean(abs(amp_train(timestamps)));
        stdAmp(i) = nanstd(abs(amp_train(timestamps)));
        cvAmp(i) =  stdAmp(i)/avgAmp(i);
        rangeAmp(i) = range(abs(amp_train(timestamps)));
        skewAmp(i) = skewness(abs(amp_train(timestamps)));
        kurtAmp(i) = kurtosis(abs(amp_train(timestamps)));
        
        avgDepAmp(i) =nanmean(abs(depAmps));
        stdDepAmp(i) = nanstd(abs(depAmps));
        cvDepAmp(i) =  stdDepAmp(i)/avgDepAmp(i);
        rangeDepAmp(i) = range(abs(depAmps));
        skewDepAmp(i) = skewness(abs(depAmps));
        kurtDepAmp(i) = kurtosis(abs(depAmps));
        
        avgHypAmp(i) =nanmean(abs(hypAmps));
        stdHypAmp(i) = nanstd(abs(hypAmps));
        cvHypAmp(i) =  stdHypAmp(i)/avgHypAmp(i);
        rangeHypAmp(i) = range(abs(hypAmps));
        skewHypAmp(i) = skewness(abs(hypAmps));
        kurtHypAmp(i) = kurtosis(abs(hypAmps));
        
        avgSpikeDur(i) =nanmean(spikeDurs);
        stdSpikeDur(i) = nanstd(spikeDurs);
        cvSpikeDur(i) =  stdSpikeDur(i)/avgSpikeDur(i);
        rangeSpikeDur(i) = range(spikeeDurs);
        skewSpikeDur(i) = skewness(spikeDurs);
        kurtSpikeDur(i) = kurtosis(spikeDurs);
        
        avgDepDur(i) =nanmean(depDurs);
        stdDepDur(i) = nanstd(depDurs);
        cvDepDur(i) =  stdDepDur(i)/avgDepDur(i);
        rangeDepDur(i) = range(depDurs);
        skewDepDur(i) = skewness(depDurs);
        kurtDepDur(i) = kurtosis(depDurs);
        
        avgHypDur(i) =nanmean(hypDurs);
        stdHypDur(i) = nanstd(hypDurs);
        cvHypDur(i) =  stdHypDur(i)/avgHypDur(i);
        rangeHypDur(i) = range(hypDurs);
        skewHypDur(i) = skewness(hypDurs);
        kurtHypDur(i) = kurtosis(hypDurs);
    end
    
    mfrs(elNum) = length(timestamps)/length(peak_train);
    
end

%MFR-----------------------------------------
mfrs(isinf(mfrs)) = NaN;
mfrs(isnan(mfrs)) = [];
meanMfrAll = nanmean(mfrs);
stdMfrAll = nanstd(mfrs);
cvMfrAll = stdMfrAll/meanMfrAll;
rangeMfrAll = range(mfrs);
skewMfrAll = skewness(mfrs,0);
kurtMfrAll = kurtosis(mfrs,0);

mfrMat = [meanMfrAll,stdMfrAll,cvMfrAll,rangeMfrAll,skewMfrAll,kurtMfrAll];

%HEIGHT ------------------------------------
avgHeight(isnan(avgHeight)) = [];
meanAvgHeight = nanmean(avgHeight);
stdAvgHeight = nanstd(avgHeight);
cvAvgHeight = stdAvgHeight/meanAvgHeight;
rangeAvgHeight = range(avgHeight);
skewAvgHeight = skewness(avgHeight,0);
kurtAvgHeight = kurtosis(avgHeight,0);

meanStdHeight =  nanmean(stdHeight);
meanCvHeight =  nanmean(cvHeight);
meanRangeHeight =  nanmean(rangeHeight);
meanSkewHeight =  nanmean(skewHeight);
meanKurtHeight =  nanmean(kurtHeight);

heightMat = [meanAvgHeight,stdAvgHeight,cvAvgHeight,rangeAvgHeight,skewAvgHeight,kurtAvgHeight,meanStdHeight,meanCvHeight,meanRangeHeight,meanSkewHeight,meanKurtHeight];

%AMP-----------------------------------------
avgAmp(isnan(avgAmp)) = [];
meanAvgAmp = nanmean(avgAmp);
stdAvgAmp = nanstd(avgAmp);
cvAvgAmp = stdAvgAmp/meanAvgAmp;
rangeAvgAmp = range(avgAmp);
skewAvgAmp = skewness(avgAmp,0);
kurtAvgAmp = kurtosis(avgAmp,0);

meanStdAmp =  nanmean(stdAmp);
meanCvAmp =  nanmean(cvAmp);
meanRangeAmp =  nanmean(rangeAmp);
meanSkewAmp =  nanmean(skewAmp);
meanKurtAmp =  nanmean(kurtAmp);

ampMat = [meanAvgAmp,stdAvgAmp,cvAvgAmp,rangeAvgAmp,skewAvgAmp,kurtAvgAmp,meanStdAmp,meanCvAmp,meanRangeAmp,meanSkewAmp,meanKurtAmp];

%DEP AMP---------------------------------------
avgDepAmp(isnan(avgDepAmp)) = [];
meanAvgDepAmp = nanmean(avgDepAmp);
stdAvgDepAmp = nanstd(avgDepAmp);
cvAvgDepAmp = stdAvgDepAmp/meanAvgDepAmp;
rangeAvgDepAmp = range(avgDepAmp);
skewAvgDepAmp = skewness(avgDepAmp,0);
kurtAvgDepAmp = kurtosis(avgDepAmp,0);

meanStdDepAmp =  nanmean(stdDepAmp);
meanCvDepAmp =  nanmean(cvDepAmp);
meanRangeDepAmp =  nanmean(rangeDepAmp);
meanSkewDepAmp =  nanmean(skewDepAmp);
meanKurtDepAmp =  nanmean(kurtDepAmp);

depAmpMat = [meanAvgDepAmp,stdAvgDepAmp,cvAvgDepAmp,rangeAvgDepAmp,skewAvgDepAmp,kurtAvgDepAmp,meanStdDepAmp,meanCvDepAmp,meanRangeDepAmp,meanSkewDepAmp,meanKurtDepAmp];

%HYP AMP-------------------------------------------
avgHypAmp(isnan(avgHypAmp)) = [];
meanAvgHypAmp = nanmean(avgHypAmp);
stdAvgHypAmp = nanstd(avgHypAmp);
cvAvgHypAmp = stdAvgHypAmp/meanAvgHypAmp;
rangeAvgHypAmp = range(avgHypAmp);
skewAvgHypAmp = skewness(avgHypAmp,0);
kurtAvgHypAmp = kurtosis(avgHypAmp,0);

meanStdHypAmp =  nanmean(stdHypAmp);
meanCvHypAmp =  nanmean(cvHypAmp);
meanRangeHypAmp =  nanmean(rangeHypAmp);
meanSkewHypAmp =  nanmean(skewHypAmp);
meanKurtHypAmp =  nanmean(kurtHypAmp);

hypAmpMat = [meanAvgHypAmp,stdAvgHypAmp,cvAvgHypAmp,rangeAvgHypAmp,skewAvgHypAmp,kurtAvgHypAmp,meanStdHypAmp,meanCvHypAmp,meanRangeHypAmp,meanSkewHypAmp,meanKurtHypAmp];

%DURATION-----------------------------------------
avgSpikeDur(isnan(avgSpikeDur)) = [];
meanAvgSpikeDur = nanmean(avgSpikeDur);
stdAvgSpikeDur = nanstd(avgSpikeDur);
cvAvgSpikeDur = stdAvgSpikeDur/meanAvgSpikeDur;
rangeAvgSpikeDur = range(avgSpikeDur);
skewAvgSpikeDur = skewness(avgSpikeDur,0);
kurtAvgSpikeDur = kurtosis(avgSpikeDur,0);

meanStdSpikeDur =  nanmean(stdSpikeDur);
meanCvSpikeDur =  nanmean(cvSpikeDur);
meanRangeSpikeDur =  nanmean(rangeSpikeDur);
meanSkewSpikeDur =  nanmean(skewSpikeDur);
meanKurtSpikeDur =  nanmean(kurtSpikeDur);

spikeDurMat = [meanAvgSpikeDur,stdAvgSpikeDur,cvAvgSpikeDur,rangeAvgSpikeDur,skewAvgSpikeDur,kurtAvgSpikeDur,meanStdSpikeDur,meanCvSpikeDur,meanRangeSpikeDur,meanSkewSpikeDur,meanKurtSpikeDur];

%DEP DURATION-----------------------------------------
avgDepDur(isnan(avgDepDur)) = [];
meanAvgDepDur = nanmean(avgDepDur);
stdAvgDepDur = nanstd(avgDepDur);
cvAvgDepDur = stdAvgDepDur/meanAvgDepDur;
rangeAvgDepDur = range(avgDepDur);
skewAvgDepDur = skewness(avgDepDur,0);
kurtAvgDepDur = kurtosis(avgDepDur,0);

meanStdDepDur =  nanmean(stdDepDur);
meanCvDepDur =  nanmean(cvDepDur);
meanRangeDepDur =  nanmean(rangeDepDur);
meanSkewDepDur =  nanmean(skewDepDur);
meanKurtDepDur =  nanmean(kurtDepDur);

depDurMat = [meanAvgDepDur,stdAvgDepDur,cvAvgDepDur,rangeAvgDepDur,skewAvgDepDur,kurtAvgDepDur,meanStdDepDur,meanCvDepDur,meanRangeDepDur,meanSkewDepDur,meanKurtDepDur];

%HYP DURATION-----------------------------------------
avgHypDur(isnan(avgHypDur)) = [];
meanAvgHypDur = nanmean(avgHypDur);
stdAvgHypDur = nanstd(avgHypDur);
cvAvgHypDur = stdAvgHypDur/meanAvgHypDur;
rangeAvgHypDur = range(avgHypDur);
skewAvgHypDur = skewness(avgHypDur,0);
kurtAvgHypDur = kurtosis(avgHypDur,0);

meanStdHypDur =  nanmean(stdHypDur);
meanCvHypDur =  nanmean(cvHypDur);
meanRangeHypDur =  nanmean(rangeHypDur);
meanSkewHypDur =  nanmean(skewHypDur);
meanKurtHypDur =  nanmean(kurtHypDur);

hypDurMat = [meanAvgHypDur,stdAvgHypDur,cvAvgHypDur,rangeAvgHypDur,skewAvgHypDur,kurtAvgHypDur,meanStdHypDur,meanCvHypDur,meanRangeHypDur,meanSkewHypDur,meanKurtHypDur];