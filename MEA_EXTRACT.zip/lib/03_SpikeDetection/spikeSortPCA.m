function spikeSortPCA()

fs = 10000;
padding = 1; %number of milliseconds around the timestamp
ms = round(fs/1000); % 1 millisecond

folder = uigetdir(pwd,'Select root folder');
cd(folder);
list = dir('*');
cd(list(3).name);

list = dir('*_MAT_files*');
cd(list(1).name);
list = dir('*');
cd(list(3).name);
matFolder = pwd;

cd ..
cd ..

mkdir('SortedSpikes');
cd('SortedSpikes');
sortFolder = pwd;
cd ..

mkdir('SortedSpikeWaveforms');
cd('SortedSpikeWaveforms');
sortWaveFolder = pwd;
cd ..


list = dir('*PeakDetectionMAT*');
cd(list(1).name);
list = dir('*ptrain*');
cd(list(1).name);
peakFolder = pwd;
peakList = dir('*ptrain*.mat');

for i=1:length(peakList)
    %find spike positions
    cd(peakFolder);
    [~,fileName,~]=fileparts(peakList(i).name);
    electrode = getChanNo(fileName);
    
    load(peakList(i).name);
    timestamps = find(peak_train);
    spikeVals = peak_train(timestamps);
    
    %go into the mat folder
    cd(matFolder);
    list = dir(strcat('*',num2str(electrode),'.mat'));
    load(list(1).name);
    
    spikes = [];
    f=figure();
    
    times = [];
    hold on
    for j=1:length(timestamps)
        try
            spikeVal = data(timestamps(j));
            %get 4ms around peak (+ or -)
            spike = data(max([1,timestamps(j)-padding*ms]):min([timestamps(j)+padding*ms,length(data)]));
            extremums = diff(diff(spike)>0);
            hills = find(extremums==-1)+1;
            valleys = find(extremums==1)+1;
            hillVals = spike(hills);
            valleyVals = spike(valleys);
            
            ex = find(extremums)+1;
            
            if nnz(ismember(spikeVal,hillVals))>0
                ind = find(spikeVal==hillVals); % find where the detected peak is
                %make everything beyond the zero crossings 0;
                firstCross = ex(find(ex<hills(ind)));
                thirdCross = ex(find(ex>hills(ind)));
                %spike(1:max([1,firstCross(end-1)]))=0;
                %spike(min([length(spike),thirdCross(1)]):end)=0;
                %extract waveform
                spike = spike(firstCross(end)-round(ms/2):firstCross(end)+round(ms));
            elseif nnz(ismember(spikeVal,valleyVals))>0
                ind = find(spikeVal==valleyVals);
                firstCross = ex(find(ex<valleys(ind)));
                thirdCross = ex(find(ex>valleys(ind)));
                %(1:max([1,firstCross(end)]))=0;
                %spike(min([length(spike),thirdCross(2)]):end)=0;
                spike = spike(valleys(ind)-round(ms/2):valleys(ind)+round(ms));
            end
            
            spikes = [spikes;spike'];
            plot(spike);
            time=[time,timestamp(j)];
        catch
        end
    end
    close(f);
    [coeff,score,latent,tsquared,explained] = pca(spikes);
    noOfCoeffs = min(find(cumsum(explained)>=90));
    plot(score(:,1),score(:,2),'+');
    
    options = statset('Display','final');
    
    % noOfCoeffs = 2;
    maxNeurons = 5;
    AICs = zeros(maxNeurons,1);
    BICs = zeros(maxNeurons,1);
    CHs = zeros(maxNeurons,1);
    
    for j=1:maxNeurons
        try
            gm = gmdistribution.fit(score(:,1:noOfCoeffs),j,'Replicates',5,'SharedCov',true,'CovType','diagonal');
            [idx,mu,sums] = kmeans(score(:,1:noOfCoeffs),j,'Replicates',10);
            CHs(j) = clusEvalCH(score(:,1:noOfCoeffs),idx,mu,sums);
            if j>1 && CHs(j)<=CHs(j-1)
                j=j-1;
                break
            end
            %             AICs(j) = gm.AIC;
            %             BICs(j) = gm.BIC;
            %             if j>1 && (AICs(j)>AICs(j-1) || BICs(j)>BICs(j-1) || gm.Converged==0)
            %               j=j-1;
            %                 break
            %             end
        catch
            j=j-1;
            break
        end
    end
    
    neurons = j;
    disp(strcat(num2str(neurons),' neurons found'));
    
    %idx = kmeans(score(:,1:noOfCoeffs),neurons,'Replicates',5);
     gm = gmdistribution.fit(score(:,1:noOfCoeffs),neurons,'Replicates',5,'SharedCov',true,'CovType','diagonal');
     idx = cluster(gm,score(:,1:noOfCoeffs));
    X = score(:,1:noOfCoeffs);
    
    cm = colormap;
    f=figure();
    hold on
    for k=1:neurons
        cluster1 = X(idx == k,:);
        val = floor(k*size(cm,1)/neurons);
        if val<=0
            val =1;
        end
        scatter(cluster1(:,1),cluster1(:,2),10,cm(val,:));
    end
    close(f);
    % [center,U] = fcm(score(1:noOfCoeffs),[1:5]);
    
    %scrsz = get(0,'ScreenSize');
    % f =figure('Position',[1+10 scrsz(1)+100 scrsz(3)-150 scrsz(4)-200]);
    f = figure();
    for k=1:neurons
        subplot(neurons,1,k);
        hold on
        xlabel('Time (ms)');
        ylabel('Voltage (uV)');
        val = floor(k*size(cm,1)/neurons);
        if val<=0
            val =1;
        end
        for j=1:size(spikes,1)
            if idx(j)==k
                plot([1:length(spikes(j,:))]./(fs/1000),spikes(j,:),'color',cm(val,:));
            end
        end
    end
    
    cd(sortWaveFolder);

    saveas(f,strcat('sortedWaveforms_',num2str(electrode)));
    saveas(f,strcat('sortedWaveforms_',num2str(electrode),'.jpg'));
    close(f);
    
    cd(sortFolder);
    orgPeakTrain = peak_train;
    for k=1:neurons
        temp = zeros(length(orgPeakTrain),1);
        temp(timestamps(idx==k))=spikeVals(idx==k);
        peak_train = sparse(temp);
        save(strcat(fileName,'_',num2str(k),'.mat'),'peak_train');
    end
end