function [th,reject] = autComputThVec(data,fs,multCoeff)

nSamples = length(data);
binWidth = 10*fs; %10 s
noOfBins = ceil(nSamples/binWidth);
th = zeros(nSamples,1);

nWin = 10;
winDur = 1000*1e-3;
winDur_samples = winDur.*fs;
startSample = 1:(round(binWidth/nWin)):binWidth; % take 30 samples from the signal
endSample = startSample+winDur_samples-1;

for i = 1:noOfBins
    
    thBlock = 100;
    dataBlock = data((i-1)*binWidth+1:min([i*binWidth,nSamples]));
    
    for j = 1:nWin
        try
            thThis = std(dataBlock(startSample(j):endSample(j))); %since you're cutting off the dc frequencies, there shouldn't be an offset --> mean ~= 0
            if thBlock > thThis
                thBlock = thThis;
            end
        end
    end
    
    th((i-1)*binWidth+1:i*binWidth) = thBlock;
end

th = th.*multCoeff;

%% ADDING HIGH THRESHOLD FOR NOISY CHANNELS SO NO PEAKS WILL BE DETECTED
% calculating 25 and 75 percentile together reduces the computation time
% significantly for very long vector, like th here. 
percent_25_75 = prctile(th,[25, 75]);
if percent_25_75(2)/percent_25_75(1) > 1.5
    reject = 1;
else
    reject = 0;
end

end