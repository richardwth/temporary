function [] = multiwellPTSDMexAutoThVec (peakDuration, refrTime, fs, thresh_vector, multCoeff, matfolder, pkdfolder,recordingTime)
% Function to implement the Peak Detection with the Precision Timing Spike
% Detection algorithm (PTSD) and the peak-to-peak threshold computed 
% using a multiplicative factor of the standard deviation of the basal noise.
% The artifact position is saved in the variable artifact.

% PTSD conceived by Alessandro Maccione
% implemented by Mauro Gandolfo (October 2006)
% modified by Michela Chiappalone (February 2009)
% modified by PL Baljon (May 2009)
%   - call to mex file for spike detection
%   - TTL-based artefact detection; original no longer available
%   - more efficient construction of sparse array peak_train
% modified by V Pasquale (May 2009)
%   - introduction of the automatic threshold computation (phase by phase)
% modified by Michela Chiappalone (March 2010)

% --------------- INPUT VARIABLES AND FOLDERS
cd (matfolder)
first=3;
matfolderMod = strrep(matfolder,'_Mat_Files','_Mat_files'); % MAIN folder containing the Mat files
anafolder = strrep(matfolderMod,'_Mat_files','_Ana_files'); % MAIN folder containing the Analog files

warning off MATLAB:MKDIR:DirectoryExists
mkdir (pkdfolder)
cd (pkdfolder)
pkdfolder = pwd;

% INITIALIZE WAITBAR
w = waitbar (0,'Spike Detection PTSD - Please wait...');

% -------------------------- START PROCESSING -----------------------------------
cd(matfolder)

   
    
    matdir=pwd;     % save the path to the present working directory
    matfiles = dir; % save in a structure the information on the files present in the current directory
    nummatfiles = length(matfiles); % number of .mat files present in the current directory

    for i=first:nummatfiles % FOR cycle on the single directory files
        
         waitbar((i-first)/(nummatfiles-first+1)) % WAITBAR
        filename = matfiles(i).name;     % current file
        
        % Refactoring the electrode label extraction from file name by
        % Damith Senanayake 2018 May(@damithsenanayake/@senanayaked). This
        % is to facilitate the Spike and Burst detection from large numbers 
        % of electrodes per well (namely for 120 channels). 
        
        [~, filename_sans_ext, ~] = fileparts(filename);
        split_parts = strsplit(filename_sans_ext, '_');
        electrode = string(split_parts(end)); % get electrode as the last _ separated value        
%         electrode=filename(end-5:end-4); % electrode current files refers to
        load (filename);                 % load the raw data .mat file
        data= data-mean(data); % "center" the data contained in the .mat file on the value 0
        disp(electrode);
        if ~isempty(thresh_vector)
            thresh = thresh_vector(eval(electrode)); % read the vector of threshold
        else
            thresh = autComputThVec(data,fs,multCoeff);
        end
        % -----------------------------------------------------------------        
        % Calling the MEX file
        % -----------------------------------------------------------------
        [spkValues, spkTimeStamps] = SpikeDetection_PTSD_dynTh(double(data)', thresh, peakDuration, refrTime); %spkValues here are spike heights between 2 extremums
        
        spikesTime  = 1 + spkTimeStamps( spkTimeStamps > 0 ); % +1 added to accomodate for zero- (c) or one-based (matlab) array indexing
        spikesValue = spkValues( spkTimeStamps > 0 );
        clear spkValues spkTimeStamps; % very large arrays.
        
        % Prepare for the SAVING phase
        name=strcat('ptrain_', filename);
       
        cd (pkdfolder)            
       
        % Check if there are spikes before SAVING
        if ( any(spikesTime) ) % If there are spikes in the current signal
            % more efficient code, not creating train in memory: possible to make sparse array immediately. PL 05/09.
            % double() is used because sparse() only accepts double-precision inputs, 
            % while spikesValue and data(spikesTime) could be single to
            % reduce computational time. For double inputs, double() does nothing
            % so this would not increase computational cost anyway - Richard 01-May-2019
            peak_train = sparse(spikesTime,1,double(spikesValue),length(data),1);
            amp_train = sparse(spikesTime,1,double(data(spikesTime)),length(data),1);
            if ~isnan(recordingTime) && length(peak_train) > fs*recordingTime
                peak_train = peak_train(length(peak_train)-recordingTime*fs:end);
                amp_train = amp_train(length(peak_train)-recordingTime*fs:end);
            end
            clear spikesTime spikesValue         % FREE the memory from the unuseful variables
                 
        else % If there are no spikes in the current signal
            peak_train = sparse(length(data), 1);
            amp_train = sparse(length(data), 1);
            if ~isnan(recordingTime) && length(peak_train) > fs*recordingTime
                peak_train = peak_train(length(peak_train)-recordingTime*fs:end);
                amp_train = amp_train(length(peak_train)-recordingTime*fs:end);
            end
            
        end    
  
        
        save (name, 'peak_train','amp_train');
        clear peak_train  amp_train      
        cd (matdir)
    end % on MATFILES
    cd(matfolder)

close (w)

end
%--------------------------------------------------------------------------
function filteredData = filtDataUser(data2Filter, filterType, cutoffFrequency,samplingFrequency)
%--------------------------------------------------------------------------
% filter data if required by the user

% initialise variable
filteredData = data2Filter;

% filter band type and filter flag
filterBandType = {'no_filter'; 'high'; 'low'};

% in case filtering must be applied, apply butterworth filter
if (filterType > 1)
    Wn_norm = cutoffFrequency/(0.5*samplingFrequency);
    
    % design transfer function
    [b, a] = butter(2, Wn_norm, strtrim(filterBandType{filterType}));
    
    % apply filter
    filteredData = (filter(b, a, data2Filter));
    
    % clear variables
    clear b a WN_norm;
end
end