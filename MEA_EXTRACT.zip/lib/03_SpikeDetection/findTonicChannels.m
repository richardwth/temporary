function saveParamsMultiwell()
% Getting features per dataset

answer = inputdlg({'Burst Detection File Name','Network Burst Detection File Name','fs'},'Save Parameters',1,{'BurstDetectionMAT_3-BAFR','*NetworkBurstDetectionFilesBO*','20000'});
burstDetectionStr = strcat('*',answer{1},'*');
nbDetectionStr = strcat('*',answer{2},'*');
fs = str2double(answer{3});


%% Initialize data %'maxIbeiLog','startPeak','IBeiAreaUnder10',
dataParams = {'meanSCBDuration(ms)','stdSCBDuration(ms)','cvSCBDuration','rangeSCBDuration(ms)','meanSCBSize','stdSCBSize','cvSCBSize','rangeSCBSize'...
    ,'avgChansInNB','meanDuration(ms)','stdDuration(ms)','cvDuration','rangeDuration(ms)',...
    'meanInbis(s)','stdInbis(s)','cvInbis','rangeInbis(s)','meanJitter(ms)','stdJitter(ms)','cvJitter','rangeJitter(ms)',...
    'NBRate','totNoOfSpikes','totNBAmp(uV)','avgNBPeakAmp(uV)','avgNBTimeAmp(uVperS)',...
    'mfrAll','mfrIn','mfrOut','mfrRatio','noOfSpikingChans','%chansInNBs','avgSpikesInNB','avgAmp(uV)','%spikesInNBs','meanNBSI(s)','stdNBSI(s)','cvNBSI','rangeNBSI(s)',...
    'name','well'};




channels = getMultiwell12Channels();
netParams = cell(1,length(channels)+1);

%% Get the upper root folder
upperRootFolder = uigetdir(pwd,'Select the root folder');
cd(upperRootFolder);

folderList = dir('*');


%% Iterate for all folders in the upper r0ot folder
for x = 3:length(folderList)
    
    cd(upperRootFolder);
    
    %% Go into a folder for 1 sample
    rootFolder = folderList(x).name;
    disp(sprintf('Analyzing...%s',rootFolder));
    
    % try
    cd(rootFolder);
    rootFolderPath = pwd;
    
    wellList = dir('*Well*');
    
    for j=1:length(wellList);
        
        meanSCBDuration = NaN;
        stdSCBDuration = NaN;
        cvSCBDuration = NaN;
        rangeSCBDuration = NaN;
        meanSCBSize = NaN;
        stdSCBSize = NaN;
        cvSCBSize = NaN;
        rangeSCBSize = NaN;
        avgChansInNB = NaN;
        meanDuration = NaN;
        stdDuration = NaN;
        cvDuration = NaN;
        rangeDuration = NaN;
        meanInbis = NaN;
        stdInbis = NaN;
        cvInbis = NaN;
        rangeInbis = NaN;
        meanJitter = NaN;
        stdJitter = NaN;
        cvJitter = NaN;
        rangeJitter = NaN;
        NBRate = NaN;
        totNoOfSpikes = NaN;
        totNetBurstAmp = NaN;
        avgNetBurstPeakAmp = NaN;
        avgNetBurstTimeAmp = NaN;
        mfrAll = NaN;
        mfrIn = NaN;
        mfrOut = NaN;
        mfrRatio = NaN;
        spikesInBursts = NaN;
        noOfSpikingChans = NaN;
        percOfChansInNBs = NaN;
        nbSpikesAvg = NaN;
        avgAmp = NaN;
        spikesInBursts =NaN;
        meanNBStartInts = NaN;
        stdNBStartInts = NaN;
        cvNBStartInts = NaN;
        rangeNBStartInts = NaN;
        
        cd(rootFolderPath);
        cd(wellList(j).name);
        disp(wellList(j).name);
        wellPath = pwd;
        
        %% Get recording time
        list = dir('*Mat_files*');
        cd(list(1).name);
        list = dir('*.mat');
        load(list(1).name);
        recordingTime = length(data)/fs; %in seconds
        cd ..
        
        
        %% Get data from burst detection files
        disp('Analysing burst detection files');
        list = dir(burstDetectionStr);
        burstFolderName = fullfile(pwd,list(1).name);
        cd(burstFolderName);
        
        %try
        
        list = dir('*BurstDetectionFiles*');
        folderName = list(1).name;
        
        cd(folderName);
        list = dir('*burst_detection*.mat');
        
        load(list(1).name);
        
        %%Find active channels
        burstMat = [];
        burstChannels = 0;
        ibi = [];
        isbi = [];
        for i=1:length(burst_detection_cell)
            if ~isempty(burst_detection_cell{i})
                bursts = burst_detection_cell{i};
                scb = bursts(1:end-1,1:4);
                ibi = [ibi;scb(2:end,1)-scb(1:end-1,2)];
                isbi = [isbi;diff(scb(:,1))];
                burstMat = [burstMat;bursts(1:end-1,1:4)];
                burstChannels = burstChannels+1;
            end
        end
        
        if burstChannels > 1
            burstMat = sortrows(burstMat,1);
            
            meanSCBSize = mean(burstMat(:,3));
            stdSCBSize =  std(burstMat(:,3));
            cvSCBSize = stdSCBSize/meanSCBSize;
            rangeSCBSize = max(burstMat(:,3))-min(burstMat(:,3));
            
            burstMat(:,4) = 1000*burstMat(:,4);% in milliseconds
            meanSCBDuration = mean(burstMat(:,4));
            stdSCBDuration = std(burstMat(:,4));
            cvSCBDuration = stdSCBDuration/meanSCBDuration;
            rangeSCBDuration = max(burstMat(:,4))-min(burstMat(:,4)) ;
        end
        
        %end
        
        cd(burstFolderName);
        
        
        
        %Get network burst metrics
        disp('Analysing network burst detection files');
        
        cd(burstFolderName);
        
        % try
        list = dir(nbDetectionStr);
        folderName = list(1).name;
        cd(folderName);
        list = dir('*NetworkBurstDetection*.mat');
        for i=1:length(list)
            x = strfind(list(i).name,'parameters');
            if isempty(x)
                fileName = list(i).name;
                break;
            end
        end
        
        path = pwd;
        
        load(fullfile(path,fileName));
        
        if ~isempty(netBursts)
            if size(netBursts,1)>2
                netBursts(:,4) = 1000*netBursts(:,4)./fs;
                avgChansInNB = mean(netBursts(:,5));
                meanDuration = mean(netBursts(:,4));
                stdDuration = std(netBursts(:,4));
                cvDuration = stdDuration/meanDuration;
                rangeDuration = max(netBursts(:,4))-min(netBursts(:,4));
                
                NBRate = size(netBursts,1)/recordingTime;
                totNoOfSpikes = mean(netBursts(:,9));
                totNetBurstAmp = mean(netBursts(:,6));
                avgNetBurstPeakAmp = mean(netBursts(:,7));
                avgNetBurstTimeAmp = mean(netBursts(:,8)); %which unit is time in?
                
                
                inbis = netBursts(2:end,1)-netBursts(1:end-1,2);
                inbis = inbis./fs;
                meanInbis = mean(inbis);
                stdInbis = std(inbis);
                cvInbis = stdInbis/meanInbis;
                rangeInbis  = max(inbis)-min(inbis);
                
                nbStartInts = diff(netBursts(:,1));
                nbStartInts = nbStartInts./fs;
                meanNBStartInts = mean(nbStartInts);
                stdNBStartInts = std(nbStartInts);
                cvNBStartInts = std(nbStartInts)/mean(nbStartInts);
                rangeNBStartInts = range(nbStartInts);
                
                
                jitter = zeros(size(netBursts,1),1);
                
                for i=1:size(netBurstsPattern,1)
                    pattern = netBurstsPattern{i};
                    [~,inds,~]= unique(pattern(:,1),'stable');
                    jitter(i) = max(pattern(inds,2))-min(pattern(inds,2));
                end
                
                jitter = 1000*jitter./fs; %ms
                meanJitter = mean(jitter);
                stdJitter = std(jitter);
                cvJitter = stdJitter/meanJitter;
                rangeJitter = max(jitter)-min(jitter);
                
                [mfrAll,mfrIn,mfrOut,mfrRatio,noOfSpikingChans,noOfChansInNBs,chanMat,nbSpikesAvg,avgAmp,spikesInBursts] = findNonNBMFR(path,fileName,getMultiwell12Channels());
                percOfChansInNBs = 100*noOfChansInNBs/noOfSpikingChans;
            else
                currentPath = pwd;
                [mfrAll,noOfSpikingChans,avgAmp] = simpleSpikeParams(wellPath,getMultiwell12Channels());
                cd(currentPath);
            end
        else
            currentPath = pwd;
            [mfrAll,noOfSpikingChans,avgAmp] = simpleSpikeParams(wellPath,getMultiwell12Channels());
            cd(currentPath);
        end
        %  end
        
        mfrAll = mfrAll*fs;
        mfrIn = mfrIn*fs;
        mfrOut = mfrOut*fs;
        
        % end
        
        name = rootFolder;
        well = wellList(j).name;
        
        dataSetTemp = [meanSCBDuration,stdSCBDuration,cvSCBDuration,rangeSCBDuration,meanSCBSize,stdSCBSize,cvSCBSize,rangeSCBSize,...
            avgChansInNB,meanDuration,stdDuration,cvDuration,rangeDuration,meanInbis,stdInbis,cvInbis,rangeInbis,meanJitter,stdJitter,cvJitter,rangeJitter,...
            NBRate,totNoOfSpikes,totNetBurstAmp,avgNetBurstPeakAmp,avgNetBurstTimeAmp,...
            mfrAll,mfrIn,mfrOut,mfrRatio,noOfSpikingChans,percOfChansInNBs,nbSpikesAvg,avgAmp,spikesInBursts,meanNBStartInts,stdNBStartInts,cvNBStartInts,rangeNBStartInts,...
            ];
        
        dataSetTemp(isnan(dataSetTemp)) = 0;
        dataSet = horzcat(num2cell(dataSetTemp),{name,well});
        dataParams = vertcat(dataParams,dataSet);
        
        
        cd ..
    end
end


assignin('base', 'dataParams', dataParams)

pause(2);
[fileName,path] = uiputfile(fileName,'Save file name');
[pathstr,fileName,ext] = fileparts(fileName);



save(fullfile(path,strcat(fileName,'.mat')),'dataParams');
xlswrite(fullfile(path,strcat(fileName,'.xls')), dataParams, 'Sheet1', 'A1');
