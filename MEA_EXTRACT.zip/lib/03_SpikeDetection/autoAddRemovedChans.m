function autoAddRemovedChans()

first = 3;

rootFolder = uigetdir(pwd,'Select root folder');

cd(rootFolder);

folderList = dir('*');

count =1;

while count<=length(folderList)
    if folderList(count).isdir == 0
        folderList(count) = [];
    else
        count=count+1;
    end
end

for i=first:length(folderList)
    cd(rootFolder);
    folderName = folderList(i).name;
    cd(folderName);
    
    disp(folderName);
    
    
    list = dir('*');
    
    count = 1;
    
    while count<=length(list)
        if list(count).isdir == 0
            list(count) = [];
        else
            count=count+1;
        end
    end
    
    cd(list(3).name);
        
    list = dir('*PeakDetectionMAT*');    
     cd(list(1).name);
     list = dir('*ptrain*');
     peakFolder = fullfile(pwd,list(1).name);
     
  cd ..

     exFolder = 'ExcludedChans';
     cd(exFolder);
     list = dir('*ptrain*.mat');
     
     for j=1:length(list)
         movefile(list(j).name,peakFolder);
     end
     
     cd ..
     rmdir(exFolder);
end