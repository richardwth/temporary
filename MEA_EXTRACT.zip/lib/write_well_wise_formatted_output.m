function y = write_well_wise_formatted_output(dataParams,pheno_type_based_op_filename,drug_based_op_filename)


%Extract the sample names
var_names = dataParams(1,:);

%retrive the index of names in the cell array
ind = find(ismember(var_names,'name'));
data = dataParams(2:end,:);
data_to_write= {'meanSCBDuration(ms)','stdSCBDuration(ms)','cvSCBDuration','rangeSCBDuration(ms)','meanSCBSize','stdSCBSize','cvSCBSize','rangeSCBSize'...
    ,'avgChansInNB','meanDuration(ms)','stdDuration(ms)','cvDuration','rangeDuration(ms)',...
    'meanInbis(s)','stdInbis(s)','cvInbis','rangeInbis(s)','meanJitter(ms)','stdJitter(ms)','cvJitter','rangeJitter(ms)',...
    'NBRate','totNoOfSpikes','totNBAmp(uV)','avgNBPeakAmp(uV)','avgNBTimeAmp(uVperS)','mfrAll','mfrIn','mfrOut','mfrRatio','noOfSpikingChans','%chansInNBs','avgSpikesInNB','avgAmp(uV)','%spikesInNBs','meanNBSI(s)','stdNBSI(s)','cvNBSI','rangeNBSI(s)','Kappa'};

well_IDs= {'Well_A1';'Well_A2';'Well_A3';'Well_A4';'Well_A5';'Well_A6';'Well_B1';'Well_B2';'Well_B3';'Well_B4';'Well_B5';'Well_B6';'Well_C1';'Well_C2';'Well_C3';'Well_C4';'Well_C5';'Well_C6';'Well_D1';'Well_D2';'Well_D3';'Well_D4';'Well_D5';'Well_D6'};

%averaged_dataset = return_formatted_data(dataParams,well_IDs);
%tab= dataset2table(averaged_dataset);

tab= cell2table(data);
sample_names = unique(tab{:,41});

%Group phenotype Based
%Need to be extracted
cell_A=getWellIDs(tab,'well_[A,B,C,D][1,2,3]_*');
cell_B=getWellIDs(tab,'well_[A,B,C,D][4,5,6]_*');

%drug studies (Drug Layout): The well names are extracted from the final
%output matrix
cell_A_drug_1= getWellIDs(tab,'well_[A,B,C,D]1_*');
cell_A_drug_2=  getWellIDs(tab,'well_[A,B,C,D]2_*');
cell_A_drug_3=  getWellIDs(tab,'well_[A,B,C,D]3_*');
cell_B_drug_1=  getWellIDs(tab,'well_[A,B,C,D]4_*');
cell_B_drug_2=  getWellIDs(tab,'well_[A,B,C,D]5_*');
cell_B_drug_3=  getWellIDs(tab,'well_[A,B,C,D]6_*');

%table_with_group_and_well_ids is created with seperate column specifying
%the well_ID and group_ID corresponding to a given code name.
%Having this new table, makes it straightforward to generate a pivot table
%and write data.

data_to_write_map = containers.Map;
drug_layout_data_to_write_map = containers.Map;
table_with_group_and_well_ids = horzcat(tab,cell(height(tab),2));
%Set dataparams with group_ids
group_ids={};
%Retrieve unique groups
for i= 1:size(data,1)
    str=  data(i,43);
    str_t = strsplit(str{1},'_G');
    group_ids{i}= strcat('G',str_t{2});
    date_tokenizer= strsplit(str_t{2},'_');
    date_ids{i} = strcat(date_tokenizer{2});
    well_id = str_t{1};
    
    table_with_group_and_well_ids.Var44{i} =  group_ids{i};
    table_with_group_and_well_ids.Var45{i} = well_id;
    %Date ID is used to sort the table, so that in the final output EXCEL
    %sheet the columns will be in order of the dates(i.e The groups run on
    % the same day are subsequent to each other
    table_with_group_and_well_ids.Var46{i} =  date_ids{i};
    
end

%group_ids=unique(group_ids);

%all_well_rep_ids=  (unique(getWellIDs(tab,'well_[A,B,C]*_*')))';
%Initialise a talbe with zero values for all wellids and all group ids

% all_data_table =  table(all_well_rep_ids,repmat(0,length(all_well_rep_ids),1));
% all_data_table.Properties.VariableNames = {'Well_ID',group_ids{1}};
% 
% for i = 2 : length(group_ids)
%     temp_table =  table(repmat(0,length(all_well_rep_ids),1));
%     temp_table.Properties.VariableNames = {group_ids{i}};
%     all_data_table = [all_data_table temp_table];
%     
%     
%     
% end
table_with_group_and_well_ids.Properties.VariableNames{44}= 'Group_ID' ;
table_with_group_and_well_ids.Properties.VariableNames{45}= 'Well_ID';
table_with_group_and_well_ids.Properties.VariableNames{46}= 'DATE_ID';
table_with_group_and_well_ids= sortrows(table_with_group_and_well_ids,'DATE_ID','ascend');
groups=unique(table_with_group_and_well_ids.Group_ID,'stable');


%to implement from here

%all data table contains well id vs gruop id empty table

for iter = 1:(ind-1)
    cell_line_data_map=containers.Map;
    drug_layout_lines_map=containers.Map;
    temp_table=[table_with_group_and_well_ids(:,iter) table_with_group_and_well_ids.Well_ID table_with_group_and_well_ids.Group_ID ];
    temp_table.Properties.VariableNames = {'var_val','Well_ID','Group_ID'};
    %unstack is used to create the pivot table
    %unstack orders the columns in the order of unique group names,i.e:
    %ordered by group name rather than the date (if we had sorted by date)
    table_with_data_to_write= unstack(temp_table,'var_val','Group_ID');
    %Get the rearranged table, ordered based on the date.
    table_with_data_to_write =orderTable(table_with_data_to_write,groups);
    %replace NAN with zeros
%     idx = ismissing(table_with_data_to_write(:,group_ids));
%     table_with_data_to_write{:,group_ids}(idx) = ' '  ;
    
    table_with_data_to_write.Properties.RowNames = table_with_data_to_write.Well_ID;
    
    
    cell_line_data_map('celll_line_1_table')= table_with_data_to_write(unique(cell_A),:);
    cell_line_data_map('celll_line_2_table')= table_with_data_to_write(unique(cell_B),:);
    
    %Drug layout related values
    
    drug_layout_lines_map('line_A_drug_1') = table_with_data_to_write(unique(cell_A_drug_1),:);
    drug_layout_lines_map('line_A_drug_2') = table_with_data_to_write(unique(cell_A_drug_2),:);
    drug_layout_lines_map('line_A_drug_3') = table_with_data_to_write(unique(cell_A_drug_3),:);
    drug_layout_lines_map('line_B_drug_1') = table_with_data_to_write(unique(cell_B_drug_1),:);
    drug_layout_lines_map('line_B_drug_2') = table_with_data_to_write(unique(cell_B_drug_2),:);
    drug_layout_lines_map('line_B_drug_3') = table_with_data_to_write(unique(cell_B_drug_3),:);
    
    data_to_write_map(var_names{iter})= cell_line_data_map;
    
    drug_layout_data_to_write_map(var_names{iter}) = drug_layout_lines_map;
    
    
end

%Write Cell line wise grouped data into Excel Sheet
keys = data_to_write_map.keys;
%Convert the data in table to cellarray and write to excel (one parameter per sheet)
for iter = 1: length(keys)
    key = keys{iter};

    iter_values =  data_to_write_map(key);
    table_1=[iter_values('celll_line_1_table').Properties.VariableNames;table2cell(iter_values('celll_line_1_table'))];
    table_2=[iter_values('celll_line_2_table').Properties.VariableNames;table2cell(iter_values('celll_line_2_table'))];
    % xlswrite takes time; it is necessay to reduce the number of times it
    % is called.
    table_12 = [table_1; cell(1,2); table_2];
    xlswrite(pheno_type_based_op_filename,table_12,key);
%     xlswrite(pheno_type_based_op_filename,table_1,keys{iter});
%     
%     %work out the index to write 
%     xlswrite(pheno_type_based_op_filename,table_2,keys{iter},strcat('A',num2str(length(table_1)+2)));

    drug_map_iter_values= drug_layout_data_to_write_map(key);

    drug_t_1 = [drug_map_iter_values('line_A_drug_1').Properties.VariableNames;table2cell(drug_map_iter_values('line_A_drug_1'))];
    drug_t_2 = [drug_map_iter_values('line_A_drug_2').Properties.VariableNames;table2cell(drug_map_iter_values('line_A_drug_2'))];
    drug_t_3 = [drug_map_iter_values('line_A_drug_3').Properties.VariableNames;table2cell(drug_map_iter_values('line_A_drug_3'))];
    drug_t_4 = [drug_map_iter_values('line_B_drug_1').Properties.VariableNames;table2cell(drug_map_iter_values('line_B_drug_1'))];
    drug_t_5 = [drug_map_iter_values('line_B_drug_2').Properties.VariableNames;table2cell(drug_map_iter_values('line_B_drug_2'))];
    drug_t_6 = [drug_map_iter_values('line_B_drug_3').Properties.VariableNames;table2cell(drug_map_iter_values('line_B_drug_3'))];
    %index is used to maintain the next index to write to .
    drug_t_123456 = [drug_t_1; cell(1,2); drug_t_2; cell(1,2); drug_t_3; cell(1,2); drug_t_4; cell(1,2); drug_t_5; cell(1,2); drug_t_6];

    xlswrite(drug_based_op_filename,drug_t_123456,key);
%     index = 0;
%     
%     xlswrite(drug_based_op_filename,drug_t_1,keys{iter});
%     index = length(drug_t_1);
%     xlswrite(drug_based_op_filename,drug_t_2,keys{iter},strcat('A',num2str(index+2)));
%     
%     index = index + length(drug_t_2);
%     xlswrite(drug_based_op_filename,drug_t_3,keys{iter},strcat('A',num2str(index+3)));
%     index = index + length(drug_t_3);
%     xlswrite(drug_based_op_filename,drug_t_4,keys{iter},strcat('A',num2str(index+4)));
%     index = index + length(drug_t_4);
%     xlswrite(drug_based_op_filename,drug_t_5,keys{iter},strcat('A',num2str(index+5)));
%     index = index + length(drug_t_5);
%     xlswrite(drug_based_op_filename,drug_t_6,keys{iter},strcat('A',num2str(index+6)));

end

end

% getWellIDs function is written to retrieve the well ids that match a
% given a set of wells included in phenotype/drug based layout.
function wellIDs = getWellIDs(tab,regexpression)


codeNames = table2array(tab(find(~cellfun(@isempty,regexp(table2array(tab(:,43)),regexpression))),43));
%Retrive only the replicate IDS
wellIDs={};

for i=1:length(codeNames)
    temp =  strsplit(codeNames{i},'_G');
    wellIDs{i} = temp{1};
end

end

function dataWiseOrderedtable = orderTable(table_with_data_to_write,orderedGroup)

dataWiseOrderedtable =  [table_with_data_to_write.Well_ID];

for i = 1: length(orderedGroup)
    
    dataWiseOrderedtable = [dataWiseOrderedtable table_with_data_to_write(:,orderedGroup{i})];


end
dataWiseOrderedtable.Properties.VariableNames{1}= 'Well_ID';
end