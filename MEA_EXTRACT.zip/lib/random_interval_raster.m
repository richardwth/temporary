function random_interval_raster(directory, fpath, t_start,well, plate )
    
%randomizing the interval using this random float for this particular well!
    peakTrain = [];
    plot_name = [plate, '-', well]
%     directory = uigetdir('', 'Select the Peak Data Directory');
%     prompt2 = 'Enter the path of the results : ';
%     fpath = uigetdir(directory, 'Select Result Directory');
%     %directory = '/Users/ashwin/Desktop/MEA PROJECT/Test Data/PeakDetectionMAT_PLP2ms_RP1ms'; %input function 
    folder = what(directory);
    matfiles  = folder.mat;

    for i = 1 :numel(matfiles)
        peakTrain{i} = load(strcat(directory,'/',char(matfiles(i))),'peak_train');    
    end
    figure
    set(gcf,'numbertitle','off','name',plot_name);

    %text box "Channel"
    text1 = annotation('textbox');
    text1.Position = [0.015 0.925 0.050 0.070];
    text1.String = 'Channel';
    text1.FontSize = 8;
    text1.FontWeight = 'bold';
    text1.LineStyle = 'none';

    %text box "Raster Plot"
    title_string ="Raster Plot"; 

    text2 = annotation('textbox');
    text2.Position = [0.2 0.925 0.2 0.070 ];
    text2.String = title_string;
    text2.FontSize = 8;
    text2.FontWeight = 'bold';
    text2.LineStyle = 'none';
    
    t_str = t_start;
    if str2num(char(t_start)) > 570
       t_str = '570';
    end
    
    time_string = strcat('Starting Time = ', t_str, 's , duration = 30s');
    
    text3 = annotation('textbox');
    text3.Position = [0.45 0.925 0.4 0.070 ];
    text3.String = time_string;
    text3.FontSize = 8;
%     text3.FontWeight = 'bold';
    text3.LineStyle = 'none';
    %text boxes for indcies 

    plotNames = [12,13,21,22,23,24,31,32,33,34,41,42];

    for a = 1:12
        textBox = annotation('textbox');
        textBox.String = plotNames(a);
        textBox.FontSize = 7;
        textBox.LineStyle = 'none';
        textBox.Position = [0.025 ,0.875 - 0.070 * (a-1),0.049 0.049 ];
    end

    %draw the alternative raster plot
    
    
    for k = 1 : 12
        subplot(12,1,k);
        rasterPlot(full(peakTrain{k}.peak_train),t_start);
        axis off;
    end

    %save the plot as a .jpeg

    %fpath = '/Users/ashwin/Desktop/MEA PROJECT';
    saveas(gca, fullfile(fpath, well), 'jpeg');

    %store the peak count per channel in the array

    peakCount = zeros(1,12); 

    for n = 1 : 12
       peakCount(n) = numel(find(full(peakTrain{n}.peak_train)));
    end

    %calculate the firing rate per channel

    firingRate = zeros(1,12);

    for n = 1 : 12
        sampleCount = numel(peakTrain{n}.peak_train);
        sampleRate = 20000;
        %sampleRate = getSampleRate;
        sampleTime = 1/sampleRate;
        recordingTime = sampleCount*sampleTime;
        firingRate(n) = peakCount(n)/recordingTime;
    end

    %tabulate the above the data

    fileMatrix = {'Channel', 'Spike Count', 'Firing Rate'};
    table = zeros(12,3);

    for i = 1:12
        table(i,1) = i;
        table(i,2) = peakCount(i);
        table(i,3) = firingRate(i);
    end

    filename = 'C:\Users\admin\Documents\Ashwin\Results - Plots\results.xlsx';
    xlswrite(filename,table);
end